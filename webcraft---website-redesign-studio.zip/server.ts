import express from 'express';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import nodemailer from 'nodemailer';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json());

// Initialize Gemini SDK if API key is present
const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;
if (apiKey) {
  ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Heuristic fallback for analysis when offline or without API key
function generateFallbackAnalysis(params: {
  clientName: string;
  websiteUrl: string;
  industry: string;
  targetAudience: string;
  primaryGoals: string[];
  currentPainPoints: string[];
  language?: string;
}) {
  const isFa = params.language !== 'en';
  const name = params.clientName || (isFa ? 'کارفرما' : 'Client');
  const industry = params.industry || (isFa ? 'خدمات تخصصی' : 'Professional Services');

  if (isFa) {
    return {
      brandPersonality: {
        tone: 'حرفه‌ای، مدرن، شفاف و ارزش‌محور',
        attributes: ['اعتمادآفرین', 'معماری مینیمال', 'سرعت و دسترس‌پذیری بالا', 'موبایل-فرست'],
      },
      uxUiAudit: [
        {
          issue: 'تراکم بصری بالا و عدم شفافیت در سلسله‌مراتب تیترها (Visual Hierarchy)',
          severity: 'high',
          impact: 'کاربران در ۳ ثانیه اول ارزش اصلی کسب‌وکار را درک نکرده و سریعاً سایت را ترک می‌کنند (افزایش بانس ریت).',
          recommendation: 'طراحی مجدد بخش هیرو با تیتر بزرگ متعادل، پیام ارزش شفاف، و یک دکمه CTA اصلی متمرکز.',
        },
        {
          issue: 'تجربه کاربری ضعیف در نسخه موبایل و ناوبری پیچیده',
          severity: 'high',
          impact: 'بیش از ۶۵٪ کاربران با گوشی هوشمند وارد می‌شوند و به دلیل منوهای گیج‌کننده فرایند خرید یا تماس ناتمام می‌ماند.',
          recommendation: 'پیاده‌سازی ناوبری تمیز ۳ قسمتی، منوی روان شبیه اپلیکیشن، و فاصله لمسی بهینه (بیش از ۴۴ پیکسل).',
        },
        {
          issue: 'فونت‌های ناخوانا و کنتراست رنگی ناکافی در کارت‌های خدمات',
          severity: 'medium',
          impact: 'خوانایی ضعیف و خستگی چشم کاربران منجر به کاهش ماندگاری در سایت می‌شود.',
          recommendation: 'مهاجرت به تایپوگرافی استاندارد وب فارسی (وزیرمتن) با کنتراست بالای WCAG AA و فاصله‌گذاری اصولی.',
        },
        {
          issue: 'نبود اثبات اجتماعی (Social Proof) معتبر و نشانه‌های اعتماد در مسیر تبدیل',
          severity: 'medium',
          impact: 'مشتریان احتمالی به دلیل نبود آمار شفاف، رضایت مشتریان یا پروژه‌های پیشین احساس ریسک می‌کنند.',
          recommendation: 'افزودن بلوک نتایج ملموس، داستان‌های موفقیت مشتریان و نشان‌های تضمین کیفیت.',
        },
      ],
      conversionStrategy: {
        headlineImprovement: `طراحی دوباره هویت دیجیتال ${name} برای افزایش ۳ برابری سرنخ‌های فروش و مشتریان وفادار`,
        primaryCtaRecommendation: 'دریافت مشاوره و ارزیابی رایگان',
        secondaryCtaRecommendation: 'مشاهده نمونه‌کارها و نتایج',
        trustSignals: [
          'بیش از ۹۸٪ رضایت مشتریان قبلی',
          'پشتیبانی اختصاصی و گارانتی بازگشت سرمایه',
          'معماری مقیاس‌پذیر و بارگذاری زیر ۱.۵ ثانیه',
        ],
      },
      recommendedDesignSystem: {
        styleName: 'مینیمال مدرن با تمرکز بر تبدیل (Modern Editorial Minimal)',
        colorPalette: {
          primary: '#1E293B',
          secondary: '#475569',
          accent: '#2563EB',
          background: '#F8FAFC',
          surface: '#FFFFFF',
          text: '#0F172A',
        },
        typography: {
          displayFont: 'Vazirmatn (وزیرمتن بولد)',
          bodyFont: 'Vazirmatn (وزیرمتن رگولار)',
          reason: 'خوانایی فوق‌العاده در تمامی نمایشگرهای فارسی، تناسب هندسی مدرن و وزن‌های استاندارد.',
        },
        spacingAndBorder: 'حاشیه‌های ظریف مویی ۱ پیکسلی (Hairline)، گوشه‌های گرد متعادل ۱۲ پیکسل، و تنفس فضایی دست‌ودلبازانه.',
      },
      recommendedSections: [
        {
          sectionName: 'بخش هیرو با قلاب تبدیل مستقیم (Focal Hero)',
          purpose: 'انتقال ارزش پیشنهادی یکتا در نگاه اول همراه با اقدام فوری',
          wireframeLayout: 'تقسیم متوازن دو ستونه (تیتر و CTA در راست، اسکرین‌شات محصول یا ویدیوی کوتاه در چپ)',
          keyElements: ['تیتر شفاف و قدرتمند', 'دکمه اقدام فوری با برچسب مشخص', 'نشانه‌های اعتماد در یک خط'],
        },
        {
          sectionName: 'بلوک بنتو (Bento Grid) قابلیت‌ها و خدمات برتر',
          purpose: 'ارائه دسته‌بندی شده و چشم‌نواز خدمات بدون شلوغی بصری',
          wireframeLayout: 'ماتریس نامتقارن با ترکیب کارت‌های ۲ستونه و تک‌ستونه همراه با ته‌رنگ‌های ظریف',
          keyElements: ['۳ تا ۴ خدمت برجسته', 'آمار واقعی کسب‌وکار', 'توضیحات کوتاه حداکثر ۲ خطی'],
        },
        {
          sectionName: 'مقایسه قبل و بعد / نتایج ملموس مشتریان',
          purpose: 'رفع تردید ذهنی کارفرما و اثبات ارزش خدمات',
          wireframeLayout: 'اسلایدر تعاملی یا کارت‌های مقایسه شفاف اعداد و رضایت مشتری',
          keyElements: ['آمار تحلیلی با ارقام تراز شده', 'نام و موقعیت شغلی مشتری راستی‌آزمایی شده'],
        },
        {
          sectionName: 'فرم تماس و جذب سرنخ مینیمال (Lead Capture)',
          purpose: 'به حداکثر رساندن ارسال درخواست بدون اتلاف وقت کاربر',
          wireframeLayout: 'فرم تک مرحله‌ای متمرکز با فیلدهای ضروری (نام، شماره تماس، توضیح کوتاه)',
          keyElements: ['اعتبارسنجی زنده ورودی‌ها', 'پاسخ و تایید فوری', 'تضمین حفظ حریم خصوصی'],
        },
      ],
      clientProposalPitch: {
        executiveSummary: `وب‌سایت فعلی ${name} دارای پتانسیل تجاری فوق‌العاده‌ای است، اما طراحی کنونی به دلیل اصطکاک بصری و نبود جریان تبدیل مشخص، بخش زیادی از مراجعان را از دست می‌دهد. با این بازطراحی ساختاریافته، هویت برند به سطح پیشرو در صنعت ${industry} ارتقا یافته و نرخ تبدیل به شکل چشمگیری افزایش می‌یابد.`,
        roiJustification: 'کاهش نرخ پرش (Bounce Rate) تا ۴۰٪، بهبود سرعت لود صفحات به زیر ۱.۵ ثانیه و افزایش نرخ کلیک روی دکمه‌های تماس تا ۱۲۰٪.',
        estimatedPhases: [
          {
            phase: 'فاز ۱: کشف، تحقیق کاربری و معماری اطلاعات',
            duration: '۷ الی ۱۰ روز کاری',
            deliverables: ['نقشه سایت (Sitemap)', 'پرسونای مخاطبان', 'وایرفریم‌های Low-Fi تمام صفحات'],
          },
          {
            phase: 'فاز ۲: طراحی رابط کاربری (UI) و سیستم دیزاین در فیگما',
            duration: '۱۰ الی ۱۴ روز کاری',
            deliverables: ['سیستم طراحی اختصاصی (رنگ‌ها، تایپوگرافی، کامپوننت‌ها)', 'طرح‌های High-Fi نسخه دسکتاپ و موبایل', 'پروتوتایپ تعاملی'],
          },
          {
            phase: 'فاز ۳: توسعه مدرن، بهینه‌سازی و واکنش‌گرایی',
            duration: '۱۴ الی ۲۱ روز کاری',
            deliverables: ['کدنویسی استاندارد تمیز', 'سازگاری کامل موبایل و تبلت', 'تست سرعت و بهینه‌سازی Core Web Vitals'],
          },
          {
            phase: 'فاز ۴: تست نهایی، اتصال درگاه‌ها و رونمایی رسمی',
            duration: '۵ الی ۷ روز کاری',
            deliverables: ['تست جامع QA و فرم‌ها', 'آموزش مدیریت سایت به تیم کارفرما', 'راه‌اندازی نهایی روی دامنه اصلی'],
          },
        ],
      },
    };
  }

  // English fallback
  return {
    brandPersonality: {
      tone: 'Authoritative, refined, modern, and conversion-focused',
      attributes: ['Trustworthy', 'Minimalist Architecture', 'High Performance', 'Mobile-First'],
    },
    uxUiAudit: [
      {
        issue: 'Cluttered visual hierarchy and unclear value proposition',
        severity: 'high',
        impact: 'Visitors fail to grasp the core benefit within 3 seconds, resulting in high bounce rates.',
        recommendation: 'Restructure hero with a balanced single headline, clear value statement, and single focused CTA.',
      },
      {
        issue: 'Friction-heavy mobile browsing experience',
        severity: 'high',
        impact: 'Over 60% of mobile users abandon interactions due to nested navigation and undersized touch targets.',
        recommendation: 'Implement clean 3-zone navigation, responsive drawer, and minimum 44px touch targets.',
      },
      {
        issue: 'Low contrast typography and dated design styling',
        severity: 'medium',
        impact: 'Diminishes brand authority and causes readability fatigue.',
        recommendation: 'Modern geometric sans typography pairing with WCAG AA compliant contrast ratios.',
      },
      {
        issue: 'Absence of quantitative social proof near conversion points',
        severity: 'medium',
        impact: 'Prospective clients hesitate to commit due to lack of verifiable evidence.',
        recommendation: 'Add dedicated quantifiable outcomes block and attributable client testimonials adjacent to CTAs.',
      },
    ],
    conversionStrategy: {
      headlineImprovement: `Modernizing ${name}'s digital presence to accelerate qualified inbound inquiries`,
      primaryCtaRecommendation: 'Schedule Discovery Call',
      secondaryCtaRecommendation: 'View Client Case Studies',
      trustSignals: ['Proven 98% client satisfaction', 'Guaranteed sub-1.5s load speeds', 'Dedicated post-launch warranty'],
    },
    recommendedDesignSystem: {
      styleName: 'Modern Editorial Minimalist',
      colorPalette: {
        primary: '#0F172A',
        secondary: '#475569',
        accent: '#2563EB',
        background: '#F8FAFC',
        surface: '#FFFFFF',
        text: '#0F172A',
      },
      typography: {
        displayFont: 'Plus Jakarta Sans (Bold)',
        bodyFont: 'Plus Jakarta Sans (Regular)',
        reason: 'Exceptional digital clarity, tight tracking for headlines, and high legibility across mobile displays.',
      },
      spacingAndBorder: '1px hairline borders, 12px unified border-radius, generous whitespace padding.',
    },
    recommendedSections: [
      {
        sectionName: 'Focal Hero Section',
        purpose: 'Convey core value proposition immediately with frictionless primary action',
        wireframeLayout: 'Balanced 2-column split with headline & CTA on start, high-impact product render on end',
        keyElements: ['Direct benefit-led headline', 'Single outcome-driven CTA', 'Inline trust indicators'],
      },
      {
        sectionName: 'Asymmetric Bento Grid of Capabilities',
        purpose: 'Showcase marquee services with visual clarity and outcome metrics',
        wireframeLayout: 'Dynamic col-span-2 and col-span-1 cards with subtle surface tint',
        keyElements: ['3 key offerings', 'Concrete deliverable descriptions', 'Outcome KPIs'],
      },
      {
        sectionName: 'Interactive Before/After Proof Section',
        purpose: 'Remove cognitive friction and substantiate return on investment',
        wireframeLayout: 'Interactive slider comparing legacy layout versus redesigned architecture',
        keyElements: ['Interactive split handle', 'Quantified performance metrics'],
      },
      {
        sectionName: 'Frictionless Inquiry Form',
        purpose: 'Maximize lead capture with validated minimal fields',
        wireframeLayout: 'Focused single-step card with real-time feedback',
        keyElements: ['3 essential inputs', 'Instant confirmation message'],
      },
    ],
    clientProposalPitch: {
      executiveSummary: `The current ${name} website contains strong baseline value, but legacy styling and conversion friction limit business growth. This redesign elevates brand positioning to industry leadership while streamlining the buyer journey.`,
      roiJustification: 'Projected 35-50% reduction in bounce rate, 2x increase in mobile form completions, and professional positioning.',
      estimatedPhases: [
        {
          phase: 'Phase 1: Discovery, IA & Wireframing',
          duration: '1-2 weeks',
          deliverables: ['Sitemap & Information Architecture', 'User Journey Maps', 'Interactive Low-Fi Wireframes'],
        },
        {
          phase: 'Phase 2: High-Fi UI & Design System in Figma',
          duration: '2 weeks',
          deliverables: ['Comprehensive Design System & Tokens', 'Desktop & Mobile Master Screens', 'Interactive Clickable Prototype'],
        },
        {
          phase: 'Phase 3: Production Development & Optimization',
          duration: '2-3 weeks',
          deliverables: ['Production-grade clean codebase', 'Full responsive testing', 'Core Web Vitals sub-1.5s optimization'],
        },
        {
          phase: 'Phase 4: QA, Handoff & Launch',
          duration: '1 week',
          deliverables: ['Cross-browser validation', 'CMS training / documentation', 'Live deployment & analytics hookup'],
        },
      ],
    },
  };
}

// Redesign Analysis API Endpoint
app.post('/api/redesign/analyze', async (req, res) => {
  try {
    const { clientName, websiteUrl, industry, targetAudience, primaryGoals, currentPainPoints, notes, language } = req.body;
    const isFa = language !== 'en';

    if (!ai) {
      // Fallback if no API key configured
      const fallback = generateFallbackAnalysis({
        clientName,
        websiteUrl,
        industry,
        targetAudience,
        primaryGoals,
        currentPainPoints,
        language,
      });
      return res.json({ success: true, data: fallback, source: 'heuristic' });
    }

    const promptText = `
You are a world-class senior UX/UI design consultant and web strategist.
Analyze the following website redesign project and produce a comprehensive, realistic redesign blueprint.

Client / Project Name: ${clientName || 'Not specified'}
Website URL: ${websiteUrl || 'Not specified'}
Industry: ${industry || 'Business'}
Target Audience: ${targetAudience || 'Target customers'}
Primary Goals for Redesign: ${Array.isArray(primaryGoals) ? primaryGoals.join(', ') : primaryGoals}
Current Weaknesses / Pain Points: ${Array.isArray(currentPainPoints) ? currentPainPoints.join(', ') : currentPainPoints}
Additional Notes: ${notes || 'None'}
Requested Language: ${isFa ? 'Persian (Farsi)' : 'English'}

Provide a strict JSON response following this structure:
{
  "brandPersonality": {
    "tone": "string describing the tone",
    "attributes": ["array", "of", "4", "personality", "keywords"]
  },
  "uxUiAudit": [
    {
      "issue": "Specific UX/UI issue in current site",
      "severity": "high | medium | low",
      "impact": "Concrete business or user impact",
      "recommendation": "Exact design solution to resolve it"
    }
  ],
  "conversionStrategy": {
    "headlineImprovement": "A powerful, modern rewritten hero headline",
    "primaryCtaRecommendation": "Specific high-intent button text",
    "secondaryCtaRecommendation": "Supporting secondary action text",
    "trustSignals": ["3 trust proofs or guarantees"]
  },
  "recommendedDesignSystem": {
    "styleName": "Design style name (e.g. Modern Minimalist, Luxury Editorial, Clean Tech SaaS)",
    "colorPalette": {
      "primary": "#hex",
      "secondary": "#hex",
      "accent": "#hex",
      "background": "#hex",
      "surface": "#hex",
      "text": "#hex"
    },
    "typography": {
      "displayFont": "Font family name",
      "bodyFont": "Font family name",
      "reason": "Why this font pairing fits this brand"
    },
    "spacingAndBorder": "Description of border radius, hairline borders, and layout rhythm"
  },
  "recommendedSections": [
    {
      "sectionName": "Name of page section",
      "purpose": "Why this section exists",
      "wireframeLayout": "Description of layout structure",
      "keyElements": ["Element 1", "Element 2", "Element 3"]
    }
  ],
  "clientProposalPitch": {
    "executiveSummary": "Compelling executive summary explaining the necessity and strategic value of the redesign",
    "roiJustification": "Specific business return on investment justification",
    "estimatedPhases": [
      {
        "phase": "Phase title",
        "duration": "Estimated timeline",
        "deliverables": ["Deliverable 1", "Deliverable 2", "Deliverable 3"]
      }
    ]
  }
}

Ensure all text is written in natural, professional ${isFa ? 'Persian (Farsi)' : 'English'} without buzzword fluff.
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: promptText,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const text = response.text;
    if (!text) {
      throw new Error('Empty response from AI model');
    }

    const parsed = JSON.parse(text);
    return res.json({ success: true, data: parsed, source: 'gemini' });
  } catch (error) {
    console.error('Redesign analysis error:', error);
    // Graceful fallback to heuristic analysis
    const fallback = generateFallbackAnalysis({
      clientName: req.body.clientName,
      websiteUrl: req.body.websiteUrl,
      industry: req.body.industry,
      targetAudience: req.body.targetAudience,
      primaryGoals: req.body.primaryGoals,
      currentPainPoints: req.body.currentPainPoints,
      language: req.body.language,
    });
    return res.json({ success: true, data: fallback, source: 'fallback_error', error: String(error) });
  }
});

// Copywriting Assistant Endpoint
app.post('/api/redesign/generate-copy', async (req, res) => {
  try {
    const { businessName, industry, sectionType, targetAction, language } = req.body;
    const isFa = language !== 'en';

    if (!ai) {
      if (isFa) {
        return res.json({
          headlines: [
            `تجربه نوین در ارائه خدمات ${industry || 'تخصصی'} با ${businessName || 'ما'}`,
            `کیفیت و سرعتی که کسب‌وکار شما شایسته آن است`,
            `تبدیل ایده‌ها به دستاوردهای ماندگار با استانداردهای جهانی`,
          ],
          ctas: ['ثبت درخواست مشاوره رایگان', 'شروع همکاری در چند دقیقه', 'مشاهده تعرفه‌ها و بسته‌ها'],
        });
      }
      return res.json({
        headlines: [
          `Transforming ${industry || 'digital solutions'} for ambitious organizations`,
          `High-performance infrastructure built for sustainable scale`,
          `Deliver exceptional customer experiences with precision`,
        ],
        ctas: ['Schedule Strategic Discovery', 'Request Custom Quote', 'Explore Interactive Demo'],
      });
    }

    const promptText = `
Write 3 compelling headlines and 3 high-converting action button labels for a redesigned website section:
Business Name: ${businessName || 'Business'}
Industry: ${industry || 'Services'}
Section Type: ${sectionType || 'Hero'}
Target User Action: ${targetAction || 'Inquiry/Purchase'}
Language: ${isFa ? 'Persian (Farsi)' : 'English'}

Return strict JSON:
{
  "headlines": ["Headline 1", "Headline 2", "Headline 3"],
  "ctas": ["CTA 1", "CTA 2", "CTA 3"]
}
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: promptText,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    return res.json(parsed);
  } catch (err) {
    console.error('Copywriting error:', err);
    return res.status(500).json({ error: 'Failed to generate copy' });
  }
});

// Invoice Email Notification for Orders (ارسال خودکار ایمیل فاکتور به مدیر)
app.post('/api/orders/send-invoice-email', async (req, res) => {
  try {
    const { order, managerEmail, smtpConfig } = req.body;
    if (!order) {
      return res.status(400).json({ error: 'Order details required' });
    }

    const recipient = managerEmail || process.env.MANAGER_EMAIL || 'info@pishgams.com';
    const host = smtpConfig?.host || process.env.SMTP_HOST || 'mail.pishgams.com';
    const portNum = Number(smtpConfig?.port || process.env.SMTP_PORT || 465);
    const user = smtpConfig?.user || process.env.SMTP_USER;
    const pass = smtpConfig?.pass || process.env.SMTP_PASS;

    const itemsHtml = (order.items || [])
      .map(
        (it: any) => `
        <tr style="border-bottom: 1px solid #e2e8f0;">
          <td style="padding: 10px; font-family: Tahoma, sans-serif; text-align: right;">${it.product?.name || 'کالا'} (${it.product?.model || '-'})</td>
          <td style="padding: 10px; font-family: Tahoma, sans-serif; text-align: center;">${it.quantity}</td>
          <td style="padding: 10px; font-family: Tahoma, sans-serif; text-align: left;">${Number(it.product?.price || 0).toLocaleString('fa-IR')} تومان</td>
          <td style="padding: 10px; font-family: Tahoma, sans-serif; text-align: left;">${(Number(it.product?.price || 0) * it.quantity).toLocaleString('fa-IR')} تومان</td>
        </tr>
      `
      )
      .join('');

    const invoiceHtml = `
      <div dir="rtl" style="font-family: Tahoma, 'Segoe UI', sans-serif; max-width: 650px; margin: 0 auto; background: #ffffff; border: 1px solid #cbd5e1; border-radius: 12px; overflow: hidden; color: #1e293b;">
        <div style="background: #e11d48; color: #ffffff; padding: 20px; text-align: center;">
          <h2 style="margin: 0; font-size: 20px;">پیشگام صنعت اهواز - فاکتور ثبت سفارش جدید</h2>
          <p style="margin: 6px 0 0; font-size: 13px; opacity: 0.9;">سفارش جدید در وب‌سایت pishgams.com ثبت گردید</p>
        </div>
        
        <div style="padding: 24px;">
          <div style="display: flex; justify-content: space-between; margin-bottom: 20px; background: #f8fafc; padding: 12px; border-radius: 8px;">
            <div><strong>کد رهگیری:</strong> <span style="color: #e11d48;">${order.trackingCode || order.id}</span></div>
            <div><strong>تاریخ:</strong> ${new Date().toLocaleDateString('fa-IR')}</div>
          </div>

          <h3 style="font-size: 15px; border-bottom: 2px solid #e11d48; padding-bottom: 6px; margin-top: 0;">اطلاعات خریدار</h3>
          <p style="margin: 6px 0; font-size: 13px;"><strong>نام مشتری:</strong> ${order.customerName || '-'}</p>
          <p style="margin: 6px 0; font-size: 13px;"><strong>شماره تماس:</strong> ${order.customerPhone || '-'}</p>
          <p style="margin: 6px 0; font-size: 13px;"><strong>شهر و آدرس:</strong> ${order.city || '-'} - ${order.address || '-'}</p>
          <p style="margin: 6px 0; font-size: 13px;"><strong>روش پرداخت:</strong> ${order.paymentMethod === 'snapp_pay' ? 'اقساط ۴ ماهه اسنپ‌پی' : order.paymentMethod === 'installment_in_person' ? 'اقساط با چک صیادی (حضوری اهواز)' : 'پرداخت آنلاین سامان'}</p>

          <h3 style="font-size: 15px; border-bottom: 2px solid #e11d48; padding-bottom: 6px; margin-top: 24px;">اقلام فاکتور</h3>
          <table style="width: 100%; border-collapse: collapse; font-size: 13px; margin-top: 10px;">
            <thead>
              <tr style="background: #f1f5f9;">
                <th style="padding: 10px; text-align: right;">شرح کالا</th>
                <th style="padding: 10px; text-align: center;">تعداد</th>
                <th style="padding: 10px; text-align: left;">فی (تومان)</th>
                <th style="padding: 10px; text-align: left;">مجموع (تومان)</th>
              </tr>
            </thead>
            <tbody>
              ${itemsHtml}
            </tbody>
            <tfoot>
              <tr style="background: #fff1f2; font-weight: bold; font-size: 14px;">
                <td colspan="3" style="padding: 12px; text-align: right;">مبلغ کل نهایی سفارش:</td>
                <td style="padding: 12px; text-align: left; color: #be123c;">${Number(order.totalAmount || 0).toLocaleString('fa-IR')} تومان</td>
              </tr>
            </tfoot>
          </table>

          <div style="margin-top: 30px; padding: 12px; background: #f8fafc; border-radius: 8px; font-size: 12px; color: #64748b; text-align: center;">
            این ایمیل به صورت خودکار از پرتال فروشگاهی پیشگام صنعت اهواز (pishgams.com) ارسال شده است.
          </div>
        </div>
      </div>
    `;

    // If SMTP credentials are provided, send real email via transporter
    if (user && pass) {
      const transporter = nodemailer.createTransport({
        host,
        port: portNum,
        secure: portNum === 465,
        auth: { user, pass },
      });

      await transporter.sendMail({
        from: `"پیشگام صنعت اهواز" <${user}>`,
        to: recipient,
        subject: `[سفارش جدید #${order.trackingCode || order.id}] - ${order.customerName}`,
        html: invoiceHtml,
      });

      return res.json({ success: true, message: `فاکتور با موفقیت به ایمیل ${recipient} ارسال شد.` });
    }

    // Otherwise return success simulation with full HTML preview
    return res.json({
      success: true,
      simulated: true,
      recipient,
      message: `فاکتور آماده ارسال به ${recipient} است (به محض وارد شدن اطلاعات SMTP ارسال زنده انجام می‌شود).`,
      previewHtml: invoiceHtml,
    });
  } catch (err: any) {
    console.error('Invoice email error:', err);
    return res.status(500).json({ error: err.message || 'خطا در ارسال ایمیل فاکتور' });
  }
});

// Setup Vite Dev Server / Static Hosting
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${port}`);
  });
}

startServer();
