export type Language = 'fa' | 'en';

export type IndustryType = 
  | 'ecommerce'
  | 'corporate_b2b'
  | 'medical_clinic'
  | 'education_tech'
  | 'hospitality_restaurant'
  | 'real_estate'
  | 'creative_agency'
  | 'personal_portfolio';

export interface AuditItem {
  issue: string;
  severity: 'high' | 'medium' | 'low';
  impact: string;
  recommendation: string;
}

export interface ColorPalette {
  primary: string;
  secondary: string;
  accent: string;
  background: string;
  surface: string;
  text: string;
}

export interface DesignSystem {
  styleName: string;
  colorPalette: ColorPalette;
  typography: {
    displayFont: string;
    bodyFont: string;
    reason: string;
  };
  spacingAndBorder: string;
}

export interface SectionWireframe {
  sectionName: string;
  purpose: string;
  wireframeLayout: string;
  keyElements: string[];
}

export interface ProjectPhase {
  phase: string;
  duration: string;
  deliverables: string[];
}

export interface ProposalPitch {
  executiveSummary: string;
  roiJustification: string;
  estimatedPhases: ProjectPhase[];
}

export interface RedesignProject {
  id: string;
  clientName: string;
  websiteUrl: string;
  industry: IndustryType;
  industryLabel: string;
  targetAudience: string;
  primaryGoals: string[];
  currentPainPoints: string[];
  notes?: string;
  budgetEstimate?: string;
  currency?: string;
  createdAt: string;
  analysis?: {
    brandPersonality: {
      tone: string;
      attributes: string[];
    };
    uxUiAudit: AuditItem[];
    conversionStrategy: {
      headlineImprovement: string;
      primaryCtaRecommendation: string;
      secondaryCtaRecommendation?: string;
      trustSignals: string[];
    };
    recommendedDesignSystem: DesignSystem;
    recommendedSections: SectionWireframe[];
    clientProposalPitch: ProposalPitch;
  };
}
