import React, { useState } from 'react';
import { PishgamStore } from './components/PishgamStore';
import { BeforeAfterSlider } from './components/BeforeAfterSlider';
import { ProposalView } from './components/ProposalView';
import { SAMPLE_PROJECTS } from './data/caseStudies';
import { X, ArrowRight } from 'lucide-react';

export default function App() {
  const [activeModal, setActiveModal] = useState<'none' | 'beforeAfter' | 'proposal'>('none');
  const project = SAMPLE_PROJECTS[0]; // pishgams.com

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 font-sans selection:bg-blue-600 selection:text-white">
      {/* 
        The Standalone Redesigned Website of Pishgam Sanat (pishgams.com) 
        Loaded directly as the primary experience with real Shopping Cart, 
        Clean Latin numerals, and instant RFQ engine!
      */}
      <PishgamStore
        language="fa"
        onOpenBeforeAfter={() => setActiveModal('beforeAfter')}
        onOpenProposal={() => setActiveModal('proposal')}
      />

      {/* Optional Overlay 1: Interactive Before & After Visualizer */}
      {activeModal === 'beforeAfter' && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-6xl max-h-[92vh] overflow-y-auto p-6 space-y-6 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                مقایسه سایت قبلی ووردپرسی در برابر سایت جدید بازطراحی‌شده پیشگام صنعت
              </h2>
              <button
                onClick={() => setActiveModal('none')}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <BeforeAfterSlider project={project} language="fa" />
          </div>
        </div>
      )}

      {/* Optional Overlay 2: Formal Client Redesign Proposal */}
      {activeModal === 'proposal' && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-5xl max-h-[92vh] overflow-y-auto p-6 space-y-6 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                پروپوزال رسمی بازطراحی برای ارائه و امضای مدیریت پیشگام صنعت
              </h2>
              <button
                onClick={() => setActiveModal('none')}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <ProposalView project={project} language="fa" />
          </div>
        </div>
      )}
    </div>
  );
}
