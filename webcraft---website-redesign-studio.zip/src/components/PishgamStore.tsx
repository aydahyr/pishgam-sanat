import React, { useState, useEffect } from 'react';
import { 
  Search, ShoppingCart, CheckCircle2, ShieldCheck, ArrowRight, Download, 
  Layers, Scale, Eye, Phone, MapPin, Printer, X, Wrench, Zap, Cpu, Plus, 
  Minus, Trash2, CreditCard, Truck, User, ArrowLeft, Edit3, Settings, Check, 
  FileText, Palette, Award, ExternalLink, ShieldAlert, Sparkles, AlertTriangle,
  Copy, Gift, Tag, LayoutDashboard, Lock, Unlock, LogOut, Key, Type,
  Building, ChevronLeft, ChevronRight, Clock, HelpCircle, Receipt,
  Smartphone, MessageSquare, Send, Package, Flame, Timer, Play, Pause
} from 'lucide-react';
import { Language } from '../types/redesign';
import { AdminPanelModal, AdminOrder, BannerSlide, SpecialOfferItem, SpecialOffersConfig } from './AdminPanelModal';

// =========================================================================
// OFFICIAL VISUAL LOGOS: SNAPP PAY & TOROB PAY (لوگوهای ارسالی و رسمی کاربر)
// =========================================================================
export const SnappPayLogo: React.FC<{ className?: string; showTagline?: boolean; badgeStyle?: boolean }> = ({ 
  className = "h-auto", 
  showTagline = true,
  badgeStyle = false,
}) => (
  <div className={`inline-flex items-center gap-2.5 rounded-2xl p-1.5 transition-all shadow-xs group ${badgeStyle ? 'bg-white text-slate-900 border border-slate-200' : 'bg-slate-900/95 border border-sky-500/50 hover:border-sky-400'} ${className}`}>
    <div className="bg-white rounded-xl px-2 py-1 flex items-center justify-center shrink-0 border border-slate-200 shadow-2xs h-8 sm:h-9">
      <img
        src="/public/assets/aistudio/_____e54e8233.png"
        alt="لوگوی رسمی اسنپ‌پی Snapp! Pay"
        className="h-6 sm:h-7 w-auto object-contain"
        onError={(e) => {
          (e.target as HTMLImageElement).src = '/public/snapp-pay-official.png';
        }}
      />
    </div>
    {showTagline && (
      <div className="text-right leading-tight pe-1">
        <div className="text-[11px] font-black text-sky-400 flex items-center gap-1">
          <span>اسنپ‌پی (Snapp! Pay)</span>
          <span className="text-[9px] px-1 py-0.2 rounded bg-sky-500/20 text-sky-300 font-bold">رسمی</span>
        </div>
        <div className="text-[10px] text-slate-300 font-medium">خرید اقساطی ۴ ماهه بدون چک و ضامن</div>
      </div>
    )}
  </div>
);

export type ThemePalette = 
  | 'red_black' 
  | 'light_clean' 
  | 'navy_blue' 
  | 'amber_graphite' 
  | 'emerald_slate'
  | 'caterpillar_yellow'
  | 'cyan_tech'
  | 'orange_safety';

interface ThemeConfig {
  id: ThemePalette;
  nameFa: string;
  dotColor: string;
  isLight?: boolean;
  bgCanvas: string;
  bgSurface: string;
  bgCard: string;
  borderPrimary: string;
  borderSecondary?: string;
  textHeading: string;
  textBody: string;
  textMuted: string;
  cardBorder: string;
  innerBg: string;
  accentBtn: string;
  accentBtnHover: string;
  accentText: string;
  accentBadgeBg: string;
  accentBadgeText: string;
  accentBadgeBorder: string;
  logoBg: string;
  tickerBg: string;
  tickerBorder: string;
}

const THEMES: Record<ThemePalette, ThemeConfig> = {
  red_black: {
    id: 'red_black',
    nameFa: 'قرمز، مشکی و طوسی صنعتی (درخواستی)',
    dotColor: '#ef4444',
    isLight: false,
    bgCanvas: 'bg-[#0a0a0c]',
    bgSurface: 'bg-[#121216]',
    bgCard: 'bg-[#17171d]',
    borderPrimary: 'border-zinc-800',
    borderSecondary: 'border-zinc-900',
    textHeading: 'text-white',
    textBody: 'text-slate-300',
    textMuted: 'text-slate-400',
    cardBorder: 'border-zinc-800',
    innerBg: 'bg-black/50',
    accentBtn: 'bg-rose-600 hover:bg-rose-500 text-white',
    accentBtnHover: 'hover:bg-rose-500',
    accentText: 'text-rose-500',
    accentBadgeBg: 'bg-rose-950/70',
    accentBadgeText: 'text-rose-300',
    accentBadgeBorder: 'border-rose-800/80',
    logoBg: 'bg-rose-600 text-white',
    tickerBg: 'bg-[#160b0e]',
    tickerBorder: 'border-rose-950',
  },
  light_clean: {
    id: 'light_clean',
    nameFa: 'تم روشن مهندسی (سفید، نقره‌ای و قرمز)',
    dotColor: '#ffffff',
    isLight: true,
    bgCanvas: 'bg-slate-100',
    bgSurface: 'bg-white',
    bgCard: 'bg-white',
    borderPrimary: 'border-slate-200',
    borderSecondary: 'border-slate-100',
    textHeading: 'text-slate-900',
    textBody: 'text-slate-700',
    textMuted: 'text-slate-500',
    cardBorder: 'border-slate-200',
    innerBg: 'bg-slate-50',
    accentBtn: 'bg-rose-600 hover:bg-rose-700 text-white shadow-xs',
    accentBtnHover: 'hover:bg-rose-700',
    accentText: 'text-rose-600',
    accentBadgeBg: 'bg-rose-50',
    accentBadgeText: 'text-rose-700',
    accentBadgeBorder: 'border-rose-200',
    logoBg: 'bg-white text-rose-600',
    tickerBg: 'bg-slate-900',
    tickerBorder: 'border-slate-800',
  },
  navy_blue: {
    id: 'navy_blue',
    nameFa: 'سرمه‌ای متالیک و آبی صنعتی',
    dotColor: '#3b82f6',
    isLight: false,
    bgCanvas: 'bg-[#0b0f19]',
    bgSurface: 'bg-[#0f172a]',
    bgCard: 'bg-[#131d35]',
    borderPrimary: 'border-slate-800',
    borderSecondary: 'border-slate-900',
    textHeading: 'text-white',
    textBody: 'text-slate-300',
    textMuted: 'text-slate-400',
    cardBorder: 'border-slate-800',
    innerBg: 'bg-black/50',
    accentBtn: 'bg-blue-600 hover:bg-blue-500 text-white',
    accentBtnHover: 'hover:bg-blue-500',
    accentText: 'text-blue-400',
    accentBadgeBg: 'bg-blue-950/70',
    accentBadgeText: 'text-blue-300',
    accentBadgeBorder: 'border-blue-800/80',
    logoBg: 'bg-blue-600 text-white',
    tickerBg: 'bg-[#0a192f]',
    tickerBorder: 'border-blue-950',
  },
  amber_graphite: {
    id: 'amber_graphite',
    nameFa: 'مشکی مات و طلایی کالیبراسیون',
    dotColor: '#f59e0b',
    isLight: false,
    bgCanvas: 'bg-[#0b0c0e]',
    bgSurface: 'bg-[#131518]',
    bgCard: 'bg-[#1a1c22]',
    borderPrimary: 'border-neutral-800',
    borderSecondary: 'border-neutral-900',
    textHeading: 'text-white',
    textBody: 'text-slate-300',
    textMuted: 'text-slate-400',
    cardBorder: 'border-neutral-800',
    innerBg: 'bg-black/50',
    accentBtn: 'bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold',
    accentBtnHover: 'hover:bg-amber-400',
    accentText: 'text-amber-400',
    accentBadgeBg: 'bg-amber-950/70',
    accentBadgeText: 'text-amber-300',
    accentBadgeBorder: 'border-amber-800/80',
    logoBg: 'bg-amber-500 text-slate-950',
    tickerBg: 'bg-[#161208]',
    tickerBorder: 'border-amber-950',
  },
  emerald_slate: {
    id: 'emerald_slate',
    nameFa: 'سبز زمردی و دودی آزمایشگاهی',
    dotColor: '#10b981',
    isLight: false,
    bgCanvas: 'bg-[#0c1015]',
    bgSurface: 'bg-[#131820]',
    bgCard: 'bg-[#19222c]',
    borderPrimary: 'border-slate-800',
    borderSecondary: 'border-slate-900',
    textHeading: 'text-white',
    textBody: 'text-slate-300',
    textMuted: 'text-slate-400',
    cardBorder: 'border-slate-800',
    innerBg: 'bg-black/50',
    accentBtn: 'bg-emerald-600 hover:bg-emerald-500 text-white',
    accentBtnHover: 'hover:bg-emerald-500',
    accentText: 'text-emerald-400',
    accentBadgeBg: 'bg-emerald-950/70',
    accentBadgeText: 'text-emerald-300',
    accentBadgeBorder: 'border-emerald-800/80',
    logoBg: 'bg-emerald-600 text-white',
    tickerBg: 'bg-[#081812]',
    tickerBorder: 'border-emerald-950',
  },
  caterpillar_yellow: {
    id: 'caterpillar_yellow',
    nameFa: 'زرد کاترپیلار و نوک‌مدادی (Fluke / ابزار دقیق)',
    dotColor: '#eab308',
    isLight: false,
    bgCanvas: 'bg-[#0c0d10]',
    bgSurface: 'bg-[#14151a]',
    bgCard: 'bg-[#1b1d24]',
    borderPrimary: 'border-zinc-800',
    borderSecondary: 'border-zinc-900',
    textHeading: 'text-white',
    textBody: 'text-slate-300',
    textMuted: 'text-slate-400',
    cardBorder: 'border-zinc-800',
    innerBg: 'bg-black/50',
    accentBtn: 'bg-yellow-500 hover:bg-yellow-400 text-slate-950 font-black shadow-xs',
    accentBtnHover: 'hover:bg-yellow-400',
    accentText: 'text-yellow-400',
    accentBadgeBg: 'bg-yellow-950/70',
    accentBadgeText: 'text-yellow-300',
    accentBadgeBorder: 'border-yellow-700/80',
    logoBg: 'bg-yellow-500 text-slate-950',
    tickerBg: 'bg-[#141206]',
    tickerBorder: 'border-yellow-950',
  },
  cyan_tech: {
    id: 'cyan_tech',
    nameFa: 'سیان نئون و آبی کاربنی (کالیبراسیون و آزمایشگاه)',
    dotColor: '#06b6d4',
    isLight: false,
    bgCanvas: 'bg-[#080d14]',
    bgSurface: 'bg-[#0d1522]',
    bgCard: 'bg-[#121e30]',
    borderPrimary: 'border-cyan-950',
    borderSecondary: 'border-slate-900',
    textHeading: 'text-white',
    textBody: 'text-slate-300',
    textMuted: 'text-slate-400',
    cardBorder: 'border-cyan-900/40',
    innerBg: 'bg-black/50',
    accentBtn: 'bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold shadow-xs',
    accentBtnHover: 'hover:bg-cyan-400',
    accentText: 'text-cyan-400',
    accentBadgeBg: 'bg-cyan-950/70',
    accentBadgeText: 'text-cyan-300',
    accentBadgeBorder: 'border-cyan-800/80',
    logoBg: 'bg-cyan-500 text-slate-950',
    tickerBg: 'bg-[#06121e]',
    tickerBorder: 'border-cyan-950',
  },
  orange_safety: {
    id: 'orange_safety',
    nameFa: 'نارنجی ایمنی صنعتی و مشکی مات (نفت و گاز)',
    dotColor: '#f97316',
    isLight: false,
    bgCanvas: 'bg-[#0d0b0a]',
    bgSurface: 'bg-[#171412]',
    bgCard: 'bg-[#201c18]',
    borderPrimary: 'border-orange-950/70',
    borderSecondary: 'border-neutral-900',
    textHeading: 'text-white',
    textBody: 'text-slate-300',
    textMuted: 'text-slate-400',
    cardBorder: 'border-orange-900/30',
    innerBg: 'bg-black/50',
    accentBtn: 'bg-orange-600 hover:bg-orange-500 text-white font-bold shadow-xs',
    accentBtnHover: 'hover:bg-orange-500',
    accentText: 'text-orange-400',
    accentBadgeBg: 'bg-orange-950/70',
    accentBadgeText: 'text-orange-300',
    accentBadgeBorder: 'border-orange-800/80',
    logoBg: 'bg-orange-600 text-white',
    tickerBg: 'bg-[#180e07]',
    tickerBorder: 'border-orange-950',
  },
};

export interface ProductItem {
  id: string;
  name: string;
  model: string;
  brand: 'UNI-T' | 'Mastech' | 'Kyoritsu' | 'Fluke' | 'Pishgam';
  category: 'multimeter' | 'megger' | 'thermal' | 'hydraulic' | 'calibrator';
  categoryLabelFa: string;
  price: number;
  inStock: boolean;
  specs: {
    voltageRange: string;
    accuracy: string;
    safetyRating: string;
    feature: string;
  };
  datasheetUrl: string;
  image: string;
}

const PRODUCTS: ProductItem[] = [
  {
    id: 'p1',
    name: 'مولتی‌متر دیجیتال صنعتی True RMS',
    model: 'UNI-T UT61E+',
    brand: 'UNI-T',
    category: 'multimeter',
    categoryLabelFa: 'مولتی‌متر و کلمپ',
    price: 6850000,
    inStock: true,
    specs: {
      voltageRange: '1000V AC/DC',
      accuracy: '±(0.05%+2)',
      safetyRating: 'CAT III 1000V / CAT IV 600V',
      feature: 'شمارنده 22,000 رقم، پورت اتصال به کامپیوتر',
    },
    datasheetUrl: '#datasheet-ut61e',
    image: '/src/assets/images/multimeter_digital_unit_1794071576297.jpg',
  },
  {
    id: 'p2',
    name: 'کلمپ آمپرمتر دیجیتال AC/DC پرتابل',
    model: 'MASTECH MS2108',
    brand: 'Mastech',
    category: 'multimeter',
    categoryLabelFa: 'مولتی‌متر و کلمپ',
    price: 4950000,
    inStock: true,
    specs: {
      voltageRange: '600V AC/DC - 400A',
      accuracy: '±(2.0%+5)',
      safetyRating: 'CAT III 600V',
      feature: 'سنجش جریان هجومی (Inrush Current)، نور نمایشگر',
    },
    datasheetUrl: '#datasheet-ms2108',
    image: '/src/assets/images/clamp_meter_multimeter_1794071608967.jpg',
  },
  {
    id: 'p3',
    name: 'میگر و تستر عایق کابل ولتاژ بالا',
    model: 'Kyoritsu 3005A',
    brand: 'Kyoritsu',
    category: 'megger',
    categoryLabelFa: 'میگر و عایق‌سنج',
    price: 24500000,
    inStock: true,
    specs: {
      voltageRange: '250V / 500V / 1000V',
      accuracy: 'مقاومت تا 2000MΩ',
      safetyRating: 'IEC 61010-1 CAT III 300V',
      feature: 'تست تداوم 20 و 200 اهم، بدنه تقویت‌شده ضد ضربه',
    },
    datasheetUrl: '#datasheet-k3005a',
    image: '/src/assets/images/megger_insulation_tester_1794071592640.jpg',
  },
  {
    id: 'p4',
    name: 'دوربین ترموویژن و تصویربردار حرارتی',
    model: 'UNI-T UTi260B',
    brand: 'UNI-T',
    category: 'thermal',
    categoryLabelFa: 'ترموویژن و حرارت‌سنج',
    price: 32000000,
    inStock: true,
    specs: {
      voltageRange: '-20°C to 550°C',
      accuracy: 'رزولوشن مادون قرمز 256x192',
      safetyRating: 'مقاوم در برابر سقوط از 2 متر',
      feature: 'فوکوس دستی، کارت حافظه میکرو، نرم‌افزار آنالیز',
    },
    datasheetUrl: '#datasheet-uti260b',
    image: '/src/assets/images/thermal_camera_infrared_1794071625759.jpg',
  },
  {
    id: 'p5',
    name: 'دستگاه پرس کابل‌شو هیدرولیک دستی',
    model: 'Pishgam HPO-400',
    brand: 'Pishgam',
    category: 'hydraulic',
    categoryLabelFa: 'ابزار کابل و هیدرولیک',
    price: 8900000,
    inStock: true,
    specs: {
      voltageRange: '16 to 400 mm²',
      accuracy: 'نیروی خروجی 16 تن با سوپاپ اطمینان',
      safetyRating: 'فک‌های فورج شده سخت‌کاری شده',
      feature: 'چرخش 360 درجه کلگی، کیف فلزی مقاوم',
    },
    datasheetUrl: '#datasheet-hpo400',
    image: '/src/assets/images/hydraulic_crimper_tool_1794071644814.jpg',
  },
  {
    id: 'p6',
    name: 'کالیبراتور فرآیندی لوپ جریان و ولتاژ',
    model: 'MASTECH MS7221',
    brand: 'Mastech',
    category: 'calibrator',
    categoryLabelFa: 'کالیبراتور ابزار دقیق',
    price: 18700000,
    inStock: true,
    specs: {
      voltageRange: '0-24mA & 0-10V Loop',
      accuracy: 'دقت 0.02% مقیاس کامل',
      safetyRating: 'ایمن در برابر اضافه ولتاژ',
      feature: 'تغذیه ترانسمیتر 24V، پله‌های 25% اتوماتیک',
    },
    datasheetUrl: '#datasheet-ms7221',
    image: '/src/assets/images/industrial_instruments_hero_1794067115735.jpg',
  },
];

// OFFICIAL REPRESENTATIONS / AGENCIES OF PISHGAM SANAT
export interface AgencyItem {
  id: string;
  name: string;
  country: string;
  role: string;
  description: string;
  badge: string;
  specialties: string[];
}

const DEFAULT_AGENCIES: AgencyItem[] = [
  {
    id: 'ag-unit',
    name: 'UNI-T (یونیتی)',
    country: 'چین - استاندارد بین‌المللی IEC',
    role: 'نمایندگی رسمی فروش و خدمات پس از فروش در خوزستان',
    description: 'بزرگ‌ترین سازنده مولتی‌مترهای صنعتی، اسیلوسکوپ و دوربین‌های تصویربرداری حرارتی',
    badge: 'نمایندگی انحصاری خوزستان',
    specialties: ['مولتی‌متر True RMS', 'کلمپ آمپرمتر', 'ترموویژن صنعتی'],
  },
  {
    id: 'ag-kyoritsu',
    name: 'KYORITSU (کیوریتسو)',
    country: 'ژاپن (Tokyo, Japan)',
    role: 'تأمین‌کننده مستقیم برای صنایع نفت، گاز و پتروشیمی',
    description: 'معتبرترین برند میگرهای ولتاژ بالا، پاورآنالایزرهای هارمونیک و نشت‌یاب جریان',
    badge: 'استاندارد ایمنی IEC ژاپن',
    specialties: ['میگرهای 1000V تا 5000V', 'پاور آنالایزر', 'تستر عایق کابل'],
  },
  {
    id: 'ag-mastech',
    name: 'MASTECH (مستک)',
    country: 'تایوان و هنگ‌کنگ',
    role: 'عامل مجاز توزیع و کالیبراسیون رسمی',
    description: 'پیشرو در طراحی تجهیزات کالیبراتور فرآیندی، ارت‌سنج و ابزارهای سنجش تاسیسات برق',
    badge: 'تضمین کالیبراسیون رسمی',
    specialties: ['کالیبراتور لوپ', 'میگر عایق‌سنج', 'تسترهای محیطی'],
  },
  {
    id: 'ag-pishgam',
    name: 'PISHGAM TOOLS (ابزار پیشگام)',
    country: 'ایران - انبار مرکزی اهواز',
    role: 'تولید و خدمات ابزارهای هیدرولیک و کابل‌کشی',
    description: 'ساخت انواع پرس کابلشو هیدرولیک، قیچی کابل‌بر و پمپ‌های هیدرولیک فشار قوی',
    badge: 'تولید و پشتیبانی قطعات در اهواز',
    specialties: ['پرس هیدرولیک 16 تا 400', 'قیچی کابل‌بر آرموردار', 'پمپ هیدرولیک'],
  },
];

const AGENCY_PRESETS = [
  {
    title: 'برندهای مرجع برق و اندازه‌گیری اهواز (پیش‌فرض)',
    items: DEFAULT_AGENCIES,
  },
  {
    title: 'برندهای سطح اول نفت، گاز و پتروشیمی (Fluke, Hioki, Kyoritsu, Testo)',
    items: [
      {
        id: 'p-fluke',
        name: 'FLUKE (فلوک)',
        country: 'ایالات متحده آمریکا',
        role: 'تأمین کالیبراتورهای فرآیندی و ابزار دقیق مرجع',
        description: 'استاندارد طلایی تجهیزات ابزار دقیق و اندازه‌گیری فوق دقیق در پالایشگاه‌ها و صنایع نفت',
        badge: 'استاندارد مرجع کالیبراسیون',
        specialties: ['کالیبراتور 754 و 725', 'مولتی‌متر 87V', 'ترموویژن Fluke'],
      },
      {
        id: 'p-kyoritsu',
        name: 'KYORITSU (کیوریتسو)',
        country: 'ژاپن (Tokyo, Japan)',
        role: 'تأمین‌کننده مستقیم میگر و تستر عایق کابل',
        description: 'مطمئن‌ترین تسترها و میگرهای ولتاژ بالا در پست‌های انتقال و توزیع برق خوزستان',
        badge: 'استاندارد ایمنی CAT IV ژاپن',
        specialties: ['میگر 5000V دیجیتال', 'ارت‌سنج کلمپی', 'پاور آنالایزر'],
      },
      {
        id: 'p-hioki',
        name: 'HIOKI (هیوکی)',
        country: 'ژاپن (Nagano, Japan)',
        role: 'تأمین پاور آنالایزر و دیتالاگرهای مهندسی',
        description: 'پیشرو در فناوری آنالیز توان، دیتالاگرهای چندکاناله و تسترهای پیشرفته باتری و ارت',
        badge: 'تکنولوژی پیشرفته ژاپن',
        specialties: ['پاور آنالایزر PW3360', 'باتری‌تستر BT3554', 'کلمپ True RMS'],
      },
      {
        id: 'p-testo',
        name: 'TESTO (تستو)',
        country: 'آلمان (Lenzkirch, Germany)',
        role: 'تأمین آنالایزرهای احتراق و ترموویژن صنعتی',
        description: 'ابزارهای سنجش دما، رطوبت، سرعت باد و آنالیز گازهای خروجی نیروگاه‌ها',
        badge: 'دقت آزمایشگاهی آلمان',
        specialties: ['ترموویژن صنعتی Testo', 'آنالایزر گاز دودکش', 'ترمومتر لیزری'],
      },
    ],
  },
  {
    title: 'برندهای کارگاهی و تجاری پرفروش (UNI-T, Mastech, Lutron, CEM)',
    items: [
      {
        id: 'p-unit',
        name: 'UNI-T (یونیتی)',
        country: 'چین - استاندارد CE اروپا',
        role: 'نمایندگی رسمی و انحصاری استان خوزستان',
        description: 'پرفروش‌ترین ابزارهای تست شامل انواع مولتی‌متر، کلمپ و اسیلوسکوپ دیجیتال صنعتی',
        badge: 'گارانتی ۱۲ ماهه طلایی اهواز',
        specialties: ['مولتی‌متر UT61E+', 'کلمپ UT204+', 'اسیلوسکوپ رومیزی'],
      },
      {
        id: 'p-mastech',
        name: 'MASTECH (مستک)',
        country: 'تایوان و هنگ‌کنگ',
        role: 'توزیع عمده و تأمین کارگاهی',
        description: 'تجهیزات ارزان‌قیمت و باکیفیت مناسب برای کارگاه‌های تابلوسازی، تعمیرات و آموزشگاه‌ها',
        badge: 'قیمت رقابتی بدون واسطه',
        specialties: ['کلمپ MS2108A', 'ارت سنج MS2302', 'مولتی‌متر MS8268'],
      },
      {
        id: 'p-lutron',
        name: 'LUTRON (لوترون)',
        country: 'تایوان (Taipei, Taiwan)',
        role: 'تأمین دستگاه‌های سنجش فیزیکی و آزمایشگاهی',
        description: 'تخصصی‌ترین سنسورهای سرعت‌سنج باد، نورسنج، صداسنج، لرزش‌سنج و سختی‌سنج صنعتی',
        badge: 'سنجش‌های آزمایشگاهی دقیق',
        specialties: ['بادسنج پروانه‌ای', 'لوکس‌متر نوری', 'تاکومتر دورسنج'],
      },
      {
        id: 'p-cem',
        name: 'CEM Instruments (سم)',
        country: 'چین - استاندارد بین‌المللی',
        role: 'تأمین دوربین‌های حرارتی و تسترهای محیطی',
        description: 'سازنده دوربین‌های حرارتی اقتصادی، دیتالاگرهای دما و رطوبت و فاصله‌سنج‌های لیزری',
        badge: 'استاندارد IP67',
        specialties: ['دوربین حرارتی DT-980', 'ترمومتر نفوذی', 'ضخامت سنج رنگ'],
      },
    ],
  },
];

// =========================================================================
// DEFAULT HERO BANNERS (اسلایدر بنرهای متغیر و تایمردار)
// =========================================================================
const DEFAULT_BANNERS: BannerSlide[] = [
  {
    id: 'slide-1',
    badge: 'تأمین ملزومات برق صنعتی و صنایع پتروشیمی خوزستان',
    title: 'مرجع تخصصی تأمین ابزار دقیق و تجهیزات اندازه‌گیری با گواهی کالیبراسیون',
    description: 'توزیع مستقیم تجهیزات تست و اندازه‌گیری صنعتی، مولتی‌مترهای حرفه‌ای، میگر و کلمپ‌های UNI-T، مستک و کیوریتسو در انبار مرکزی اهواز همراه با پشتیبانی فنی و ارسال اکسپرس.',
    buttonText: 'مشاهده کاتالوگ تجهیزات',
    buttonLink: '#catalog',
    secondaryButtonText: 'شرایط خرید اقساطی با چک صیادی',
    secondaryButtonLink: '#installment',
    image: '/src/assets/images/industrial_instruments_hero_1794067115735.jpg',
    active: true,
    type: 'main',
  },
  {
    id: 'slide-2',
    badge: '⚡ محموله جدید ترخیص شد - انبار مرکزی اهواز',
    title: 'ورود جدیدترین مولتی‌مترها، کلمپ‌ها و ترموویژن‌های کالیبره‌شده ۲۰۲۶',
    description: 'تجهیزات فوق‌پیشرفته عایق‌سنجی، سنجش هارمونیک و آنالایزرهای صنعتی تازه رسیده، آماده تحویل فوری ۲۴ ساعته به شرکت‌ها و کارگاه‌های صنعتی سراسر خوزستان.',
    buttonText: 'بررسی مشخصات جدیدترین‌ها',
    buttonLink: '#catalog',
    secondaryButtonText: 'مشاوره فنی فوری اهواز',
    secondaryButtonLink: 'tel:06132230000',
    image: '/src/assets/images/multimeter_digital_unit_1794071576297.jpg',
    active: true,
    type: 'new_products',
  },
  {
    id: 'slide-3',
    badge: '🏆 اصالت ۱۰۰٪ قطعی با گارانتی طلایی اهواز',
    title: 'نمایندگی و توزیع رسمی برترین برندهای ابزار دقیق: FLUKE، HIOKI، UNI-T، KYORITSU و MASTECH',
    description: 'تأمین بدون واسطه با سرتیفیکیت کالیبراسیون رسمی معتبر در آزمایشگاه‌های مرجع نفت و پتروشیمی، به همراه خدمات فنی و پشتیبانی قطعات در اهواز.',
    buttonText: 'مشاهده لیست نمایندگی‌ها و گواهی‌ها',
    buttonLink: '#agencies',
    secondaryButtonText: 'تضمین اصالت کالا',
    secondaryButtonLink: '#agencies',
    image: '/src/assets/images/clamp_meter_multimeter_1794071608967.jpg',
    active: true,
    type: 'brands',
  },
];

// =========================================================================
// DEFAULT SPECIAL 24H OFFERS (پیشنهادات شگفت‌انگیز ۲۴ ساعته انبار اهواز)
// =========================================================================
const DEFAULT_SPECIAL_OFFERS: SpecialOffersConfig = {
  enabled: true,
  title: 'پیشنهادات شگفت‌انگیز ۲۴ ساعته انبار اهواز',
  subtitle: 'تخفیف ویژه محدود کارگاهی روی ملزومات پرتقاضای تست صنعتی با تحویل فوری ۲۴ ساعته در اهواز و سراسر خوزستان',
  durationHours: 24,
  targetEndTime: Date.now() + 24 * 60 * 60 * 1000,
  items: [
    {
      productId: 'p1', // مولتی‌متر True RMS
      discountPercent: 18,
      stockLeft: 3,
      customBadge: 'تخفیف شگفت‌انگیز ۲۴h',
    },
    {
      productId: 'p2', // کلمپ آمپرمتر
      discountPercent: 15,
      stockLeft: 2,
      customBadge: 'پیشنهاد محدود تکنسین',
    },
    {
      productId: 'p5', // پرس کابلشو هیدرولیک
      discountPercent: 20,
      stockLeft: 4,
      customBadge: 'تخفیف کارگاهی اهواز',
    },
  ],
};

// =========================================================================
// SLIDE 2: AUTO-CYCLING NEW PRODUCTS SHOWCASE (نمایش متغیر عکس جدیدترین محصولات)
// =========================================================================
const CYCLING_NEW_PRODUCTS = [
  {
    name: 'مولتی‌متر دیجیتال True RMS صنعتی',
    model: 'UNI-T UT61E+ Plus',
    brand: 'UNI-T',
    image: '/src/assets/images/multimeter_digital_unit_1794071576297.jpg',
    tag: '⚡ محموله جدید ۲۰۲۶',
    spec: 'دقت ۲۲,۰۰۰ کانت با پورت USB و کالیبراسیون رسمی',
    price: '۶,۲۰۰,۰۰۰ تومان',
  },
  {
    name: 'دوربین ترموویژن مادون قرمز مادربورد و تابلو',
    model: 'CEM DT-980 High Definition',
    brand: 'CEM',
    image: '/src/assets/images/thermal_camera_infrared_1794071625759.jpg',
    tag: '🔥 عیب‌یابی حرارتی لحظه‌ای',
    spec: 'رزولوشن حرارتی بالا و تشخیص اتصالات داغ در پست برق',
    price: '۲۴,۵۰۰,۰۰۰ تومان',
  },
  {
    name: 'کلمپ‌آمپرمتر جریان بالا True RMS',
    model: 'UNI-T UT204+ Industrial',
    brand: 'UNI-T',
    image: '/src/assets/images/clamp_meter_multimeter_1794071608967.jpg',
    tag: '🛠️ مناسب صنایع سنگین اهواز',
    spec: 'سنجش جریان AC/DC تا 600A و خازن‌سنجی دقیق',
    price: '۳,۴۵۰,۰۰۰ تومان',
  },
  {
    name: 'میگر و تستر عایق ولتاژ بالا 5000V',
    model: 'KYORITSU 3125A Japan',
    brand: 'Kyoritsu ژاپن',
    image: '/src/assets/images/megger_insulation_tester_1794071592640.jpg',
    tag: '🏭 ویژه پست‌های انتقال و توزیع',
    spec: 'تست عایق کابل‌های زمینی و ژنراتورهای پالایشگاهی',
    price: '۲۹,۸۰۰,۰۰۰ تومان',
  },
  {
    name: 'پرس کابلشو هیدرولیک صنعتی ۱۶ تا ۴۰۰',
    model: 'PISHGAM HPO-400',
    brand: 'Pishgam Tools',
    image: '/src/assets/images/hydraulic_crimper_tool_1794071644814.jpg',
    tag: '⚙️ قدرت ۱۶ تن با سوپاپ اطمینان',
    spec: 'فک‌های فورج شده سخت‌کاری شده و چرخش ۳۶۰ درجه',
    price: '۸,۹۰۰,۰۰۰ تومان',
  },
];

// =========================================================================
// SLIDE 3: AUTO-CYCLING LEADING BRANDS SHOWCASE (نمایش متغیر برندهای مطرح)
// =========================================================================
const CYCLING_BRANDS = [
  {
    name: 'FLUKE (فلوک)',
    origin: 'ایالات متحده آمریکا',
    role: 'استاندارد مرجع کالیبراسیون و آزمایشگاه‌های نفت و پتروشیمی',
    image: '/src/assets/images/industrial_instruments_hero_1794067115735.jpg',
    badge: 'استاندارد طلایی جهان',
    feature: 'کالیبراتورهای 754 و مولتی‌مترهای مرجع 87V',
  },
  {
    name: 'KYORITSU (کیوریتسو)',
    origin: 'توکیو، ژاپن',
    role: 'معتبرترین تسترها و میگرهای ولتاژ بالای انتقال نیرو',
    image: '/src/assets/images/megger_insulation_tester_1794071592640.jpg',
    badge: 'استاندارد ایمنی CAT IV ژاپن',
    feature: 'میگرهای دیجیتال 5000V و پاورآنالایزرهای هارمونیک',
  },
  {
    name: 'HIOKI (هیوکی)',
    origin: 'ناگانو، ژاپن',
    role: 'پیشرو در دیتالاگرهای مهندسی، آنالیز توان و تست باتری',
    image: '/src/assets/images/clamp_meter_multimeter_1794071608967.jpg',
    badge: 'تکنولوژی پیشرفته ژاپن',
    feature: 'پاور آنالایزرهای PW3360 و تسترهای صنعتی باتری',
  },
  {
    name: 'UNI-T (یونیتی)',
    origin: 'استاندارد بین‌المللی IEC',
    role: 'پرفروش‌ترین مولتی‌مترها و کلمپ‌های صنعتی خوزستان',
    image: '/src/assets/images/multimeter_digital_unit_1794071576297.jpg',
    badge: 'نمایندگی رسمی توزیع اهواز',
    feature: 'مولتی‌مترهای سری True RMS Plus و کلمپ‌های تخصصی',
  },
  {
    name: 'MASTECH (مستک)',
    origin: 'تایوان و هنگ‌کنگ',
    role: 'تجهیزات تخصصی کالیبراتور لوپ جریان و ارت‌سنج',
    image: '/src/assets/images/industrial_warehouse_hero_1794067115867.jpg',
    badge: 'تضمین کالیبراسیون رسمی',
    feature: 'کالیبراتورهای دقیق میلی‌آمپر و تستر تاسیسات برق',
  },
];

export const PishgamStore: React.FC<{
  language: Language;
  onOpenBeforeAfter?: () => void;
  onOpenProposal?: () => void;
}> = ({ language, onOpenBeforeAfter, onOpenProposal }) => {
  const isFa = language === 'fa';
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedBrand, setSelectedBrand] = useState<string>('all');

  // COLOR PALETTE (قفل شده روی تم صنعتی قرمز مشکی طوسی - انتخاب قطعی)
  const [activeTheme, setActiveTheme] = useState<ThemePalette>('red_black');
  const [showThemeMenu, setShowThemeMenu] = useState(false);

  const theme = THEMES[activeTheme];

  const handleSelectTheme = (newTheme: ThemePalette) => {
    setActiveTheme(newTheme);
    localStorage.setItem('pishgam_theme', newTheme);
    setShowThemeMenu(false);
  };

  // AUTHENTIC PERSIAN FONT (قفل شده روی فونت ساحل متین - انتخاب نهایی)
  const [activeFont, setActiveFont] = useState<'vazir' | 'shabnam' | 'sahel' | 'samim' | 'yekan' | 'system'>('sahel');

  const handleSelectFont = (newFont: 'vazir' | 'shabnam' | 'sahel' | 'samim' | 'yekan' | 'system') => {
    setActiveFont(newFont);
    localStorage.setItem('pishgam_font', newFont);
  };

  const currentFontClass = 'font-persian-sahel';

  // =========================================================================
  // DYNAMIC HERO BANNERS SLIDER STATE (اسلایدر بنرهای متغیر و تایمردار)
  // =========================================================================
  const [bannerSlides, setBannerSlides] = useState<BannerSlide[]>(() => {
    try {
      const saved = localStorage.getItem('pishgam_banners');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return DEFAULT_BANNERS;
  });

  const [bannerInterval, setBannerInterval] = useState<number>(() => {
    const saved = localStorage.getItem('pishgam_banner_interval');
    return saved ? Number(saved) : 8;
  });

  const activeSlides = bannerSlides.filter((s) => s.active);
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
  const [isBannerHovered, setIsBannerHovered] = useState(false);
  const [bannerProgress, setBannerProgress] = useState(0);

  // Auto-advance banner timer with progress tick
  useEffect(() => {
    if (activeSlides.length <= 1 || isBannerHovered) return;

    const intervalMs = Math.max(3000, bannerInterval * 1000);
    const stepMs = 100;
    let elapsed = 0;

    const timer = setInterval(() => {
      elapsed += stepMs;
      setBannerProgress(Math.min(100, (elapsed / intervalMs) * 100));

      if (elapsed >= intervalMs) {
        elapsed = 0;
        setBannerProgress(0);
        setCurrentSlideIndex((prev) => (prev + 1) % activeSlides.length);
      }
    }, stepMs);

    return () => clearInterval(timer);
  }, [activeSlides.length, bannerInterval, isBannerHovered, currentSlideIndex]);

  const handleUpdateBannerSlides = (newSlides: BannerSlide[]) => {
    setBannerSlides(newSlides);
    localStorage.setItem('pishgam_banners', JSON.stringify(newSlides));
  };

  const handleUpdateBannerInterval = (newSec: number) => {
    setBannerInterval(newSec);
    localStorage.setItem('pishgam_banner_interval', String(newSec));
  };

  // Mini-cycling state for Slide 2 (New products showcase) & Slide 3 (Leading Brands showcase)
  const [activeNewProductIdx, setActiveNewProductIdx] = useState(0);
  const [activeBrandIndex, setActiveBrandIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveNewProductIdx((prev) => (prev + 1) % CYCLING_NEW_PRODUCTS.length);
    }, 2800);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveBrandIndex((prev) => (prev + 1) % CYCLING_BRANDS.length);
    }, 2800);
    return () => clearInterval(timer);
  }, []);

  // =========================================================================
  // SPECIAL OFFERS 24H SECTION STATE (پیشنهادات شگفت‌انگیز ۲۴ ساعته)
  // =========================================================================
  const [specialOffers, setSpecialOffers] = useState<SpecialOffersConfig>(() => {
    try {
      const saved = localStorage.getItem('pishgam_special_offers');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return DEFAULT_SPECIAL_OFFERS;
  });

  const [nowTime, setNowTime] = useState<number>(Date.now());
  useEffect(() => {
    const timer = setInterval(() => {
      setNowTime(Date.now());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const specialTimeRemainingMs = Math.max(0, specialOffers.targetEndTime - nowTime);
  const isSpecialExpired = specialTimeRemainingMs <= 0;
  const specialHours = Math.floor(specialTimeRemainingMs / (1000 * 60 * 60));
  const specialMinutes = Math.floor((specialTimeRemainingMs % (1000 * 60 * 60)) / (1000 * 60));
  const specialSeconds = Math.floor((specialTimeRemainingMs % (1000 * 60)) / 1000);

  const handleUpdateSpecialOffers = (newConfig: SpecialOffersConfig) => {
    setSpecialOffers(newConfig);
    localStorage.setItem('pishgam_special_offers', JSON.stringify(newConfig));
  };

  const handleResetSpecialOffersTimer = (hours = 24) => {
    const newEndTime = Date.now() + hours * 60 * 60 * 1000;
    const updated = {
      ...specialOffers,
      durationHours: hours,
      targetEndTime: newEndTime,
    };
    setSpecialOffers(updated);
    localStorage.setItem('pishgam_special_offers', JSON.stringify(updated));
  };

  const handleAddSpecialOfferToCart = (prod: ProductItem, discountPercent: number) => {
    const discountedPrice = Math.round(prod.price * (1 - discountPercent / 100));
    const specialProdClone: ProductItem = {
      ...prod,
      price: discountedPrice,
      model: `${prod.model} [تخفیف شگفت‌انگیز ۲۴h]`,
    };
    handleAddToCart(specialProdClone);
  };

  // CUSTOMER VS ADMIN ROLE ISOLATION (تضمین امنیت و عدم دسترسی مشتریان به پنل تنظیمات)
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState<boolean>(() => {
    return localStorage.getItem('pishgam_is_admin') === 'true';
  });
  const [showAdminLoginModal, setShowAdminLoginModal] = useState(false);
  const [adminPinInput, setAdminPinInput] = useState('');
  const [adminPinError, setAdminPinError] = useState('');

  const handleAdminLoginSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (adminPinInput.trim() === '1234') {
      setIsAdminAuthenticated(true);
      localStorage.setItem('pishgam_is_admin', 'true');
      setShowAdminLoginModal(false);
      setAdminPinInput('');
      setAdminPinError('');
      setShowAdminPanel(true);
    } else {
      setAdminPinError('کد پین مدیر نادرست است. (کد پیش‌فرض: 1234)');
    }
  };

  const handleAdminLogout = () => {
    setIsAdminAuthenticated(false);
    localStorage.setItem('pishgam_is_admin', 'false');
    setShowAdminPanel(false);
  };

  // LIVE TICKER (MARQUEE) STATE & MANAGER EDITING
  const defaultTicker = 'امکان خرید اقساطی در ۴ قسط بدون سود با اسنپ‌پی (SnappPay) · خرید اقساطی با چک صیادی و ضمانت · درگاه پرداخت آنلاین سامان (شتاب) · ارسال فوری از انبار مرکزی اهواز · گواهی کالیبراسیون ۱۰۰٪ معتبر · تلفن مستقیم: 061-32230000';
  const [tickerText, setTickerText] = useState(() => {
    return localStorage.getItem('pishgam_ticker_text') || defaultTicker;
  });
  const [showTickerEditor, setShowTickerEditor] = useState(false);
  const [tempTickerText, setTempTickerText] = useState(tickerText);

  const handleSaveTicker = () => {
    setTickerText(tempTickerText);
    localStorage.setItem('pishgam_ticker_text', tempTickerText);
    setShowTickerEditor(false);
  };

  // AGENCIES LIST STATE & MANAGER CUSTOMIZER (قابلیت ویرایش و شخصی‌سازی لیست نمایندگی‌ها)
  const [agenciesList, setAgenciesList] = useState<AgencyItem[]>(() => {
    try {
      const saved = localStorage.getItem('pishgam_agencies');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return DEFAULT_AGENCIES;
  });
  const [showAgencyModal, setShowAgencyModal] = useState(false);
  const [tempAgencies, setTempAgencies] = useState<AgencyItem[]>(agenciesList);

  const handleOpenAgencyModal = () => {
    setTempAgencies(JSON.parse(JSON.stringify(agenciesList)));
    setShowAgencyModal(true);
  };

  const handleSaveAgencies = () => {
    setAgenciesList(tempAgencies);
    localStorage.setItem('pishgam_agencies', JSON.stringify(tempAgencies));
    setShowAgencyModal(false);
  };

  const handleResetAgencies = () => {
    setTempAgencies(JSON.parse(JSON.stringify(DEFAULT_AGENCIES)));
  };

  const handleLoadAgencyPreset = (presetItems: AgencyItem[]) => {
    setTempAgencies(JSON.parse(JSON.stringify(presetItems)));
  };

  const handleAddAgency = () => {
    const newAg: AgencyItem = {
      id: `ag-custom-${Date.now()}`,
      name: 'نام برند / کمپانی جدید',
      country: 'کشور سازنده',
      role: 'سطح نمایندگی یا عاملیت توزیع',
      description: 'توضیحات مربوط به محصولات و گارانتی این برند در انبار اهواز',
      badge: 'دارای سرتیفیکیت معتبر',
      specialties: ['محصول ۱', 'محصول ۲'],
    };
    setTempAgencies([...tempAgencies, newAg]);
  };

  const handleRemoveAgency = (index: number) => {
    setTempAgencies(tempAgencies.filter((_, idx) => idx !== index));
  };

  const handleUpdateAgencyField = (index: number, field: keyof AgencyItem, value: any) => {
    setTempAgencies(prev => {
      const copy = [...prev];
      copy[index] = { ...copy[index], [field]: value };
      return copy;
    });
  };

  // Cart State (Shopping Cart)
  const [cartItems, setCartItems] = useState<{ product: ProductItem; quantity: number }[]>([
    { product: PRODUCTS[0], quantity: 1 },
    { product: PRODUCTS[1], quantity: 2 },
  ]);
  const [cartDrawerOpen, setCartDrawerOpen] = useState(false);
  const [checkoutModalOpen, setCheckoutModalOpen] = useState(false);
  const [orderSuccess, setOrderSuccess] = useState(false);
  const [orderTrackingCode, setOrderTrackingCode] = useState('');

  // Customer Online Order Tracking Portal State (سامانه رهگیری و استعلام سفارشات با شماره موبایل)
  const [showOrderTrackingModal, setShowOrderTrackingModal] = useState(false);
  const [trackingSearchInput, setTrackingSearchInput] = useState('');
  const [trackingSearchResult, setTrackingSearchResult] = useState<AdminOrder[] | null>(null);
  const [hasSearchedTracking, setHasSearchedTracking] = useState(false);
  const [resendSmsFeedback, setResendSmsFeedback] = useState<string | null>(null);

  // Stepped Checkout Experience ('address' | 'payment' | 'gateway' | 'success')
  const [checkoutStep, setCheckoutStep] = useState<'address' | 'payment' | 'gateway' | 'success'>('address');
  const [gatewayProgress, setGatewayProgress] = useState(0);
  const [showPreInvoiceModal, setShowPreInvoiceModal] = useState(false);
  const [trackingCopied, setTrackingCopied] = useState(false);

  // Shipping Method
  const [shippingMethod, setShippingMethod] = useState<'express_ahvaz' | 'tipax' | 'freight'>('express_ahvaz');

  // Checkout Form Details
  const [customerName, setCustomerName] = useState('مهندس علی رضایی');
  const [customerPhone, setCustomerPhone] = useState('09161112233');
  const [customerLandline, setCustomerLandline] = useState('06134445566');
  const [customerProvince, setCustomerProvince] = useState('خوزستان');
  const [customerCity, setCustomerCity] = useState('اهواز');
  const [customerAddress, setCustomerAddress] = useState('کوی نفت، خیابان بهارستان، پلاک ۱۴');
  const [postalCode, setPostalCode] = useState('6164712345');
  const [orderNotes, setOrderNotes] = useState('تحویل به واحد تدارکات و کالیبراسیون پالایشگاه - هماهنگی قبل از ارسال');
  const [paymentMethod, setPaymentMethod] = useState<'online' | 'snapp_pay' | 'installment_in_person' | 'bank_transfer'>('snapp_pay');

  // INSTALLMENT TERMS & CONDITIONS STATE (شرایط خرید اقساطی با چک صیادی و ضمانت - قابل ویرایش از پنل مدیر)
  const defaultInstallmentTerms = `شرایط و مدارک لازم جهت خرید اقساطی با چک صیادی (پیشگام صنعت اهواز):

۱. ویژه سازمان‌ها، پیمانکاران محترم، شرکت‌های صنعتی، کارگاه‌ها و اصناف خوزستان و سراسر کشور.
۲. نیازمند ارائه چک صیادی معتبر (بنفش رنگ) ثبت‌شده در سامانه یکپارچه صیاد بانک مرکزی به نام شخص یا شرکت خریدار.
۳. هماهنگی نهایی، اعتبارسنجی حساب بانکی و تحویل اصل چک‌ها در محل دفتر مرکزی و انبار اهواز (طالقانی، خیابان نظامی) انجام می‌پذیرد.
۴. ارائه مدارک شناسایی معتبر، احراز هویت شغلی (پروانه کسب معتبر یا معرفی‌نامه رسمی شرکت با سربرگ و مهر) الزامی است.
۵. پس از ثبت این درخواست در سایت، کارشناس واحد فروش اعتباری جهت تعیین وقت جلسه حضوری و تکمیل پرونده ظرف ۱ ساعت کاری با شما تماس خواهد گرفت.`;

  const [installmentTermsText, setInstallmentTermsText] = useState<string>(() => {
    return localStorage.getItem('pishgam_installment_terms') || defaultInstallmentTerms;
  });
  const [showInstallmentTermsModal, setShowInstallmentTermsModal] = useState<boolean>(false);

  const handleUpdateInstallmentTerms = (text: string) => {
    setInstallmentTermsText(text);
    localStorage.setItem('pishgam_installment_terms', text);
  };
  const [needOfficialInvoice, setNeedOfficialInvoice] = useState(false);
  const [companyName, setCompanyName] = useState('شرکت مهندسی و بازرگانی نفت و گاز اروند');
  const [companyNationalId, setCompanyNationalId] = useState('14008923410');
  const [companyEconomicCode, setCompanyEconomicCode] = useState('411589326411');

  // Technical Specs & Compare State
  const [activeModalProduct, setActiveModalProduct] = useState<ProductItem | null>(null);
  const [compareList, setCompareList] = useState<ProductItem[]>([]);
  const [showCompareModal, setShowCompareModal] = useState(false);

  // Discrete RFQ Modal
  const [showRfqModal, setShowRfqModal] = useState(false);

  // ADMIN PANEL STATE (پنل مدیریت یکپارچه فروشگاه و انبار پیشگام صنعت)
  const [showAdminPanel, setShowAdminPanel] = useState(false);

  // PRODUCTS & INVENTORY STATE (قابلیت مدیریت و افزودن محصول توسط مدیر)
  const [productsList, setProductsList] = useState<ProductItem[]>(() => {
    try {
      const saved = localStorage.getItem('pishgam_products');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return PRODUCTS;
  });

  const handleUpdateProduct = (updated: ProductItem) => {
    const next = productsList.map((p) => (p.id === updated.id ? updated : p));
    setProductsList(next);
    localStorage.setItem('pishgam_products', JSON.stringify(next));
  };

  const handleAddProduct = (newProd: ProductItem) => {
    const next = [newProd, ...productsList];
    setProductsList(next);
    localStorage.setItem('pishgam_products', JSON.stringify(next));
  };

  const handleDeleteProduct = (productId: string) => {
    const next = productsList.filter((p) => p.id !== productId);
    setProductsList(next);
    localStorage.setItem('pishgam_products', JSON.stringify(next));
  };

  // ORDERS MANAGEMENT STATE (ثبت و مدیریت سفارشات اسنپ‌پی، ترب‌پی و شتاب)
  const [ordersList, setOrdersList] = useState<AdminOrder[]>(() => {
    try {
      const saved = localStorage.getItem('pishgam_orders');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return [
      {
        id: 'ord-101',
        trackingCode: 'PG-834921',
        customerName: 'مهندس حسینی (پتروشیمی ماهشهر)',
        customerPhone: '09163001234',
        city: 'ماهشهر',
        address: 'منطقه ویژه اقتصادی پتروشیمی، فاز ۲، سایت ۵',
        shippingMethod: 'tipax',
        paymentMethod: 'snapp_pay',
        totalAmount: 13700000,
        items: [{ product: PRODUCTS[0], quantity: 2 }],
        status: 'processing',
        createdAt: 'امروز - ۱۰:۴۵',
        smsStatus: 'delivered',
        smsSentAt: 'امروز - ۱۰:۴۶',
        postalBarcode: 'TPX-98210384910',
      },
      {
        id: 'ord-102',
        trackingCode: 'PG-549102',
        customerName: 'رضا کریمی (شرکت توزیع نیروی برق اهواز)',
        customerPhone: '09161117788',
        city: 'اهواز',
        address: 'کیانپارس، خیابان پهلوان غربی، پلاک ۲۴',
        shippingMethod: 'express_ahvaz',
        paymentMethod: 'installment_in_person',
        totalAmount: 24575000,
        items: [{ product: PRODUCTS[2], quantity: 1 }],
        status: 'shipped',
        createdAt: 'دیروز - ۱۶:۲۰',
        smsStatus: 'delivered',
        smsSentAt: 'دیروز - ۱۶:۲۲',
        postalBarcode: 'AHV-EXP-9014',
      },
      {
        id: 'ord-103',
        trackingCode: 'PG-294018',
        customerName: 'مهندس بهرامی',
        customerPhone: '09121119988',
        city: 'آبادان',
        address: 'کوی کارمندان، خیابان نفت، شرکت نفت و گاز اروندان',
        shippingMethod: 'tipax',
        paymentMethod: 'online',
        totalAmount: 32180000,
        items: [{ product: PRODUCTS[3], quantity: 1 }],
        status: 'delivered',
        createdAt: '۳ روز قبل',
        smsStatus: 'delivered',
        smsSentAt: '۳ روز قبل',
        postalBarcode: '243891002948192039485712',
      },
    ];
  });

  const handleUpdateOrderStatus = (orderId: string, status: AdminOrder['status']) => {
    const next = ordersList.map((o) => (o.id === orderId ? { ...o, status } : o));
    setOrdersList(next);
    localStorage.setItem('pishgam_orders', JSON.stringify(next));
  };

  const handleUpdateOrderDetails = (orderId: string, updates: Partial<AdminOrder>) => {
    const next = ordersList.map((o) => (o.id === orderId ? { ...o, ...updates } : o));
    setOrdersList(next);
    localStorage.setItem('pishgam_orders', JSON.stringify(next));
  };

  // Search orders for online tracking portal (by mobile number or tracking code)
  const handleSearchOrderTracking = (queryToSearch?: string) => {
    const query = (queryToSearch !== undefined ? queryToSearch : trackingSearchInput).trim().toLowerCase();
    if (!query) {
      setTrackingSearchResult(null);
      setHasSearchedTracking(false);
      return;
    }
    setHasSearchedTracking(true);
    const normalizedDigits = query.replace(/\D/g, '');
    const results = ordersList.filter((o) => {
      const matchCode = o.trackingCode.toLowerCase().includes(query);
      const matchPostal = o.postalBarcode?.toLowerCase().includes(query);
      const matchPhone = normalizedDigits.length >= 4 && o.customerPhone.replace(/\D/g, '').includes(normalizedDigits);
      return matchCode || matchPostal || matchPhone;
    });
    setTrackingSearchResult(results);
  };

  // STORE CONTACT & WAREHOUSE SETTINGS
  const [storePhone, setStorePhone] = useState(() => {
    return localStorage.getItem('pishgam_phone') || '061-32230000';
  });
  const [storeMobile, setStoreMobile] = useState(() => {
    return localStorage.getItem('pishgam_mobile') || '09161112233';
  });
  const [storeAddress, setStoreAddress] = useState(() => {
    return localStorage.getItem('pishgam_address') || 'اهواز، خیابان طالقانی، نبش نظامی، مجتمع ابزار دقیق';
  });

  // EXIT-INTENT RETENTION POPUP STATE (هشدار تحریک مشتری هنگام ترک سایت)
  const [showExitIntentModal, setShowExitIntentModal] = useState(false);
  const [discountCopied, setDiscountCopied] = useState(false);
  const [discountCode, setDiscountCode] = useState(() => {
    return localStorage.getItem('pishgam_discount_code') || 'PISHGAM5';
  });

  const handleUpdateDiscountCode = (newCode: string) => {
    setDiscountCode(newCode);
    localStorage.setItem('pishgam_discount_code', newCode);
  };

  useEffect(() => {
    const handleMouseLeave = (e: MouseEvent) => {
      // Trigger when cursor leaves from the top boundary of the viewport
      if (e.clientY <= 15) {
        const dismissed = sessionStorage.getItem('pishgam_exit_retention_dismissed');
        if (!dismissed) {
          setShowExitIntentModal(true);
        }
      }
    };

    document.addEventListener('mouseleave', handleMouseLeave);
    return () => {
      document.removeEventListener('mouseleave', handleMouseLeave);
    };
  }, []);

  const handleDismissExitModal = () => {
    setShowExitIntentModal(false);
    sessionStorage.setItem('pishgam_exit_retention_dismissed', 'true');
  };

  const handleCopyDiscount = () => {
    navigator.clipboard.writeText(discountCode);
    setDiscountCopied(true);
    setTimeout(() => setDiscountCopied(false), 2500);
  };

  // Filter logic based on dynamic productsList
  const filteredProducts = productsList.filter((p) => {
    const matchCat = selectedCategory === 'all' || p.category === selectedCategory;
    const matchBrand = selectedBrand === 'all' || p.brand === selectedBrand;
    const matchSearch =
      p.name.includes(searchQuery) ||
      p.model.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.specs.feature.includes(searchQuery);
    return matchCat && matchBrand && matchSearch;
  });

  // Cart Handlers
  const handleAddToCart = (product: ProductItem) => {
    setCartItems((prev) => {
      const exists = prev.find((item) => item.product.id === product.id);
      if (exists) {
        return prev.map((item) =>
          item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { product, quantity: 1 }];
    });
    setCartDrawerOpen(true);
  };

  const handleUpdateCartQty = (productId: string, delta: number) => {
    setCartItems((prev) =>
      prev
        .map((item) => {
          if (item.product.id === productId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as { product: ProductItem; quantity: number }[]
    );
  };

  const handleRemoveFromCart = (productId: string) => {
    setCartItems((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const cartTotalQty = cartItems.reduce((sum, item) => sum + item.quantity, 0);
  const cartSubtotal = cartItems.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  
  let shippingCost = 0;
  if (shippingMethod === 'express_ahvaz') {
    shippingCost = cartSubtotal > 5000000 ? 0 : 75000;
  } else if (shippingMethod === 'tipax') {
    shippingCost = cartSubtotal > 10000000 ? 0 : 180000;
  } else {
    shippingCost = cartSubtotal > 15000000 ? 0 : 250000;
  }

  const vatCost = needOfficialInvoice ? Math.round(cartSubtotal * 0.1) : 0;
  const cartFinalTotal = cartSubtotal + shippingCost + vatCost;

  const handleToggleCompare = (product: ProductItem) => {
    if (compareList.find((p) => p.id === product.id)) {
      setCompareList(compareList.filter((p) => p.id !== product.id));
    } else {
      if (compareList.length >= 3) {
        alert('حداکثر ۳ محصول را می‌توانید همزمان مقایسه کنید.');
        return;
      }
      setCompareList([...compareList, product]);
    }
  };

  // Stepped Checkout Handlers
  const handleOpenCheckout = () => {
    if (cartItems.length === 0) {
      setCartItems([
        { product: productsList[0] || PRODUCTS[0], quantity: 1 }
      ]);
    }
    setOrderSuccess(false);
    setCheckoutStep('address');
    setCheckoutModalOpen(true);
  };

  const handleProceedToPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim() || !customerPhone.trim() || !customerAddress.trim()) {
      alert('لطفاً نام تحویل‌گیرنده، شماره تماس و آدرس پستی دقیق را وارد کنید.');
      return;
    }
    setCheckoutStep('payment');
  };

  const handleStartPaymentSimulation = () => {
    setCheckoutStep('gateway');
    setGatewayProgress(15);
    
    setTimeout(() => setGatewayProgress(45), 350);
    setTimeout(() => setGatewayProgress(80), 850);
    setTimeout(() => setGatewayProgress(100), 1350);
    setTimeout(() => {
      finishOrderProcessing();
    }, 1700);
  };

  const finishOrderProcessing = () => {
    const tracking = `PG-${Math.floor(100000 + Math.random() * 900000)}`;
    setOrderTrackingCode(tracking);

    const newOrder: AdminOrder = {
      id: `ord-${Date.now()}`,
      trackingCode: tracking,
      customerName,
      customerPhone,
      city: customerCity,
      address: `${customerProvince}، ${customerCity}، ${customerAddress}`,
      shippingMethod,
      paymentMethod,
      totalAmount: cartFinalTotal,
      items: [...cartItems],
      status: 'pending',
      createdAt: 'امروز - هم‌اکنون',
    };
    const nextOrders = [newOrder, ...ordersList];
    setOrdersList(nextOrders);
    localStorage.setItem('pishgam_orders', JSON.stringify(nextOrders));

    // Send automatic invoice email to manager
    try {
      const savedEmail = localStorage.getItem('pishgam_manager_email') || 'info@pishgams.com';
      const savedSmtp = localStorage.getItem('pishgam_smtp_config');
      const smtpConfig = savedSmtp ? JSON.parse(savedSmtp) : null;
      fetch('/api/orders/send-invoice-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          order: newOrder,
          managerEmail: savedEmail,
          smtpConfig,
        }),
      }).catch((err) => console.log('Invoice email notification error:', err));
    } catch (e) {
      console.log('Invoice email trigger error:', e);
    }

    setCheckoutStep('success');
    setOrderSuccess(true);
  };

  const handleCopyTrackingCode = () => {
    if (orderTrackingCode) {
      navigator.clipboard.writeText(orderTrackingCode);
      setTrackingCopied(true);
      setTimeout(() => setTrackingCopied(false), 2500);
    }
  };

  return (
    <div className={`w-full ${theme.bgCanvas} text-slate-100 min-h-screen ${currentFontClass} transition-colors duration-200 selection:bg-rose-600 selection:text-white`}>
      
      {/* ADMIN STATUS BAR (هنگام لاگین مدیر - امکان سوئیچ فوری به نمای مشتری عادی) */}
      {isAdminAuthenticated && (
        <div className="bg-amber-950/90 border-b border-amber-500/40 text-amber-200 text-xs px-4 py-1.5 flex items-center justify-between shadow-xs">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping shrink-0" />
            <span className="font-bold text-amber-300">حالت مدیریت انبار فعال است</span>
            <span className="text-amber-400/70 text-[11px] hidden sm:inline">· مشتریان عادی به این بخش دسترسی ندارند</span>
          </div>
          <div className="flex items-center gap-2 text-[11px]">
            <button
              onClick={() => setShowAdminPanel(true)}
              className="px-2.5 py-0.5 rounded bg-amber-600 hover:bg-amber-500 text-white font-bold flex items-center gap-1 transition-colors"
            >
              <LayoutDashboard className="w-3 h-3" />
              <span>پنل مدیریت</span>
            </button>
            <button
              onClick={handleAdminLogout}
              className="px-2 py-0.5 rounded border border-amber-700/80 hover:bg-amber-900/60 text-amber-300 transition-colors flex items-center gap-1"
              title="خروج و مشاهده وب‌سایت در نمای مشتری عادی"
            >
              <LogOut className="w-3 h-3" />
              <span>خروج (نمای مشتری)</span>
            </button>
          </div>
        </div>
      )}

      {/* =========================================================================
          1. LIVE MOVING MARQUEE TICKER (هدر متحرک زنده، شفاف و بدون برچسب استاتیک)
         ========================================================================= */}
      <div className={`relative ${theme.tickerBg} border-b ${theme.tickerBorder} text-slate-200 text-xs py-2 overflow-hidden flex items-center shadow-xs`}>
        {/* Continuous Animated Moving Ticker Bar - Bolder & Prominent */}
        <div className="overflow-hidden flex-1 relative flex items-center px-4">
          <div className="animate-ticker text-xs sm:text-sm font-black text-white flex items-center gap-10 py-0.5 tracking-wide">
            <span className="drop-shadow-xs">{tickerText}</span>
            <span className="text-rose-500 font-black text-sm">✦</span>
            <span className="drop-shadow-xs">{tickerText}</span>
            <span className="text-rose-500 font-black text-sm">✦</span>
            <span className="drop-shadow-xs">{tickerText}</span>
          </div>
        </div>

        {/* Right static shortcuts */}
        <div className={`z-10 ${theme.tickerBg} ps-3 pe-4 hidden lg:flex items-center gap-3 shrink-0 border-s ${theme.borderPrimary} text-[11px] font-num`}>
          <span className="flex items-center gap-1 text-slate-300">
            <Phone className={`w-3 h-3 ${theme.accentText}`} />
            <span dir="ltr">{storePhone}</span>
          </span>
          {onOpenBeforeAfter && (
            <button
              onClick={onOpenBeforeAfter}
              className="text-slate-400 hover:text-white underline"
            >
              مقایسه قبل/بعد
            </button>
          )}
          {onOpenProposal && (
            <button
              onClick={onOpenProposal}
              className="text-slate-400 hover:text-emerald-400 underline"
            >
              پروپوزال رسمی
            </button>
          )}
          <button
            onClick={handleOpenCheckout}
            className="px-2.5 py-0.5 rounded-md border border-emerald-600/70 bg-emerald-950/70 hover:bg-emerald-900 text-emerald-300 hover:text-white text-[10px] flex items-center gap-1 transition-colors font-bold shadow-xs"
            title="مشاهده و تست پروسه کامل ثبت سفارش و فرم آدرس"
          >
            <CreditCard className="w-3 h-3 text-emerald-400" />
            <span>تست پروسه سفارش و آدرس</span>
          </button>
          <button
            onClick={() => setShowExitIntentModal(true)}
            className="px-2 py-0.5 rounded-md border border-slate-700/60 bg-slate-900/60 hover:bg-slate-800 text-slate-400 hover:text-slate-200 text-[10px] flex items-center gap-1 transition-colors"
            title="پیش‌نمایش هشدار ترک سایت"
          >
            <AlertTriangle className="w-2.5 h-2.5 text-amber-400/80" />
            <span>تست هشدار خروج</span>
          </button>
        </div>
      </div>

      {/* Modal for Manager to Edit Ticker Text */}
      {showTickerEditor && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg p-6 space-y-4 shadow-2xl text-xs">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Edit3 className="w-4 h-4 text-amber-400" />
                <h3 className="font-bold text-sm text-white">ویرایش متن نوار متحرک بالای سایت (پنل مدیر)</h3>
              </div>
              <button
                onClick={() => setShowTickerEditor(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div>
              <label className="block text-slate-400 mb-1.5 font-medium">متن اطلاعیه انبار و تخفیفات:</label>
              <textarea
                rows={4}
                value={tempTickerText}
                onChange={(e) => setTempTickerText(e.target.value)}
                className="w-full p-3 rounded-xl border border-slate-700 bg-slate-800 text-white focus:outline-none focus:ring-2 focus:ring-rose-500 leading-relaxed"
                placeholder="متن دلخواه خود را بنویسید..."
              />
            </div>

            <div className="flex items-center justify-between pt-2">
              <button
                onClick={() => setTempTickerText(defaultTicker)}
                className="text-slate-400 hover:text-white underline text-[11px]"
              >
                بازنشانی به متن پیش‌فرض
              </button>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setShowTickerEditor(false)}
                  className="px-3 py-1.5 rounded-lg border border-slate-700 text-slate-300 hover:bg-slate-800"
                >
                  انصراف
                </button>
                <button
                  onClick={handleSaveTicker}
                  className="px-4 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold flex items-center gap-1.5"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>ذخیره و اعمال در نوار</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          2. MAIN HEADER (هدر تیره مدرن با پالت سوییچر و سبد خرید)
         ========================================================================= */}
      <header className={`sticky top-0 z-40 ${theme.bgSurface}/95 backdrop-blur-md border-b ${theme.borderPrimary} px-4 sm:px-8 py-3.5 shadow-md`}>
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-6">
          {/* Brand Logo & Wordmark with official store logo - Large & Up Close */}
          <div className="flex items-center gap-3.5 shrink-0">
            <div className="h-14 sm:h-16 px-3.5 sm:px-4 py-1.5 bg-white rounded-2xl border-2 border-slate-300 dark:border-slate-700 shadow-lg flex items-center justify-center shrink-0 hover:scale-[1.02] transition-transform">
              <img
                src="/pishgam-logo-hd.png"
                alt="لوگوی رسمی پیشگام صنعت اهواز"
                className="h-11 sm:h-13 w-auto max-w-[170px] sm:max-w-[210px] object-contain drop-shadow-xs"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = '/public/assets/aistudio/_______596a28b5.jpg';
                }}
              />
            </div>
            <div className="hidden md:flex flex-col justify-center border-s border-slate-700/60 ps-3.5">
              <div className="flex items-center gap-2">
                <span className={`text-xs font-black tracking-tight ${theme.textHeading}`}>
                  تجهیزات تست و ابزار دقیق
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-400 font-bold border border-rose-500/30">
                  اهواز
                </span>
              </div>
              <div className={`text-[11px] ${theme.textMuted} font-medium flex items-center gap-2 mt-0.5`}>
                <span>کالیبراسیون و پخش مستقیم</span>
                <span className="text-slate-600">·</span>
                <span className="text-emerald-400 font-bold text-[10px] flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  انبار مرکزی فعال
                </span>
              </div>
            </div>
          </div>

          {/* Quick Search */}
          <div className="flex-1 max-w-md hidden md:block">
            <div className="relative">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="جستجوی تجهیزات (UT61E+, کلمپ‌متر، میگر، کالیبراتور...)"
                className="w-full ps-9 pe-3 py-1.5 text-xs rounded-xl border border-slate-800 bg-slate-900/90 focus:outline-none focus:ring-2 focus:ring-rose-500 text-white placeholder:text-slate-500"
              />
              <Search className="w-4 h-4 text-slate-500 absolute start-3 top-2 pointer-events-none" />
            </div>
          </div>

          {/* Action Area: Shopping Cart (Header is now ultra-clean, fast and uncluttered) */}
          <div className="flex items-center gap-2 shrink-0">
            {/* REFINED SHOPPING CART BUTTON */}
            <button
              onClick={() => setCartDrawerOpen(true)}
              className={`flex items-center gap-2 px-3.5 py-2 text-xs font-bold ${theme.accentBtn} rounded-xl transition-all shadow-md hover:shadow-rose-900/40 whitespace-nowrap`}
              title="مشاهده سبد خرید و تسویه حساب"
            >
              <ShoppingCart className="w-4 h-4" />
              <span>سبد خرید</span>
              <span className="px-2 py-0.5 rounded-full bg-black/30 text-white text-[11px] font-num font-extrabold">
                {cartTotalQty}
              </span>
            </button>
          </div>
        </div>
      </header>

      {/* =========================================================================
          3. DYNAMIC HERO SLIDER (اسلایدر بنرهای متغیر و تایمردار با حاشیه قرمز)
         ========================================================================= */}
      <section 
        className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8"
        onMouseEnter={() => setIsBannerHovered(true)}
        onMouseLeave={() => setIsBannerHovered(false)}
      >
        <div className="relative overflow-hidden rounded-3xl border-2 border-rose-600/80 bg-gradient-to-br from-slate-900/98 via-slate-800/90 to-slate-900/98 backdrop-blur-md p-6 sm:p-10 shadow-2xl shadow-rose-950/30 ring-1 ring-rose-500/30 transition-all duration-500">
          
          {/* Top Live Progress Bar for Slide Timer */}
          <div className="absolute top-0 inset-x-0 h-1.5 bg-slate-950/80 overflow-hidden z-20">
            <div 
              className="h-full bg-gradient-to-r from-rose-600 via-amber-500 to-emerald-500 transition-all ease-linear"
              style={{ width: `${activeSlides.length > 1 ? bannerProgress : 100}%` }}
            />
          </div>

          {/* Subtle Ambient Glow Accents */}
          <div className="absolute -top-32 -end-32 w-80 h-80 bg-rose-600/15 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-32 -start-32 w-80 h-80 bg-rose-500/10 rounded-full blur-3xl pointer-events-none" />

          {/* Previous & Next Navigation Buttons */}
          {activeSlides.length > 1 && (
            <>
              <button
                type="button"
                onClick={() => setCurrentSlideIndex((prev) => (prev - 1 + activeSlides.length) % activeSlides.length)}
                className="absolute start-3 top-1/2 -translate-y-1/2 z-20 p-2 sm:p-2.5 rounded-2xl bg-black/60 hover:bg-rose-600 border border-white/10 hover:border-rose-500 text-white transition-all shadow-lg backdrop-blur-xs group"
                title="اسلاید قبلی"
              >
                <ChevronRight className="w-5 h-5 group-hover:scale-110 transition-transform" />
              </button>
              <button
                type="button"
                onClick={() => setCurrentSlideIndex((prev) => (prev + 1) % activeSlides.length)}
                className="absolute end-3 top-1/2 -translate-y-1/2 z-20 p-2 sm:p-2.5 rounded-2xl bg-black/60 hover:bg-rose-600 border border-white/10 hover:border-rose-500 text-white transition-all shadow-lg backdrop-blur-xs group"
                title="اسلاید بعدی"
              >
                <ChevronLeft className="w-5 h-5 group-hover:scale-110 transition-transform" />
              </button>
            </>
          )}

          {/* Active Slide Content */}
          {activeSlides.length > 0 && (() => {
            const currentSlide = activeSlides[currentSlideIndex % activeSlides.length] || activeSlides[0];

            return (
              <div key={currentSlide.id} className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center animate-in fade-in zoom-in-98 duration-300">
                <div className="lg:col-span-7 space-y-5 relative z-10">
                  <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full ${theme.accentBadgeBg} border ${theme.accentBadgeBorder} text-xs font-bold ${theme.accentBadgeText}`}>
                    {currentSlide.type === 'main' ? (
                      <Cpu className="w-3.5 h-3.5" />
                    ) : currentSlide.type === 'new_products' ? (
                      <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    ) : (
                      <Award className="w-3.5 h-3.5 text-rose-400" />
                    )}
                    <span>{currentSlide.badge}</span>
                  </div>

                  <h1 className="text-2xl sm:text-3xl font-bold text-white leading-snug tracking-tight" style={{ textWrap: 'balance' }}>
                    {currentSlide.title}
                  </h1>

                  <p className="text-xs sm:text-[13px] text-slate-300 leading-relaxed max-w-xl">
                    {currentSlide.description}
                  </p>

                  <div className="flex flex-wrap items-center gap-2.5 pt-1">
                    <a
                      href={currentSlide.buttonLink}
                      className={`px-4 py-2 text-xs font-semibold ${theme.accentBtn} rounded-lg transition-colors shadow-xs flex items-center gap-1.5`}
                    >
                      <span>{currentSlide.buttonText}</span>
                      <ChevronLeft className="w-3.5 h-3.5" />
                    </a>
                    
                    {currentSlide.secondaryButtonText && (
                      currentSlide.secondaryButtonLink === '#installment' ? (
                        <button
                          type="button"
                          onClick={() => setShowInstallmentTermsModal(true)}
                          className="px-3.5 py-2 text-xs font-medium border border-amber-500/60 hover:bg-amber-950/40 text-amber-300 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
                        >
                          <FileText className="w-3.5 h-3.5 text-amber-400" />
                          <span>{currentSlide.secondaryButtonText}</span>
                        </button>
                      ) : (
                        <a
                          href={currentSlide.secondaryButtonLink}
                          className="px-3.5 py-2 text-xs font-medium border border-slate-700/80 hover:bg-slate-800 text-slate-300 rounded-lg transition-colors flex items-center gap-1.5"
                        >
                          <Award className="w-3.5 h-3.5 text-amber-400" />
                          <span>{currentSlide.secondaryButtonText}</span>
                        </a>
                      )
                    )}
                  </div>

                  {/* Badges / Extra Highlights for Slide 1 */}
                  {currentSlide.type === 'main' && (
                    <>
                      <div className="pt-2 flex flex-wrap items-center gap-3">
                        <SnappPayLogo showTagline={true} className="bg-black/60 shadow-md" />
                        <button
                          type="button"
                          onClick={() => setShowInstallmentTermsModal(true)}
                          className="inline-flex items-center gap-2.5 rounded-2xl p-1.5 transition-all shadow-md bg-slate-900/90 border border-amber-500/50 hover:border-amber-400 group text-start cursor-pointer"
                          title="مشاهده شرایط خرید اقساطی با چک صیادی"
                        >
                          <div className="bg-amber-500/20 text-amber-400 rounded-xl px-2 py-1 flex items-center justify-center shrink-0 border border-amber-500/30 shadow-2xs h-8 sm:h-9">
                            <FileText className="w-4 h-4 sm:w-5 sm:h-5" />
                          </div>
                          <div className="text-right leading-tight pe-1">
                            <div className="text-[11px] font-black text-amber-300 flex items-center gap-1">
                              <span>خرید اقساطی با چک صیادی</span>
                              <span className="text-[9px] px-1 py-0.2 rounded bg-amber-500/20 text-amber-200 font-bold">حضوری اهواز</span>
                            </div>
                            <div className="text-[10px] text-slate-300 font-medium">ویژه شرکت‌ها و کارگاه‌های خوزستان</div>
                          </div>
                        </button>
                      </div>

                      <div className="pt-3 border-t border-slate-800/80 grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs font-num">
                        <div>
                          <span className="text-slate-400 block text-[11px] font-sans">تاسیس انبار اهواز:</span>
                          <span className="font-bold text-slate-200">سال 1393</span>
                        </div>
                        <div>
                          <span className="text-slate-400 block text-[11px] font-sans">سرعت ارسال:</span>
                          <span className="font-bold text-emerald-400">تحویل 24 ساعته</span>
                        </div>
                        <div>
                          <span className="text-slate-400 block text-[11px] font-sans">روش‌های اقساط:</span>
                          <span className="font-bold text-emerald-300">اسنپ‌پی + چک صیاد</span>
                        </div>
                        <div>
                          <span className="text-slate-400 block text-[11px] font-sans">درگاه پرداخت:</span>
                          <span className="font-bold text-sky-300">بانک سامان (شتاب)</span>
                        </div>
                      </div>
                    </>
                  )}

                  {/* Dynamic Controls for Slide 2 (New products cycling) */}
                  {currentSlide.type === 'new_products' && (
                    <div className="pt-3 border-t border-slate-800/80 space-y-2.5">
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-slate-400 text-[11px]">محصول فعال در نمایشگر (چرخش خودکار هر ۳ ثانیه):</span>
                        <span className="font-num text-rose-400 font-bold text-[11px] flex items-center gap-1">
                          <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
                          <span>{((activeNewProductIdx % CYCLING_NEW_PRODUCTS.length) + 1)} از {CYCLING_NEW_PRODUCTS.length}</span>
                        </span>
                      </div>
                      <div className="flex flex-wrap gap-1.5">
                        {CYCLING_NEW_PRODUCTS.map((prod, pIdx) => {
                          const isCurrent = pIdx === (activeNewProductIdx % CYCLING_NEW_PRODUCTS.length);
                          return (
                            <button
                              key={pIdx}
                              type="button"
                              onClick={() => setActiveNewProductIdx(pIdx)}
                              className={`px-2.5 py-1 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                                isCurrent
                                  ? 'bg-rose-600 text-white shadow-md shadow-rose-950/60 ring-1 ring-rose-400'
                                  : 'bg-black/50 text-slate-400 border border-slate-800 hover:text-white hover:bg-slate-900'
                              }`}
                            >
                              <span className="font-num text-[10px]">#{pIdx + 1}</span>
                              <span className="truncate max-w-[130px]">{prod.model}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {/* Dynamic Controls for Slide 3 (Brands cycling) */}
                  {currentSlide.type === 'brands' && (
                    <div className="pt-3 border-t border-slate-800/80 space-y-2.5">
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-slate-400 text-[11px]">برند فعال در نمایشگر (چرخش خودکار هر ۳ ثانیه):</span>
                        <span className="font-num text-cyan-400 font-bold text-[11px] flex items-center gap-1">
                          <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
                          <span>{((activeBrandIndex % CYCLING_BRANDS.length) + 1)} از {CYCLING_BRANDS.length}</span>
                        </span>
                      </div>
                      <div className="flex flex-wrap gap-1.5">
                        {CYCLING_BRANDS.map((br, bIdx) => {
                          const isCurrent = bIdx === (activeBrandIndex % CYCLING_BRANDS.length);
                          return (
                            <button
                              key={bIdx}
                              type="button"
                              onClick={() => setActiveBrandIndex(bIdx)}
                              className={`px-2.5 py-1 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                                isCurrent
                                  ? 'bg-cyan-500 text-slate-950 font-black shadow-md shadow-cyan-950/60 ring-1 ring-cyan-300'
                                  : 'bg-black/50 text-slate-400 border border-slate-800 hover:text-white hover:bg-slate-900'
                              }`}
                            >
                              <span className="truncate">{br.name.split(' ')[0]}</span>
                              <span className="text-[10px] opacity-75 font-normal hidden sm:inline">({br.origin.split('،')[0]})</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>

                {/* Hero Visual Side */}
                <div className="lg:col-span-5">
                  {(() => {
                    if (currentSlide.type === 'new_products') {
                      const curProd = CYCLING_NEW_PRODUCTS[activeNewProductIdx % CYCLING_NEW_PRODUCTS.length];
                      return (
                        <div className={`rounded-2xl overflow-hidden border border-rose-500/70 shadow-2xl bg-black group relative cursor-pointer ring-1 ring-rose-500/30`}>
                          <div className="overflow-hidden relative h-64 sm:h-72">
                            <img
                              key={curProd.model}
                              src={curProd.image}
                              alt={curProd.name}
                              className="w-full h-full object-cover transform transition-all duration-700 ease-out group-hover:scale-105 animate-in fade-in zoom-in-95"
                              referrerPolicy="no-referrer"
                            />
                            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />
                            
                            {/* Top Badges */}
                            <div className="absolute top-3 start-3 px-2.5 py-1 rounded-lg bg-black/80 backdrop-blur-xs border border-rose-500/40 text-rose-300 text-[11px] font-bold flex items-center gap-1.5">
                              <Sparkles className="w-3.5 h-3.5 text-rose-400" />
                              <span>{curProd.tag}</span>
                            </div>

                            <div className="absolute top-3 end-3 px-2.5 py-1 rounded-lg bg-black/80 backdrop-blur-xs border border-white/20 text-emerald-400 text-[11px] font-black font-num">
                              {curProd.price}
                            </div>

                            {/* Bottom In-Image Info */}
                            <div className="absolute bottom-3 inset-x-3 space-y-1">
                              <div className="text-white font-bold text-sm truncate flex items-center gap-2">
                                <span>{curProd.model}</span>
                                <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800/90 text-slate-300 font-normal">
                                  {curProd.brand}
                                </span>
                              </div>
                              <p className="text-[11px] text-slate-300 line-clamp-1">{curProd.name}</p>
                            </div>
                          </div>

                          <div className="p-3 bg-black/95 border-t border-slate-800 flex items-center justify-between text-xs gap-2">
                            <span className="text-slate-300 font-medium text-[11px] truncate">
                              {curProd.spec}
                            </span>
                            <span className="font-num text-rose-400 font-bold shrink-0 flex items-center gap-1 text-[11px]">
                              <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
                              تحویل اهواز
                            </span>
                          </div>
                        </div>
                      );
                    }

                    if (currentSlide.type === 'brands') {
                      const curBrand = CYCLING_BRANDS[activeBrandIndex % CYCLING_BRANDS.length];
                      return (
                        <div className={`rounded-2xl overflow-hidden border border-cyan-500/70 shadow-2xl bg-black group relative cursor-pointer ring-1 ring-cyan-500/30`}>
                          <div className="overflow-hidden relative h-64 sm:h-72">
                            <img
                              key={curBrand.name}
                              src={curBrand.image}
                              alt={curBrand.name}
                              className="w-full h-full object-cover transform transition-all duration-700 ease-out group-hover:scale-105 animate-in fade-in zoom-in-95"
                              referrerPolicy="no-referrer"
                            />
                            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/35 to-transparent" />
                            
                            {/* Top Badges */}
                            <div className="absolute top-3 start-3 px-2.5 py-1 rounded-lg bg-black/80 backdrop-blur-xs border border-cyan-500/40 text-cyan-300 text-[11px] font-bold flex items-center gap-1.5">
                              <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
                              <span>{curBrand.badge}</span>
                            </div>

                            <div className="absolute top-3 end-3 px-2.5 py-1 rounded-lg bg-black/80 backdrop-blur-xs border border-white/20 text-amber-300 text-[11px] font-bold">
                              {curBrand.origin}
                            </div>

                            {/* Bottom In-Image Info */}
                            <div className="absolute bottom-3 inset-x-3 space-y-1">
                              <div className="text-white font-black text-base truncate flex items-center gap-2">
                                <span>{curBrand.name}</span>
                              </div>
                              <p className="text-[11px] text-slate-300 line-clamp-1">{curBrand.role}</p>
                            </div>
                          </div>

                          <div className="p-3 bg-black/95 border-t border-slate-800 flex items-center justify-between text-xs gap-2">
                            <span className="text-slate-300 font-medium text-[11px] truncate">
                              {curBrand.feature}
                            </span>
                            <span className="font-num text-cyan-400 font-bold shrink-0 flex items-center gap-1 text-[11px]">
                              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
                              کالیبراسیون رسمی
                            </span>
                          </div>
                        </div>
                      );
                    }

                    // Default / Main Slide Visual
                    return (
                      <div className={`rounded-2xl overflow-hidden border ${theme.borderPrimary} shadow-2xl bg-black group relative cursor-pointer`}>
                        <div className="overflow-hidden relative h-64 sm:h-72">
                          <img
                            src={currentSlide.image}
                            alt={currentSlide.title}
                            className="w-full h-full object-cover transform transition-transform duration-700 ease-out group-hover:scale-105"
                            referrerPolicy="no-referrer"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/25 to-transparent opacity-60 group-hover:opacity-40 transition-opacity" />
                          
                          {/* Interactive Badge on Image */}
                          <div className="absolute top-3 start-3 px-2.5 py-1 rounded-lg bg-black/75 backdrop-blur-xs border border-white/20 text-white text-[11px] font-bold flex items-center gap-1.5">
                            <Eye className="w-3.5 h-3.5 text-rose-400" />
                            <span>انبار مرکزی اهواز (طالقانی)</span>
                          </div>
                        </div>

                        <div className="p-3 bg-black/95 border-t border-slate-800 flex items-center justify-between text-xs">
                          <span className="text-slate-300 font-medium text-[11px]">
                            بزرگترین دپوی تجهیزات ابزاردقیق و کالیبراسیون خوزستان
                          </span>
                          <span className="font-num text-emerald-400 font-bold flex items-center gap-1 text-[11px]">
                            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                            انبار فعال اهواز
                          </span>
                        </div>
                      </div>
                    );
                  })()}
                </div>
              </div>
            );
          })()}

          {/* Bottom Slide Indicators & Controls */}
          {activeSlides.length > 1 && (
            <div className="pt-6 mt-6 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-3 text-xs">
              {/* Slide Pill Tabs */}
              <div className="flex items-center gap-1.5 flex-wrap">
                {activeSlides.map((slide, idx) => {
                  const isActive = idx === (currentSlideIndex % activeSlides.length);
                  return (
                    <button
                      key={slide.id}
                      type="button"
                      onClick={() => setCurrentSlideIndex(idx)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                        isActive
                          ? 'bg-rose-600 text-white shadow-md shadow-rose-950/60'
                          : 'bg-slate-900/80 text-slate-400 hover:text-white border border-slate-800'
                      }`}
                    >
                      <span className="font-num">{idx + 1}.</span>
                      <span className="hidden sm:inline truncate max-w-[150px]">
                        {slide.type === 'main'
                          ? 'انبار اهواز'
                          : slide.type === 'new_products'
                          ? 'جدیدترین محصولات'
                          : slide.type === 'brands'
                          ? 'برندهای مرجع'
                          : slide.title}
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* Autoplay & Speed Status Badge */}
              <div className="flex items-center gap-2 text-[11px] text-slate-400 font-num">
                {isBannerHovered ? (
                  <span className="text-amber-400 flex items-center gap-1 font-bold">
                    <Pause className="w-3.5 h-3.5" />
                    <span>توقف تایمر هنگام مطالعه</span>
                  </span>
                ) : (
                  <span className="flex items-center gap-1">
                    <Timer className="w-3.5 h-3.5 text-rose-400 animate-spin" style={{ animationDuration: '6s' }} />
                    <span>گردش خودکار هر {bannerInterval} ثانیه</span>
                  </span>
                )}
              </div>
            </div>
          )}
        </div>
      </section>

      {/* =========================================================================
          3.5 SPECIAL OFFERS 24H SECTION (پیشنهادات شگفت‌انگیز ۲۴ ساعته انبار اهواز)
         ========================================================================= */}
      {specialOffers.enabled && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-6">
          <div className="relative overflow-hidden rounded-3xl border-2 border-rose-500/80 bg-gradient-to-br from-rose-950/40 via-slate-900/95 to-amber-950/30 p-5 sm:p-7 shadow-2xl ring-1 ring-rose-500/30 space-y-6">
            
            {/* Top Glowing Gradient Accent */}
            <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-rose-600 via-amber-500 to-rose-600" />

            {/* Header: Title + Live Countdown Timer */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800/80">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-500 shadow-inner">
                    <Flame className="w-5 h-5 text-rose-500 animate-pulse" />
                  </div>
                  <h2 className="text-lg sm:text-xl font-black text-white flex items-center gap-2">
                    <span>{specialOffers.title}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-600 text-white font-bold">
                      محدود
                    </span>
                  </h2>
                </div>
                <p className="text-xs text-slate-300">
                  {specialOffers.subtitle}
                </p>
              </div>

              {/* Live Industrial Countdown Clock */}
              <div className="flex items-center gap-3 bg-black/60 border border-rose-500/40 rounded-2xl px-4 py-2.5 shadow-inner shrink-0 self-start md:self-auto">
                <div className="flex items-center gap-1.5 text-rose-400 font-bold text-xs">
                  <Clock className="w-4 h-4 animate-spin" style={{ animationDuration: '8s' }} />
                  <span className="hidden sm:inline">مهلت باقی‌مانده:</span>
                </div>

                {!isSpecialExpired ? (
                  <div className="flex items-center gap-1 font-num text-xs font-black">
                    {/* Hours */}
                    <div className="bg-slate-900 border border-slate-700 px-2 py-1 rounded-lg text-white min-w-[32px] text-center shadow-xs">
                      {String(specialHours).padStart(2, '0')}
                    </div>
                    <span className="text-rose-500 animate-pulse font-bold">:</span>
                    {/* Minutes */}
                    <div className="bg-slate-900 border border-slate-700 px-2 py-1 rounded-lg text-white min-w-[32px] text-center shadow-xs">
                      {String(specialMinutes).padStart(2, '0')}
                    </div>
                    <span className="text-rose-500 animate-pulse font-bold">:</span>
                    {/* Seconds */}
                    <div className="bg-rose-950/80 border border-rose-600/60 px-2 py-1 rounded-lg text-rose-300 min-w-[32px] text-center shadow-xs">
                      {String(specialSeconds).padStart(2, '0')}
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-amber-400">مهلت این دوره به پایان رسید</span>
                    {isAdminAuthenticated && (
                      <button
                        type="button"
                        onClick={() => handleResetSpecialOffersTimer(24)}
                        className="px-2 py-1 rounded-lg bg-amber-500 text-slate-950 font-bold text-[10px] hover:bg-amber-400"
                        title="تمدید ۲۴ ساعته از طرف مدیر"
                      >
                        تمدید ۲۴h
                      </button>
                    )}
                  </div>
                )}
              </div>
            </div>

            {/* Special Products Cards Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {specialOffers.items.map((offerItem) => {
                const prod = productsList.find((p) => p.id === offerItem.productId);
                if (!prod) return null;
                const discountedPrice = Math.round(prod.price * (1 - offerItem.discountPercent / 100));
                const snappInstallment = Math.round(discountedPrice / 4);

                return (
                  <div
                    key={offerItem.productId}
                    className="rounded-2xl border border-rose-500/40 hover:border-rose-500 bg-slate-900/90 p-4 space-y-3.5 transition-all shadow-lg hover:shadow-rose-950/40 relative overflow-hidden flex flex-col justify-between group"
                  >
                    {/* Top Corner Discount Badge */}
                    <div className="absolute top-3 end-3 z-10 px-2.5 py-1 rounded-xl bg-gradient-to-r from-rose-600 to-amber-500 text-white font-num font-black text-xs shadow-md">
                      {offerItem.discountPercent}٪ تخفیف ۲۴h
                    </div>

                    <div>
                      {/* Image Thumbnail */}
                      <div className="relative rounded-xl overflow-hidden bg-black h-40 sm:h-44 border border-slate-800">
                        <img
                          src={prod.image}
                          alt={prod.name}
                          className="w-full h-full object-cover transform transition-transform duration-500 group-hover:scale-105"
                        />
                        <div className="absolute top-2.5 start-2.5 px-2 py-0.5 rounded-md bg-black/70 backdrop-blur-xs text-[10px] font-bold text-slate-300 font-num">
                          {prod.brand}
                        </div>
                      </div>

                      {/* Info */}
                      <div className="pt-3 space-y-1">
                        <div className="flex items-center gap-1.5 text-[10px] font-bold text-amber-400">
                          <Sparkles className="w-3 h-3 text-amber-400" />
                          <span>{offerItem.customBadge || 'پیشنهاد شگفت‌انگیز ۲۴ ساعته'}</span>
                        </div>
                        <h3 className="font-bold text-sm text-white line-clamp-1">{prod.name}</h3>
                        <p className="text-[11px] text-slate-400 font-num font-medium">{prod.model}</p>
                      </div>
                    </div>

                    {/* Pricing & Stock Status */}
                    <div className="space-y-3 pt-2 border-t border-slate-800/80">
                      {/* Pricing Row */}
                      <div className="flex items-baseline justify-between font-num">
                        <div className="space-y-0.5">
                          <span className="text-slate-500 line-through text-xs block">
                            {prod.price.toLocaleString('en-US')} تومان
                          </span>
                          <span className="text-base font-black text-rose-400">
                            {discountedPrice.toLocaleString('en-US')}{' '}
                            <span className="text-xs font-sans text-slate-300">تومان</span>
                          </span>
                        </div>

                        {/* SnappPay 4 installments breakdown */}
                        <div className="text-left">
                          <span className="text-[9px] text-sky-400 block font-bold">اسنپ‌پی ۴ قسط:</span>
                          <span className="text-xs font-bold text-sky-300">
                            {snappInstallment.toLocaleString('en-US')} ت/ماه
                          </span>
                        </div>
                      </div>

                      {/* Warehouse Stock Urgency Bar */}
                      <div className="space-y-1">
                        <div className="flex items-center justify-between text-[10px] text-slate-400 font-num">
                          <span>انبار مرکزی اهواز</span>
                          <span className="text-amber-400 font-bold">
                            تنها {offerItem.stockLeft} دستگاه باقی مانده
                          </span>
                        </div>
                        <div className="h-1.5 rounded-full bg-slate-800 overflow-hidden">
                          <div
                            className="h-full bg-gradient-to-r from-rose-500 to-amber-400 rounded-full"
                            style={{ width: `${Math.max(20, Math.min(90, (offerItem.stockLeft / 10) * 100))}%` }}
                          />
                        </div>
                      </div>

                      {/* Add to Cart Button */}
                      <button
                        type="button"
                        onClick={() => handleAddSpecialOfferToCart(prod, offerItem.discountPercent)}
                        className={`w-full py-2.5 rounded-xl ${theme.accentBtn} font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-all cursor-pointer`}
                      >
                        <ShoppingCart className="w-4 h-4" />
                        <span>افزودن به سبد با تخفیف ویژه</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>
      )}

      {/* =========================================================================
          4. PRODUCT CATALOG (تک‌دکمه‌ای و بدون دکمه‌های آزاردهنده پیش‌فاکتور)
         ========================================================================= */}
      <section id="catalog" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* Category & Brand Filters */}
        <div className="flex flex-wrap items-center justify-between gap-4 pb-2 border-b border-slate-800">
          <div className="flex flex-wrap gap-2">
            {[
              { id: 'all', label: 'تمامی تجهیزات' },
              { id: 'multimeter', label: 'مولتی‌متر و کلمپ' },
              { id: 'megger', label: 'میگر و عایق‌سنج' },
              { id: 'thermal', label: 'ترموویژن' },
              { id: 'hydraulic', label: 'پرس کابلشو' },
              { id: 'calibrator', label: 'کالیبراتور فرآیندی' },
            ].map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${
                  selectedCategory === cat.id
                    ? `${theme.accentBtn} shadow-xs font-semibold`
                    : 'bg-slate-900/80 text-slate-300 border border-slate-800 hover:bg-slate-800 hover:text-white'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-400 font-medium">برند:</span>
            <select
              value={selectedBrand}
              onChange={(e) => setSelectedBrand(e.target.value)}
              className="px-3 py-1.5 text-xs rounded-xl border border-slate-800 bg-slate-900 text-slate-200 focus:outline-none"
            >
              <option value="all">تمامی برندها</option>
              <option value="UNI-T">UNI-T</option>
              <option value="Mastech">Mastech</option>
              <option value="Kyoritsu">Kyoritsu</option>
              <option value="Pishgam">پیشگام صنعت</option>
            </select>
          </div>
        </div>

        {/* Product Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProducts.map((product) => {
            const isComparing = compareList.some((p) => p.id === product.id);
            const inCart = cartItems.find((ci) => ci.product.id === product.id);

            return (
              <div
                key={product.id}
                className={`${theme.bgCard} border ${theme.borderPrimary} rounded-2xl overflow-hidden hover:border-slate-600 transition-all flex flex-col justify-between shadow-xs group`}
              >
                <div>
                  {/* Thumbnail */}
                  <div className="relative h-48 bg-black overflow-hidden">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300 opacity-90"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute top-3 start-3 px-2.5 py-0.5 rounded-lg bg-black/90 text-white text-xs font-num font-bold border border-slate-800">
                      {product.brand}
                    </div>
                    <div className="absolute top-3 end-3 px-2 py-0.5 rounded bg-emerald-950/80 border border-emerald-700/60 text-emerald-300 text-[11px] font-semibold">
                      موجود در انبار
                    </div>
                  </div>

                  {/* Body Info */}
                  <div className="p-5 space-y-3">
                    <div className="flex items-center justify-between text-xs text-slate-400 font-num">
                      <span className={`font-bold ${theme.accentText}`}>{product.model}</span>
                      <span>{product.categoryLabelFa}</span>
                    </div>

                    <h3 className="text-sm font-bold text-white leading-snug">
                      {product.name}
                    </h3>

                    {/* Specs Box with clean numbers */}
                    <div className="space-y-1 text-xs text-slate-300 bg-black/50 p-3 rounded-xl border border-slate-800/80 font-num">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] text-slate-400 font-sans">رنج کاری:</span>
                        <span className="font-semibold">{product.specs.voltageRange}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] text-slate-400 font-sans">ایمنی صنعتی:</span>
                        <span className="font-semibold">{product.specs.safetyRating}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Price & Single Clear Add-to-Cart Action (No intrusive RFQ buttons!) */}
                <div className="p-5 pt-0 border-t border-slate-800 mt-2 space-y-2.5">
                  <div className="pt-3 space-y-1.5 font-num">
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-slate-400 font-sans">قیمت نقدی انبار:</span>
                      <span className="text-base font-bold text-white">
                        {product.price.toLocaleString('en-US')} <span className="text-xs font-normal font-sans text-slate-400">تومان</span>
                      </span>
                    </div>

                    {/* SnappPay 4-Installment Pill & TorobPay */}
                    <div className="flex items-center justify-between text-[11px] px-2.5 py-1.5 rounded-xl bg-sky-950/40 border border-sky-600/40">
                      <div className="flex items-center gap-1.5 text-sky-300 font-medium">
                        <div className="bg-white rounded px-1 py-0.2 shrink-0">
                          <img
                            src="/public/assets/aistudio/_____e54e8233.png"
                            alt="Snapp! Pay"
                            className="h-3.5 w-auto object-contain"
                            onError={(e) => {
                              (e.target as HTMLImageElement).src = '/public/snapp-pay-official.png';
                            }}
                          />
                        </div>
                        <span className="font-sans text-[10px]">۴ قسط ماهانه:</span>
                      </div>
                      <span className="font-bold text-white text-[11px]">
                        {Math.round(product.price / 4).toLocaleString('en-US')} ت
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-[10px] text-amber-300/90 px-1">
                      <span className="flex items-center gap-1.5">
                        <FileText className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                        <span>امکان خرید اقساطی با چک صیادی</span>
                      </span>
                      <span className="text-slate-400 font-sans">تحویل فوری</span>
                    </div>
                  </div>

                  {/* FOCUSED ADD TO CART & SPECS BUTTONS */}
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => handleAddToCart(product)}
                      className={`flex items-center justify-center gap-1.5 py-2 px-2.5 text-[11px] font-medium rounded-lg transition-colors shadow-2xs ${
                        inCart
                          ? 'bg-emerald-600 hover:bg-emerald-500 text-white font-semibold'
                          : `${theme.accentBtn}`
                      }`}
                    >
                      <ShoppingCart className="w-3.5 h-3.5" />
                      <span>{inCart ? `در سبد (${inCart.quantity}) +` : 'افزودن به سبد'}</span>
                    </button>

                    <button
                      onClick={() => setActiveModalProduct(product)}
                      className="flex items-center justify-center gap-1.5 py-2 px-2.5 text-[11px] font-medium rounded-lg border border-slate-700/80 hover:bg-slate-800 text-slate-300 transition-colors"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>مشخصات فنی</span>
                    </button>
                  </div>

                  {/* Assurance guarantee note */}
                  <div className="flex items-center justify-between pt-1 text-[11px] text-slate-400">
                    <span className="flex items-center gap-1 text-emerald-400/90 font-medium">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      <span>تضمین اصالت و کالیبراسیون کالا</span>
                    </span>
                    <span className="text-slate-500 font-sans">انبار اهواز</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* =========================================================================
          5. PROMINENT OFFICIAL AGENCIES & REPRESENTATION SECTION
             (بخش ویژه و برجسته نمایندگی‌های رسمی پیشگام صنعت در فوتر)
         ========================================================================= */}
      <section id="agencies" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className={`${theme.bgSurface} border ${theme.borderPrimary} rounded-3xl p-6 sm:p-10 shadow-xl space-y-8`}>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-800">
            <div>
              <div className={`inline-flex items-center gap-1.5 text-xs font-bold ${theme.accentText} mb-1`}>
                <Award className="w-4 h-4" />
                <span>اصالت و اعتبار شرکتی</span>
              </div>
              <h2 className={`text-xl sm:text-2xl font-extrabold ${theme.textHeading}`}>
                نمایندگی‌های رسمی و برندهای تحت پوشش پیشگام صنعت
              </h2>
              <p className={`text-xs ${theme.textBody} mt-1`}>
                تأمین بی‌واسطه، تضمین اصالت ۱۰۰٪ قطعات، گواهی کالیبراسیون و ارائه خدمات پس از فروش در انبار اهواز
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <span className="px-3.5 py-1.5 rounded-xl bg-emerald-950/70 border border-emerald-700/60 text-emerald-300 text-xs font-bold flex items-center gap-1.5 shadow-xs">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>دارای پروانه کسب و گواهی کالیبراسیون معتبر از اتحادیه ابزار صنعتی</span>
              </span>
            </div>
          </div>

          {/* Prominent Agency Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
            {agenciesList.map((agency, idx) => (
              <div
                key={agency.id || idx}
                className={`${theme.bgCard} border ${theme.cardBorder} rounded-2xl p-5 space-y-4 hover:border-slate-500 transition-all flex flex-col justify-between shadow-md relative overflow-hidden`}
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-num font-bold text-slate-400">0{idx + 1}.</span>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${theme.isLight ? 'bg-slate-200 text-slate-700 border-slate-300' : 'bg-slate-800 text-slate-300 border-slate-700'} border`}>
                      {agency.country}
                    </span>
                  </div>

                  <div>
                    <h3 className={`text-base font-extrabold ${theme.textHeading} font-num`}>
                      {agency.name}
                    </h3>
                    <div className={`text-xs font-bold ${theme.accentText} mt-0.5`}>
                      {agency.role}
                    </div>
                  </div>

                  <p className={`text-xs ${theme.textBody} leading-relaxed`}>
                    {agency.description}
                  </p>
                </div>

                <div className="pt-3 border-t border-slate-800/60 space-y-2">
                  <div className="text-[10px] font-bold text-emerald-400 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>{agency.badge}</span>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {agency.specialties.map((spec, sIdx) => (
                      <span key={sIdx} className={`text-[10px] ${theme.isLight ? 'bg-slate-100 text-slate-600 border-slate-200' : 'bg-slate-900 text-slate-400 border-slate-800'} px-2 py-0.5 rounded border`}>
                        {spec}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Verification Banner */}
          <div className={`p-4 rounded-2xl ${theme.innerBg} border ${theme.borderPrimary} flex flex-col sm:flex-row items-center justify-between gap-4 text-xs ${theme.textBody}`}>
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
              <span>
                کلیه دستگاه‌های ارسالی از انبار اهواز دارای **هولوگرام اصالت، سریال معتبر سازنده و سرتیفیکیت کالیبراسیون** می‌باشند.
              </span>
            </div>
            <a
              href="tel:06132230000"
              className={`px-4 py-1.5 rounded-xl ${theme.accentBtn} font-bold whitespace-nowrap`}
            >
              استعلام گارانتی و اصالت
            </a>
          </div>
        </div>
      </section>

      {/* Modal for Manager to Edit / Customize Agencies */}
      {showAgencyModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-3xl p-5 sm:p-6 space-y-5 shadow-2xl text-xs max-h-[92vh] flex flex-col my-auto text-slate-200">
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 shrink-0">
              <div className="flex items-center gap-2">
                <Edit3 className="w-4 h-4 text-amber-400" />
                <h3 className="font-bold text-sm text-white">ویرایش و شخصی‌سازی نمایندگی‌های رسمی (پیشگام صنعت)</h3>
              </div>
              <button
                onClick={() => setShowAgencyModal(false)}
                className="text-slate-400 hover:text-white p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Quick Presets */}
            <div className="bg-slate-800/80 p-3.5 rounded-2xl border border-slate-700/80 space-y-2 shrink-0">
              <div className="text-[11px] font-bold text-amber-300 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                <span>بارگذاری سریع پکیج‌های پیشنهادی جهت ارائه به کارفرما:</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {AGENCY_PRESETS.map((p, pIdx) => (
                  <button
                    key={pIdx}
                    onClick={() => handleLoadAgencyPreset(p.items)}
                    className="px-2.5 py-1 rounded-xl bg-slate-900 hover:bg-slate-700 border border-slate-700 text-slate-300 hover:text-white text-[11px] font-semibold transition-colors"
                  >
                    {p.title}
                  </button>
                ))}
              </div>
            </div>

            {/* Agency Items List */}
            <div className="flex-1 overflow-y-auto space-y-4 pe-1">
              {tempAgencies.map((agency, aIdx) => (
                <div key={agency.id || aIdx} className="p-4 rounded-2xl bg-black/40 border border-slate-800 space-y-3 relative group">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-amber-400 text-xs">کارت نمایندگی #{aIdx + 1}</span>
                    <button
                      onClick={() => handleRemoveAgency(aIdx)}
                      className="text-rose-400 hover:text-rose-300 text-[11px] flex items-center gap-1 px-2 py-0.5 rounded hover:bg-rose-950/40"
                    >
                      <Trash2 className="w-3 h-3" />
                      <span>حذف</span>
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-slate-400 mb-1 text-[11px]">نام برند و کمپانی:</label>
                      <input
                        type="text"
                        value={agency.name}
                        onChange={(e) => handleUpdateAgencyField(aIdx, 'name', e.target.value)}
                        className="w-full p-2 rounded-xl border border-slate-700 bg-slate-800 text-white font-bold"
                        placeholder="مثال: FLUKE (فلوک)"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-400 mb-1 text-[11px]">کشور و استاندارد:</label>
                      <input
                        type="text"
                        value={agency.country}
                        onChange={(e) => handleUpdateAgencyField(aIdx, 'country', e.target.value)}
                        className="w-full p-2 rounded-xl border border-slate-700 bg-slate-800 text-white"
                        placeholder="مثال: ایالات متحده آمریکا"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-slate-400 mb-1 text-[11px]">سطح نمایندگی / عاملیت:</label>
                      <input
                        type="text"
                        value={agency.role}
                        onChange={(e) => handleUpdateAgencyField(aIdx, 'role', e.target.value)}
                        className="w-full p-2 rounded-xl border border-slate-700 bg-slate-800 text-white"
                        placeholder="مثال: نمایندگی رسمی فروش در خوزستان"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-400 mb-1 text-[11px]">برچسب تاییدیه / گواهی:</label>
                      <input
                        type="text"
                        value={agency.badge}
                        onChange={(e) => handleUpdateAgencyField(aIdx, 'badge', e.target.value)}
                        className="w-full p-2 rounded-xl border border-slate-700 bg-slate-800 text-emerald-400"
                        placeholder="مثال: سرتیفیکیت کالیبراسیون رسمی"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-slate-400 mb-1 text-[11px]">توضیحات و سوابق تأمین:</label>
                    <textarea
                      rows={2}
                      value={agency.description}
                      onChange={(e) => handleUpdateAgencyField(aIdx, 'description', e.target.value)}
                      className="w-full p-2 rounded-xl border border-slate-700 bg-slate-800 text-white leading-relaxed"
                      placeholder="توضیح کوتاه درباره محصولات و خدمات این برند در انبار اهواز..."
                    />
                  </div>

                  <div>
                    <label className="block text-slate-400 mb-1 text-[11px]">دسته‌بندی تجهیزات شاخص (با ویرگول جدا کنید):</label>
                    <input
                      type="text"
                      value={agency.specialties.join('، ')}
                      onChange={(e) =>
                        handleUpdateAgencyField(
                          aIdx,
                          'specialties',
                          e.target.value.split(/[,،]+/).map((s) => s.trim()).filter(Boolean)
                        )
                      }
                      className="w-full p-2 rounded-xl border border-slate-700 bg-slate-800 text-slate-300"
                      placeholder="مثال: مولتی‌متر True RMS، کلمپ آمپرمتر، میگر"
                    />
                  </div>
                </div>
              ))}

              <button
                onClick={handleAddAgency}
                className="w-full py-2.5 rounded-xl border border-dashed border-slate-700 hover:border-slate-500 bg-slate-800/50 hover:bg-slate-800 text-slate-300 hover:text-white font-bold flex items-center justify-center gap-2 transition-colors"
              >
                <Plus className="w-4 h-4 text-emerald-400" />
                <span>افزودن برند یا نمایندگی جدید به لیست</span>
              </button>
            </div>

            {/* Modal Actions */}
            <div className="flex items-center justify-between pt-3 border-t border-slate-800 shrink-0">
              <button
                onClick={handleResetAgencies}
                className="text-slate-400 hover:text-white underline text-[11px]"
              >
                بازنشانی به حالت پیش‌فرض اولیه
              </button>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setShowAgencyModal(false)}
                  className="px-3.5 py-1.5 rounded-xl border border-slate-700 text-slate-300 hover:bg-slate-800"
                >
                  انصراف
                </button>
                <button
                  onClick={handleSaveAgencies}
                  className="px-4 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold flex items-center gap-1.5 shadow-xs"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>ذخیره و اعمال در سایت</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          6. SHOPPING CART DRAWER (سبد خرید کشویی تیره)
         ========================================================================= */}
      {cartDrawerOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden bg-black/70 backdrop-blur-xs flex justify-end">
          <div className={`w-full max-w-[340px] sm:max-w-[360px] ${theme.bgSurface} h-full shadow-2xl flex flex-col justify-between border-s ${theme.borderPrimary} animate-in slide-in-from-right duration-200`}>
            {/* Drawer Header - Compact */}
            <div className="p-3.5 sm:p-4 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShoppingCart className={`w-4 h-4 ${theme.accentText}`} />
                <h2 className="text-sm font-bold text-white">
                  سبد خرید ({cartTotalQty} قلم)
                </h2>
              </div>
              <button
                onClick={() => setCartDrawerOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white transition-colors"
                title="بستن"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Cart Items List - Sleek & Compact */}
            <div className="flex-1 overflow-y-auto p-3 sm:p-3.5 space-y-2.5">
              {cartItems.length === 0 ? (
                <div className="text-center py-12 space-y-2.5">
                  <div className="w-12 h-12 rounded-full bg-slate-800/80 flex items-center justify-center mx-auto text-slate-500">
                    <ShoppingCart className="w-6 h-6" />
                  </div>
                  <h3 className="text-xs font-bold text-white">سبد خرید شما خالی است</h3>
                  <p className="text-[11px] text-slate-400">کالاهای مورد نظر را به سبد خرید اضافه نمایید.</p>
                </div>
              ) : (
                cartItems.map((item) => (
                  <div
                    key={item.product.id}
                    className="p-2.5 rounded-xl border border-slate-800/80 bg-black/40 flex items-center gap-2.5"
                  >
                    <img
                      src={item.product.image}
                      alt={item.product.name}
                      className="w-11 h-11 rounded-lg object-cover border border-slate-800 shrink-0"
                    />

                    <div className="flex-1 min-w-0 space-y-0.5">
                      <h4 className="text-xs font-bold text-white truncate max-w-[145px]">{item.product.name}</h4>
                      <div className={`text-[10px] font-num font-semibold ${theme.accentText}`}>{item.product.model}</div>
                      <div className="text-[11px] font-num font-bold text-slate-200">
                        {item.product.price.toLocaleString('en-US')} ت
                      </div>
                    </div>

                    {/* Quantity Controls - Compact */}
                    <div className="flex flex-col items-end gap-1 shrink-0">
                      <button
                        onClick={() => handleRemoveFromCart(item.product.id)}
                        className="text-slate-500 hover:text-rose-400 p-0.5"
                        title="حذف"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>

                      <div className="flex items-center gap-0.5 border border-slate-700 rounded-md px-1.5 py-0.2 bg-slate-900 font-num">
                        <button
                          onClick={() => handleUpdateCartQty(item.product.id, -1)}
                          className="text-slate-400 hover:text-white p-0.5"
                        >
                          <Minus className="w-2.5 h-2.5" />
                        </button>
                        <span className="font-bold text-[11px] px-1">{item.quantity}</span>
                        <button
                          onClick={() => handleUpdateCartQty(item.product.id, 1)}
                          className="text-slate-400 hover:text-white p-0.5"
                        >
                          <Plus className="w-2.5 h-2.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Cart Footer - Compact */}
            {cartItems.length > 0 && (
              <div className="p-3.5 sm:p-4 border-t border-slate-800 bg-black/60 space-y-2.5 font-num text-xs">
                <div className="flex items-center justify-between text-slate-400 text-[11px]">
                  <span className="font-sans">مجموع اقلام:</span>
                  <span className="font-bold text-white">{cartSubtotal.toLocaleString('en-US')} تومان</span>
                </div>

                <div className="flex items-center justify-between text-xs font-bold pt-1.5 border-t border-slate-800 text-white">
                  <span className="font-sans">مبلغ کل سفارش:</span>
                  <span className={`${theme.accentText} text-sm`}>{cartFinalTotal.toLocaleString('en-US')} تومان</span>
                </div>

                {/* SnappPay 4 installments breakdown in Cart */}
                <div className="p-2 rounded-xl bg-sky-950/40 border border-sky-600/40 space-y-0.5 text-[11px]">
                  <div className="flex items-center justify-between text-sky-300 font-bold">
                    <span className="font-sans flex items-center gap-1">
                      <span className="px-1 py-0.2 rounded bg-sky-500 text-slate-950 text-[9px] font-black">SnappPay</span>
                      <span>۴ قسط ماهیانه:</span>
                    </span>
                    <span className="text-white font-num font-bold text-[11px]">
                      {Math.round(cartFinalTotal / 4).toLocaleString('en-US')} ت/ماه
                    </span>
                  </div>
                </div>

                {/* Check Installment info */}
                <div className="flex items-center justify-between text-[10px] px-2 py-1 rounded-lg bg-amber-950/30 border border-amber-800/50 text-amber-300">
                  <span className="flex items-center gap-1">
                    <FileText className="w-3 h-3 text-amber-400" />
                    <span>اقساط با چک صیادی (اهواز)</span>
                  </span>
                  <button
                    type="button"
                    onClick={() => setShowInstallmentTermsModal(true)}
                    className="text-[10px] text-amber-300 hover:text-white underline font-bold"
                  >
                    شرایط
                  </button>
                </div>

                <button
                  onClick={handleOpenCheckout}
                  className={`w-full py-2.5 ${theme.accentBtn} rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm transition-all`}
                >
                  <CreditCard className="w-3.5 h-3.5" />
                  <span className="font-sans">ادامه ثبت سفارش و تسویه‌حساب</span>
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* =========================================================================
          7. FLAWLESS 3-STEP CHECKOUT MODAL
         ========================================================================= */}
      {checkoutModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 overflow-y-auto">
          <div className={`${theme.bgSurface} border ${theme.borderPrimary} rounded-3xl w-full max-w-3xl p-5 sm:p-7 space-y-5 shadow-2xl my-auto max-h-[92vh] overflow-y-auto`}>
            
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <CreditCard className={`w-5 h-5 ${theme.accentText}`} />
                <div>
                  <h3 className="text-base font-bold text-white">
                    مراحل ثبت سفارش و تسویه‌حساب (پیشگام صنعت اهواز)
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    تجهیزات تست، اندازه‌گیری و ابزاردقیق با ضمانت کالیبراسیون انبار مرکزی
                  </p>
                </div>
              </div>
              <button
                onClick={() => setCheckoutModalOpen(false)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                title="بستن"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Stepper Progress Bar */}
            <div className="grid grid-cols-4 gap-2 pt-1 pb-3 text-[11px] font-medium border-b border-slate-800">
              {/* Step 1: Address */}
              <button
                type="button"
                onClick={() => checkoutStep !== 'gateway' && setCheckoutStep('address')}
                className={`flex flex-col sm:flex-row items-center justify-center gap-1.5 p-2 rounded-xl text-center transition-all ${
                  checkoutStep === 'address'
                    ? `${theme.bgCard} text-white font-bold ring-1 ring-white/20 shadow-xs`
                    : checkoutStep === 'payment' || checkoutStep === 'gateway' || checkoutStep === 'success'
                    ? 'text-emerald-400 bg-emerald-950/30 hover:bg-emerald-950/50'
                    : 'text-slate-400 bg-slate-900/40'
                }`}
              >
                <div className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0 ${
                  checkoutStep === 'address' ? `${theme.accentBtn} text-white` : 'bg-emerald-500 text-slate-950'
                }`}>
                  {checkoutStep === 'address' ? '۱' : <Check className="w-3 h-3" />}
                </div>
                <span className="truncate">۱. آدرس و مشخصات</span>
              </button>

              {/* Step 2: Shipping & Payment */}
              <button
                type="button"
                onClick={() => {
                  if (checkoutStep === 'address') {
                    if (!customerName.trim() || !customerPhone.trim() || !customerAddress.trim()) {
                      alert('لطفاً ابتدا نام تحویل‌گیرنده، شماره تماس و آدرس را تکمیل کنید.');
                      return;
                    }
                  }
                  if (checkoutStep !== 'gateway') setCheckoutStep('payment');
                }}
                className={`flex flex-col sm:flex-row items-center justify-center gap-1.5 p-2 rounded-xl text-center transition-all ${
                  checkoutStep === 'payment'
                    ? `${theme.bgCard} text-white font-bold ring-1 ring-white/20 shadow-xs`
                    : checkoutStep === 'gateway' || checkoutStep === 'success'
                    ? 'text-emerald-400 bg-emerald-950/30 hover:bg-emerald-950/50'
                    : 'text-slate-400 bg-slate-900/40'
                }`}
              >
                <div className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0 ${
                  checkoutStep === 'payment' ? `${theme.accentBtn} text-white` : checkoutStep === 'gateway' || checkoutStep === 'success' ? 'bg-emerald-500 text-slate-950' : 'bg-slate-800 text-slate-400'
                }`}>
                  {checkoutStep === 'gateway' || checkoutStep === 'success' ? <Check className="w-3 h-3" /> : '۲'}
                </div>
                <span className="truncate">۲. ارسال و پرداخت</span>
              </button>

              {/* Step 3: Secure Gateway */}
              <div
                className={`flex flex-col sm:flex-row items-center justify-center gap-1.5 p-2 rounded-xl text-center transition-all ${
                  checkoutStep === 'gateway'
                    ? 'bg-amber-950/50 text-amber-300 font-bold ring-1 ring-amber-500/50'
                    : checkoutStep === 'success'
                    ? 'text-emerald-400 bg-emerald-950/30'
                    : 'text-slate-500 bg-slate-900/30'
                }`}
              >
                <div className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0 ${
                  checkoutStep === 'gateway' ? 'bg-amber-500 text-slate-950' : checkoutStep === 'success' ? 'bg-emerald-500 text-slate-950' : 'bg-slate-800 text-slate-500'
                }`}>
                  {checkoutStep === 'success' ? <Check className="w-3 h-3" /> : '۳'}
                </div>
                <span className="truncate">۳. درگاه پرداخت امن</span>
              </div>

              {/* Step 4: Invoice & Tracking */}
              <div
                className={`flex flex-col sm:flex-row items-center justify-center gap-1.5 p-2 rounded-xl text-center transition-all ${
                  checkoutStep === 'success'
                    ? 'bg-emerald-950/50 text-emerald-300 font-bold ring-1 ring-emerald-500/50'
                    : 'text-slate-500 bg-slate-900/30'
                }`}
              >
                <div className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0 ${
                  checkoutStep === 'success' ? 'bg-emerald-500 text-slate-950' : 'bg-slate-800 text-slate-500'
                }`}>
                  {checkoutStep === 'success' ? <Check className="w-3 h-3" /> : '۴'}
                </div>
                <span className="truncate">۴. فاکتور و رهگیری</span>
              </div>
            </div>

            {/* =========================================================================
                STEP 1: ADDRESS & RECIPIENT INFORMATION (اطلاعات و آدرس دقیق پستی)
               ========================================================================= */}
            {checkoutStep === 'address' && (
              <form onSubmit={handleProceedToPayment} className="space-y-4 text-xs">
                <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center gap-2.5">
                  <MapPin className={`w-4 h-4 ${theme.accentText} shrink-0`} />
                  <p className="text-[11px] text-slate-300 leading-relaxed">
                    لطفاً نشانی پستی دقیق و مشخصات تحویل‌گیرنده را وارد کنید. مرسولات از انبار مرکزی پیشگام صنعت اهواز با بسته‌بندی ایمن صنعتی ارسال می‌شوند.
                  </p>
                </div>

                {/* Recipient Personal Info */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-slate-300 mb-1 font-medium flex items-center gap-1">
                      <User className="w-3 h-3 text-slate-400" />
                      <span>نام و نام خانوادگی تحویل‌گیرنده *</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      placeholder="مثال: مهندس علی رضایی"
                      className="w-full p-2.5 rounded-xl border border-slate-700 bg-slate-900 text-white focus:outline-none focus:ring-1 focus:ring-rose-500 font-medium"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-300 mb-1 font-medium flex items-center gap-1">
                      <Phone className="w-3 h-3 text-slate-400" />
                      <span>شماره موبایل جهت پیامک رهگیری *</span>
                    </label>
                    <input
                      type="tel"
                      required
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      placeholder="09161112233"
                      className="w-full p-2.5 rounded-xl border border-slate-700 bg-slate-900 text-white focus:outline-none focus:ring-1 focus:ring-rose-500 font-num"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-300 mb-1 font-medium flex items-center gap-1">
                      <Phone className="w-3 h-3 text-slate-400" />
                      <span>تلفن ثابت / داخلی کارخانه (اختیاری)</span>
                    </label>
                    <input
                      type="tel"
                      value={customerLandline}
                      onChange={(e) => setCustomerLandline(e.target.value)}
                      placeholder="06134445566"
                      className="w-full p-2.5 rounded-xl border border-slate-700 bg-slate-900 text-white focus:outline-none focus:ring-1 focus:ring-rose-500 font-num"
                    />
                  </div>
                </div>

                {/* Province, City, Postal Code */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-slate-300 mb-1 font-medium">استان مقصد *</label>
                    <select
                      value={customerProvince}
                      onChange={(e) => setCustomerProvince(e.target.value)}
                      className="w-full p-2.5 rounded-xl border border-slate-700 bg-slate-900 text-white focus:outline-none focus:ring-1 focus:ring-rose-500"
                    >
                      <option value="خوزستان">خوزستان (مبدا انبار اهواز)</option>
                      <option value="تهران">تهران</option>
                      <option value="بوشهر">بوشهر (عسلویه و پارس جنوبی)</option>
                      <option value="اصفهان">اصفهان</option>
                      <option value="فارس">فارس (شیراز)</option>
                      <option value="هرمزگان">هرمزگان (بندرعباس)</option>
                      <option value="خراسان رضوی">خراسان رضوی (مشهد)</option>
                      <option value="آذربایجان شرقی">آذربایجان شرقی (تبریز)</option>
                      <option value="کرمان">کرمان</option>
                      <option value="سایر استان‌ها">سایر استان‌ها</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-slate-300 mb-1 font-medium">شهر مقصد *</label>
                    <input
                      type="text"
                      required
                      value={customerCity}
                      onChange={(e) => setCustomerCity(e.target.value)}
                      placeholder="مثال: اهواز، ماهشهر، آبادان، ..."
                      className="w-full p-2.5 rounded-xl border border-slate-700 bg-slate-900 text-white focus:outline-none focus:ring-1 focus:ring-rose-500"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-300 mb-1 font-medium">کد پستی ۱۰ رقمی *</label>
                    <input
                      type="text"
                      required
                      maxLength={10}
                      value={postalCode}
                      onChange={(e) => setPostalCode(e.target.value)}
                      placeholder="6164712345"
                      className="w-full p-2.5 rounded-xl border border-slate-700 bg-slate-900 text-white focus:outline-none focus:ring-1 focus:ring-rose-500 font-num"
                    />
                  </div>
                </div>

                {/* Detailed Street Address */}
                <div>
                  <label className="block text-slate-300 mb-1 font-medium flex items-center justify-between">
                    <span>نشانی کامل پستی (خیابان، کوچه / فاز صنعتی، پلاک، طبقه یا نام واحد صنعتی) *</span>
                    <span className="text-[10px] text-slate-500">جهت تحویل دقیق راننده یا مامور پست</span>
                  </label>
                  <textarea
                    rows={2}
                    required
                    value={customerAddress}
                    onChange={(e) => setCustomerAddress(e.target.value)}
                    placeholder="اهواز، کوی نفت، خیابان بهارستان، پلاک ۱۴..."
                    className="w-full p-2.5 rounded-xl border border-slate-700 bg-slate-900 text-white focus:outline-none focus:ring-1 focus:ring-rose-500 leading-relaxed"
                  />
                </div>

                {/* Delivery Notes */}
                <div>
                  <label className="block text-slate-400 mb-1 font-medium text-[11px]">
                    یادداشت ارسال یا هماهنگی انباردار (اختیاری):
                  </label>
                  <input
                    type="text"
                    value={orderNotes}
                    onChange={(e) => setOrderNotes(e.target.value)}
                    placeholder="مثال: تحویل به حراست کارخانه / تماس قبل از حرکت راننده"
                    className="w-full p-2 rounded-xl border border-slate-700/80 bg-slate-900/80 text-white text-[11px]"
                  />
                </div>

                {/* Corporate Official Tax Invoice Request Checkbox */}
                <div className="p-3 rounded-2xl bg-black/40 border border-slate-800 space-y-2.5">
                  <label className="flex items-center gap-2 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={needOfficialInvoice}
                      onChange={(e) => setNeedOfficialInvoice(e.target.checked)}
                      className="w-4 h-4 rounded border-slate-700 text-rose-600 focus:ring-rose-500"
                    />
                    <span className="text-xs font-bold text-slate-200">
                      درخواست صدور فاکتور رسمی حقوقی با ارزش افزوده (ماده ۱۶۹ م.م)
                    </span>
                  </label>

                  {needOfficialInvoice && (
                    <div className="pt-2 border-t border-slate-800/80 grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                      <div>
                        <label className="block text-[10px] text-slate-400 mb-1">نام رسمی شرکت / ارگان</label>
                        <input
                          type="text"
                          value={companyName}
                          onChange={(e) => setCompanyName(e.target.value)}
                          className="w-full p-2 rounded-xl border border-slate-700 bg-slate-900 text-white text-xs"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] text-slate-400 mb-1">شناسه ملی شرکت</label>
                        <input
                          type="text"
                          value={companyNationalId}
                          onChange={(e) => setCompanyNationalId(e.target.value)}
                          className="w-full p-2 rounded-xl border border-slate-700 bg-slate-900 text-white text-xs font-num"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] text-slate-400 mb-1">کد اقتصادی ۱۲ رقمی</label>
                        <input
                          type="text"
                          value={companyEconomicCode}
                          onChange={(e) => setCompanyEconomicCode(e.target.value)}
                          className="w-full p-2 rounded-xl border border-slate-700 bg-slate-900 text-white text-xs font-num"
                        />
                      </div>
                    </div>
                  )}
                </div>

                {/* Cart Items Mini Preview */}
                <div className="p-3 rounded-2xl bg-slate-900/60 border border-slate-800/80 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="flex -space-x-2 space-x-reverse overflow-hidden">
                      {cartItems.slice(0, 3).map((item, idx) => (
                        <img
                          key={idx}
                          src={item.product.image}
                          alt={item.product.name}
                          className="w-8 h-8 rounded-lg object-cover border border-slate-700 bg-slate-800"
                        />
                      ))}
                    </div>
                    <span className="text-slate-300 font-num">
                      {cartTotalQty} قلم کالا در سبد خرید
                    </span>
                  </div>
                  <div className="text-left font-num">
                    <span className="text-slate-400 text-[11px] block">جمع موقت:</span>
                    <span className="font-bold text-white text-xs">
                      {cartSubtotal.toLocaleString('en-US')} تومان
                    </span>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center justify-between pt-2">
                  <button
                    type="button"
                    onClick={() => setCheckoutModalOpen(false)}
                    className="px-4 py-2.5 rounded-xl border border-slate-700 text-slate-400 hover:text-white hover:bg-slate-800 font-medium"
                  >
                    انصراف
                  </button>
                  <button
                    type="submit"
                    className={`px-6 py-2.5 ${theme.accentBtn} rounded-xl font-bold text-xs flex items-center gap-2 shadow-md transition-all`}
                  >
                    <span>تأیید مشخصات و آدرس تحویل ← انتخاب شیوه پرداخت</span>
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                </div>
              </form>
            )}

            {/* =========================================================================
                STEP 2: SHIPPING METHOD & PAYMENT GATEWAY SELECTION
               ========================================================================= */}
            {checkoutStep === 'payment' && (
              <div className="space-y-4 text-xs">
                
                {/* Back to Address & Summary Card */}
                <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-emerald-700/50 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                  <div className="flex items-start gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2 font-bold text-white">
                        <span>تحویل به: {customerName}</span>
                        <span className="text-slate-400 font-num text-[11px]">({customerPhone})</span>
                      </div>
                      <div className="text-[11px] text-slate-300">
                        {customerProvince}، {customerCity}، {customerAddress} (کد پستی: <span className="font-num">{postalCode}</span>)
                      </div>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setCheckoutStep('address')}
                    className="self-end sm:self-center px-3 py-1 rounded-lg border border-slate-700 hover:border-slate-500 bg-slate-800 text-slate-300 hover:text-white text-[11px] font-medium flex items-center gap-1 transition-colors shrink-0"
                  >
                    <Edit3 className="w-3 h-3 text-amber-400" />
                    <span>ویرایش آدرس</span>
                  </button>
                </div>

                {/* 1. Shipping Methods */}
                <div className="space-y-1.5">
                  <label className="block text-slate-300 font-bold flex items-center gap-1.5">
                    <Truck className="w-3.5 h-3.5 text-slate-400" />
                    <span>شیوه ارسال از انبار مرکزی اهواز:</span>
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                    <button
                      type="button"
                      onClick={() => setShippingMethod('express_ahvaz')}
                      className={`p-3 rounded-2xl border text-start transition-all ${
                        shippingMethod === 'express_ahvaz'
                          ? `border-white/40 ${theme.bgCard} text-white font-bold ring-1 ring-white/30 shadow-xs`
                          : 'border-slate-800 bg-black/40 text-slate-400 hover:border-slate-700'
                      }`}
                    >
                      <div className="font-sans font-bold text-xs text-white">پیک فوری اهواز (تحویل امروز)</div>
                      <div className="text-[10px] text-slate-400 mt-1">ویژه شهرستان اهواز و حومه صنعتی</div>
                      <div className="text-[11px] text-emerald-400 font-num mt-1 font-bold">۷۵,۰۰۰ تومان</div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setShippingMethod('tipax')}
                      className={`p-3 rounded-2xl border text-start transition-all ${
                        shippingMethod === 'tipax'
                          ? `border-white/40 ${theme.bgCard} text-white font-bold ring-1 ring-white/30 shadow-xs`
                          : 'border-slate-800 bg-black/40 text-slate-400 hover:border-slate-700'
                      }`}
                    >
                      <div className="font-sans font-bold text-xs text-white">تیپاکس پیشتاز سراسری</div>
                      <div className="text-[10px] text-slate-400 mt-1">ارسال ۲۴ الی ۴۸ ساعته با بیمه بار</div>
                      <div className="text-[11px] text-emerald-400 font-num mt-1 font-bold">۱۸۰,۰۰۰ تومان</div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setShippingMethod('freight')}
                      className={`p-3 rounded-2xl border text-start transition-all ${
                        shippingMethod === 'freight'
                          ? `border-white/40 ${theme.bgCard} text-white font-bold ring-1 ring-white/30 shadow-xs`
                          : 'border-slate-800 bg-black/40 text-slate-400 hover:border-slate-700'
                      }`}
                    >
                      <div className="font-sans font-bold text-xs text-white">باربری تجهیزات سنگین و حساس</div>
                      <div className="text-[10px] text-slate-400 mt-1">ارسال پالتی ایمن به سراسر ایران</div>
                      <div className="text-[11px] text-emerald-400 font-num mt-1 font-bold">۲۵۰,۰۰۰ تومان</div>
                    </button>
                  </div>
                </div>

                {/* 2. Payment Gateways (Snapp! Pay, Torob Pay, Online Shetab) */}
                <div className="space-y-2 pt-1">
                  <label className="block text-slate-300 font-bold flex items-center gap-1.5">
                    <CreditCard className="w-3.5 h-3.5 text-slate-400" />
                    <span>انتخاب درگاه پرداخت الکترونیک:</span>
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                    {/* SnappPay Option */}
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('snapp_pay')}
                      className={`p-3 rounded-2xl border text-start transition-all relative ${
                        paymentMethod === 'snapp_pay'
                          ? 'border-sky-500 bg-sky-950/50 text-white font-bold ring-2 ring-sky-500/60 shadow-md'
                          : 'border-slate-800 bg-black/40 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1.5">
                        <div className="flex items-center gap-2">
                          <div className="bg-white rounded-lg px-1.5 py-0.5 border border-slate-200 shrink-0">
                            <img
                              src="/public/assets/aistudio/_____e54e8233.png"
                              alt="Snapp! Pay"
                              className="h-5 w-auto object-contain"
                              onError={(e) => {
                                (e.target as HTMLImageElement).src = '/public/snapp-pay-official.png';
                              }}
                            />
                          </div>
                          <span className="font-bold text-xs text-sky-300">اقساطی اسنپ‌پی</span>
                        </div>
                        <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-sky-500/20 text-sky-300 font-bold">۴ قسط</span>
                      </div>
                      <div className="text-[11px] text-slate-300 font-normal">
                        ۴ قسط مساوی ماهیانه بدون سود، ضامن و چک
                      </div>
                    </button>

                    {/* Online Saman Gateway (سامانه پرداخت اینترنتی) */}
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('online')}
                      className={`p-3 rounded-2xl border text-start transition-all ${
                        paymentMethod === 'online'
                          ? `border-white/40 ${theme.bgCard} text-white font-bold ring-2 ring-white/30 shadow-md`
                          : 'border-slate-800 bg-black/40 text-slate-400 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1.5">
                        <div className="flex items-center gap-2">
                          <div className="w-6 h-6 rounded-lg bg-slate-800 flex items-center justify-center text-rose-400">
                            <CreditCard className="w-3.5 h-3.5" />
                          </div>
                          <span className="font-bold text-xs text-white">درگاه آنلاین سامان</span>
                        </div>
                        <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-rose-500/20 text-rose-300 font-bold">سامانه شتاب</span>
                      </div>
                      <div className="text-[11px] text-slate-400 font-normal">
                        سامانه پرداخت اینترنتی کلیه کارت‌های بانکی شتاب
                      </div>
                    </button>

                    {/* In-Person Check Installment Option (خرید اقساطی با چک صیادی) */}
                    <button
                      type="button"
                      onClick={() => {
                        setPaymentMethod('installment_in_person');
                        setShowInstallmentTermsModal(true);
                      }}
                      className={`p-3 rounded-2xl border text-start transition-all relative ${
                        paymentMethod === 'installment_in_person'
                          ? 'border-amber-500 bg-amber-950/50 text-white font-bold ring-2 ring-amber-500/60 shadow-md'
                          : 'border-slate-800 bg-black/40 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1.5">
                        <div className="flex items-center gap-2">
                          <div className="w-6 h-6 rounded-lg bg-amber-500/20 flex items-center justify-center text-amber-400">
                            <FileText className="w-3.5 h-3.5" />
                          </div>
                          <span className="font-bold text-xs text-amber-300">اقساط با چک صیادی</span>
                        </div>
                        <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-amber-500/20 text-amber-200 font-bold">حضوری اهواز</span>
                      </div>
                      <div className="text-[11px] text-slate-300 font-normal">
                        خرید اعتباری با چک صیادی و مراجعه حضوری به دفتر اهواز
                      </div>
                    </button>
                  </div>

                  {/* Payment Details Callout based on selection */}
                  {paymentMethod === 'snapp_pay' && (
                    <div className="p-3.5 rounded-2xl bg-sky-950/40 border border-sky-600/50 space-y-2.5 mt-2">
                      <div className="flex items-center justify-between text-xs font-bold text-sky-300">
                        <span className="flex items-center gap-1.5">
                          <CheckCircle2 className="w-4 h-4 text-sky-400" />
                          <span>برنامه پرداخت اقساط ۴ ماهه اسنپ‌پی:</span>
                        </span>
                        <span className="text-[11px] text-emerald-400 font-num">کارمزد و سود: ۰ تومان</span>
                      </div>
                      <div className="grid grid-cols-4 gap-2 text-center font-num text-xs">
                        <div className="p-2 rounded-xl bg-black/60 border border-sky-600">
                          <span className="block text-[10px] text-sky-300 font-sans">قسط ۱ (امروز)</span>
                          <span className="font-bold text-white text-xs mt-0.5 block">{Math.round(cartFinalTotal / 4).toLocaleString('en-US')} ت</span>
                        </div>
                        <div className="p-2 rounded-xl bg-black/60 border border-slate-800">
                          <span className="block text-[10px] text-slate-400 font-sans">قسط ۲ (ماه بعد)</span>
                          <span className="font-bold text-slate-300 text-xs mt-0.5 block">{Math.round(cartFinalTotal / 4).toLocaleString('en-US')} ت</span>
                        </div>
                        <div className="p-2 rounded-xl bg-black/60 border border-slate-800">
                          <span className="block text-[10px] text-slate-400 font-sans">قسط ۳ (۲ ماه بعد)</span>
                          <span className="font-bold text-slate-300 text-xs mt-0.5 block">{Math.round(cartFinalTotal / 4).toLocaleString('en-US')} ت</span>
                        </div>
                        <div className="p-2 rounded-xl bg-black/60 border border-slate-800">
                          <span className="block text-[10px] text-slate-400 font-sans">قسط ۴ (۳ ماه بعد)</span>
                          <span className="font-bold text-slate-300 text-xs mt-0.5 block">{Math.round(cartFinalTotal / 4).toLocaleString('en-US')} ت</span>
                        </div>
                      </div>
                      <p className="text-[11px] text-slate-300 leading-relaxed">
                        با تأیید سفارش، وارد درگاه امن اسنپ‌پی می‌شوید و تنها ۲۵٪ کل مبلغ (قسط اول) را پرداخت می‌نمایید. مابقی اقساط به صورت ماهیانه و خودکار سررسید خواهند شد.
                      </p>
                    </div>
                  )}

                  {paymentMethod === 'installment_in_person' && (
                    <div className="p-3.5 rounded-2xl bg-amber-950/40 border border-amber-600/50 space-y-2.5 mt-2 text-xs">
                      <div className="flex items-center justify-between font-bold text-amber-300">
                        <span className="flex items-center gap-1.5">
                          <FileText className="w-4 h-4 text-amber-400" />
                          <span>شرایط خرید اقساطی با چک صیادی (هماهنگی و مراجعه حضوری):</span>
                        </span>
                        <span className="text-[11px] text-amber-400 font-bold">دفتر اهواز</span>
                      </div>
                      <p className="text-[11px] text-slate-300 leading-relaxed">
                        ویژه شرکت‌ها، کارگاه‌ها و فعالان صنعتی با ارائه چک صیادی بنفش ثبت‌شده در سامانه صیاد. پس از ثبت نهایی این مرحله، سفارش شما با وضعیت <strong className="text-amber-300 font-bold">«در انتظار هماهنگی حضوری»</strong> ثبت می‌گردد و کارشناس فروش اعتباری جهت هماهنگی جلسه در دفتر اهواز ظرف ۱ ساعت کاری با شما تماس خواهد گرفت.
                      </p>
                      <div className="pt-1 flex items-center justify-between">
                        <span className="text-[11px] text-slate-400 font-sans">آدرس دفتر جهت تحویل مدارک: اهواز، خ طالقانی، خ نظامی</span>
                        <button
                          type="button"
                          onClick={() => setShowInstallmentTermsModal(true)}
                          className="px-3 py-1 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 text-[11px] font-bold border border-amber-500/30 transition-colors"
                        >
                          مشاهده متن کامل شرایط و مدارک ضمانت
                        </button>
                      </div>
                    </div>
                  )}

                  {paymentMethod === 'online' && (
                    <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-700/80 space-y-2 mt-2 text-xs">
                      <div className="flex items-center justify-between font-bold text-slate-200">
                        <span className="flex items-center gap-1.5">
                          <ShieldCheck className="w-4 h-4 text-emerald-400" />
                          <span>درگاه پرداخت اینترنتی سامان (سامانه پرداخت شتاب):</span>
                        </span>
                        <span className="text-[11px] text-emerald-400">سامانه شتاب بانکی</span>
                      </div>
                      <p className="text-[11px] text-slate-300 leading-relaxed">
                        تسویه آنی آنلاین با استفاده از کلیه کارت‌های عضو شبکه شتاب بانکی به همراه صدور پیش‌فاکتور رسمی و کد پیگیری آنی.
                      </p>
                    </div>
                  )}
                </div>

                {/* Financial Summary Calculation Table */}
                <div className="p-3.5 rounded-2xl bg-black/60 border border-slate-800 space-y-2 font-num">
                  <div className="flex items-center justify-between text-slate-400 text-xs">
                    <span className="font-sans">مجموع قیمت اقلام ({cartTotalQty} عدد):</span>
                    <span>{cartSubtotal.toLocaleString('en-US')} تومان</span>
                  </div>
                  <div className="flex items-center justify-between text-slate-400 text-xs">
                    <span className="font-sans">هزینه بسته‌بندی و ارسال از انبار اهواز:</span>
                    <span className="text-emerald-400">{shippingCost === 0 ? 'رایگان' : `${shippingCost.toLocaleString('en-US')} تومان`}</span>
                  </div>
                  {needOfficialInvoice && (
                    <div className="flex items-center justify-between text-slate-400 text-xs">
                      <span className="font-sans">مالیات بر ارزش افزوده قانونی (۱۰٪):</span>
                      <span>{vatCost.toLocaleString('en-US')} تومان</span>
                    </div>
                  )}
                  <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
                    <span className="font-sans text-sm font-bold text-white">
                      {paymentMethod === 'snapp_pay' ? 'مبلغ قسط اول (پرداخت امروز):' : 
                       paymentMethod === 'installment_in_person' ? 'مبلغ کل سفارش (تسویه با چک صیادی):' : 'مبلغ نهایی قابل پرداخت:'}
                    </span>
                    <span className={`text-base font-bold ${paymentMethod === 'snapp_pay' ? 'text-sky-400' : paymentMethod === 'installment_in_person' ? 'text-amber-400' : theme.accentText}`}>
                      {paymentMethod === 'snapp_pay'
                        ? `${Math.round(cartFinalTotal / 4).toLocaleString('en-US')} تومان`
                        : `${cartFinalTotal.toLocaleString('en-US')} تومان`}
                    </span>
                  </div>
                </div>

                {/* Step 2 Actions */}
                <div className="flex items-center justify-between pt-2">
                  <button
                    type="button"
                    onClick={() => setCheckoutStep('address')}
                    className="px-4 py-2.5 rounded-xl border border-slate-700 text-slate-300 hover:text-white hover:bg-slate-800 font-medium flex items-center gap-1.5"
                  >
                    <ArrowRight className="w-4 h-4" />
                    <span>مرحله قبل (ویرایش آدرس)</span>
                  </button>
                  <button
                    type="button"
                    onClick={paymentMethod === 'installment_in_person' ? finishOrderProcessing : handleStartPaymentSimulation}
                    className={`px-6 py-2.5 ${
                      paymentMethod === 'snapp_pay'
                        ? 'bg-sky-600 hover:bg-sky-500'
                        : paymentMethod === 'installment_in_person'
                        ? 'bg-amber-600 hover:bg-amber-500'
                        : 'bg-rose-600 hover:bg-rose-500'
                    } text-white rounded-xl font-bold text-xs flex items-center gap-2 shadow-lg transition-all`}
                  >
                    <span>
                      {paymentMethod === 'snapp_pay'
                        ? `ورود به درگاه اسنپ‌پی و پرداخت قسط اول (${Math.round(cartFinalTotal / 4).toLocaleString('en-US')} تومان)`
                        : paymentMethod === 'installment_in_person'
                        ? 'ثبت درخواست خرید اقساطی (هماهنگی و تحویل چک)'
                        : 'ورود به درگاه پرداخت آنلاین سامان (سامانه شتاب)'}
                    </span>
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {/* =========================================================================
                STEP 3: SECURE PAYMENT GATEWAY SIMULATION (شبیه‌سازی واقعی اتصال به درگاه)
               ========================================================================= */}
            {checkoutStep === 'gateway' && (
              <div className="py-8 px-4 text-center space-y-6">
                <div className="relative inline-flex items-center justify-center">
                  <div className="w-20 h-20 rounded-full bg-slate-900 border-2 border-slate-700 flex items-center justify-center shadow-xl">
                    <ShieldCheck className="w-10 h-10 text-emerald-400 animate-pulse" />
                  </div>
                  <div className="absolute inset-0 rounded-full border-2 border-emerald-500/40 animate-ping" />
                </div>

                <div className="space-y-1.5">
                  <h4 className="text-base font-bold text-white">
                    در حال اتصال به درگاه پرداخت امن اینترنتی
                  </h4>
                  <p className="text-xs text-slate-400 max-w-md mx-auto">
                    {paymentMethod === 'snapp_pay'
                      ? 'ارتباط امن با سرور اسنپ‌پی جهت تأیید و تقسیط ۴ ماهه...'
                      : 'اتصال به سامانه پرداخت الکترونیک بانک سامان (سپ - عضو شتاب)...'}
                  </p>
                </div>

                {/* Gateway Identity Card */}
                <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 max-w-md mx-auto text-xs space-y-2 font-num text-start">
                  <div className="flex justify-between pb-2 border-b border-slate-800">
                    <span className="text-slate-400 font-sans">پذیرنده رسمی:</span>
                    <span className="font-bold text-white font-sans">پیشگام صنعت اهواز (سهامی خاص)</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400 font-sans">روش پرداخت:</span>
                    <span className="font-bold text-sky-400 font-sans">
                      {paymentMethod === 'snapp_pay' ? 'اقساط ۴ ماهه اسنپ‌پی' : 'درگاه اینترنتی سامان (سامانه پرداخت)'}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400 font-sans">مبلغ تراکنش:</span>
                    <span className="font-bold text-emerald-400">
                      {paymentMethod === 'snapp_pay'
                        ? `${Math.round(cartFinalTotal / 4).toLocaleString('en-US')} تومان (قسط اول)`
                        : `${cartFinalTotal.toLocaleString('en-US')} تومان`}
                    </span>
                  </div>
                  <div className="flex justify-between pt-1 border-t border-slate-800 text-[11px]">
                    <span className="text-slate-500 font-sans">پروتکل امنیتی:</span>
                    <span className="text-slate-400 flex items-center gap-1 font-sans">
                      <Lock className="w-3 h-3 text-emerald-400" />
                      <span>SSL 256-Bit Encrypted</span>
                    </span>
                  </div>
                </div>

                {/* Progress bar */}
                <div className="max-w-md mx-auto space-y-2">
                  <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-emerald-500 via-sky-500 to-rose-500 transition-all duration-300"
                      style={{ width: `${gatewayProgress}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-[11px] text-slate-500 font-num">
                    <span>احراز هویت بانکی</span>
                    <span>{gatewayProgress}٪</span>
                  </div>
                </div>

                <div className="pt-2">
                  <button
                    type="button"
                    onClick={finishOrderProcessing}
                    className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-medium border border-slate-700 transition-colors"
                  >
                    تأیید فوری پرداخت (تست شبیه‌ساز)
                  </button>
                </div>
              </div>
            )}

            {/* =========================================================================
                STEP 4: ORDER CONFIRMED & OFFICIAL INVOICE (فاکتور رسمی و کد رهگیری)
               ========================================================================= */}
            {checkoutStep === 'success' && (
              <div className="text-center py-4 space-y-5">
                <div className={`w-16 h-16 rounded-full ${paymentMethod === 'installment_in_person' ? 'bg-amber-950/60 border-2 border-amber-500 text-amber-400' : 'bg-emerald-950/60 border-2 border-emerald-500 text-emerald-400'} flex items-center justify-center mx-auto shadow-lg`}>
                  {paymentMethod === 'installment_in_person' ? <FileText className="w-9 h-9" /> : <CheckCircle2 className="w-10 h-10" />}
                </div>
                
                <div>
                  <h3 className={`text-lg font-bold ${paymentMethod === 'installment_in_person' ? 'text-amber-400' : 'text-emerald-400'}`}>
                    {paymentMethod === 'installment_in_person'
                      ? 'درخواست خرید اقساطی شما با موفقیت ثبت شد!'
                      : 'پرداخت تایید شد و سفارش شما با موفقیت ثبت گردید!'}
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    {paymentMethod === 'installment_in_person'
                      ? 'اقلام سفارش جهت هماهنگی و بررسی چک‌های صیادی برای شما در انبار مرکزی اهواز رزرو گردید.'
                      : 'اقلام سفارش هم‌اکنون در واحد تدارکات و کالیبراسیون انبار مرکزی اهواز در حال پردازش می‌باشند.'}
                  </p>
                </div>

                {/* Tracking Code Highlight Box */}
                <div className="p-4 rounded-2xl bg-black/60 border border-slate-800 max-w-lg mx-auto space-y-3 text-start">
                  <div className="flex items-center justify-between pb-2.5 border-b border-slate-800">
                    <span className="text-xs text-slate-400">کد رهگیری رسمی سفارش:</span>
                    <div className="flex items-center gap-2">
                      <span className="font-num font-black text-white text-base tracking-wider bg-slate-900 px-3 py-1 rounded-xl border border-slate-700">
                        {orderTrackingCode}
                      </span>
                      <button
                        type="button"
                        onClick={handleCopyTrackingCode}
                        className="p-1.5 rounded-lg border border-slate-700 hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
                        title="کپی کد رهگیری"
                      >
                        {trackingCopied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  <div className="space-y-1.5 text-xs font-num">
                    <div className="flex justify-between">
                      <span className="text-slate-400 font-sans">تحویل‌گیرنده:</span>
                      <span className="text-white font-sans font-bold">{customerName}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400 font-sans">شماره تماس پیامک:</span>
                      <span className="text-white">{customerPhone}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400 font-sans">نشانی مقصد:</span>
                      <span className="text-slate-300 font-sans text-start max-w-[280px] truncate">{customerProvince}، {customerCity}، {customerAddress}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400 font-sans">روش تسویه:</span>
                      <span className="text-white font-sans font-bold">
                        {paymentMethod === 'snapp_pay'
                          ? 'اقساطی ۴ ماهه اسنپ‌پی (قسط اول تسویه شد)'
                          : paymentMethod === 'installment_in_person'
                          ? 'خرید اقساطی با چک صیادی (در انتظار مراجعه حضوری)'
                          : 'درگاه آنلاین سامان (سامانه پرداخت شتاب)'}
                      </span>
                    </div>
                    <div className="flex justify-between pt-1 border-t border-slate-800">
                      <span className="text-slate-400 font-sans">
                        {paymentMethod === 'snapp_pay' ? 'مبلغ قسط اول پرداخت شده:' :
                         paymentMethod === 'installment_in_person' ? 'مبلغ کل سفارش (چک صیادی):' : 'مبلغ پرداخت شده:'}
                      </span>
                      <span className={`font-bold ${paymentMethod === 'installment_in_person' ? 'text-amber-400' : 'text-emerald-400'} text-sm`}>
                        {paymentMethod === 'snapp_pay'
                          ? `${Math.round(cartFinalTotal / 4).toLocaleString('en-US')} تومان (۳ قسط ماهیانه باقی‌مانده)`
                          : `${cartFinalTotal.toLocaleString('en-US')} تومان`}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Specific Action Guidance for In-Person Check Installment */}
                {paymentMethod === 'installment_in_person' ? (
                  <div className="p-3.5 rounded-2xl bg-amber-950/40 border border-amber-600/50 text-[11px] text-slate-300 max-w-lg mx-auto space-y-2 text-start">
                    <div className="flex items-center gap-2 text-amber-300 font-bold text-xs">
                      <FileText className="w-4 h-4 shrink-0 text-amber-400" />
                      <span>مراحل بعدی: هماهنگی تلفنی و تحویل اصل چک صیادی در دفتر اهواز</span>
                    </div>
                    <p className="text-slate-300 text-[10px] leading-relaxed">
                      کارشناس فروش اعتباری جهت تعیین وقت حضور در دفتر اهواز و تحویل مدارک ظرف حداکثر ۱ ساعت کاری با شماره <strong>{customerPhone}</strong> تماس خواهد گرفت. همچنین جهت تسریع در فرآیند می‌توانید تصویر چک صیادی را در واتس‌اپ ارسال فرمایید.
                    </p>
                    <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-amber-800/40">
                      <a
                        href={`https://api.whatsapp.com/send?phone=98${storeMobile.replace(/^0/, '')}&text=${encodeURIComponent(
                          `سلام، جهت خرید اقساطی با چک صیادی سفارش #${orderTrackingCode} پیام می‌دهم.\nخریدار: ${customerName}\nمبلغ: ${cartFinalTotal.toLocaleString('en-US')} تومان`
                        )}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-2.5 py-1 rounded-lg bg-emerald-700 hover:bg-emerald-600 text-white text-[10px] font-bold flex items-center gap-1 transition-colors"
                      >
                        <MessageSquare className="w-3 h-3" />
                        <span>ارسال پیام در واتس‌اپ تدارکات ({storeMobile})</span>
                      </a>
                      <a
                        href={`tel:${storePhone}`}
                        className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-700 text-slate-200 text-[10px] font-bold flex items-center gap-1 transition-colors"
                      >
                        <Phone className="w-3 h-3 text-amber-400" />
                        <span>تماس مستقیم: {storePhone}</span>
                      </a>
                    </div>
                  </div>
                ) : (
                  <div className="p-3.5 rounded-2xl bg-emerald-950/40 border border-emerald-600/50 text-[11px] text-slate-300 max-w-lg mx-auto space-y-2 text-start">
                    <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs">
                      <CheckCircle2 className="w-4 h-4 shrink-0" />
                      <span>پیامک پترن خدماتی (عبور ۱۰۰٪ از بلک‌لیست تبلیغاتی) به شماره {customerPhone} ارسال شد</span>
                    </div>
                    <p className="text-slate-300 text-[10px] leading-relaxed">
                      حتی در صورت مسدود بودن پیامک‌های تبلیغاتی خط شما، کد رهگیری با خط خدماتی ارسال شده است. همچنین اطلاعات سفارش در سامانه پیگیری سایت ثبت گردید و در هر زمان با شماره همراه خود می‌توانید از بخش <strong className="text-white font-medium">«پیگیری سفارش»</strong> بالای سایت، وضعیت بسته و بارکد پستی را استعلام کنید.
                    </p>
                    <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-emerald-800/40">
                      <a
                        href={`https://api.whatsapp.com/send?phone=98${customerPhone.replace(/^0/, '')}&text=${encodeURIComponent(
                          `کد رهگیری سفارش من در شرکت پیشگام صنعت اهواز: ${orderTrackingCode}\nتحویل‌گیرنده: ${customerName}\nمبلغ: ${cartFinalTotal.toLocaleString('en-US')} تومان`
                        )}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-2.5 py-1 rounded-lg bg-emerald-900/60 hover:bg-emerald-800 text-emerald-200 text-[10px] font-bold flex items-center gap-1 transition-colors"
                      >
                        <MessageSquare className="w-3 h-3 text-emerald-400" />
                        <span>ذخیره کد رهگیری در واتساپ من</span>
                      </a>
                      <button
                        type="button"
                        onClick={() => {
                          setShowOrderTrackingModal(true);
                          setTrackingSearchInput(customerPhone);
                          handleSearchOrderTracking(customerPhone);
                        }}
                        className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-700 hover:border-slate-500 text-slate-200 text-[10px] font-bold flex items-center gap-1 transition-colors"
                      >
                        <Truck className="w-3 h-3 text-sky-400" />
                        <span>مشاهده در سامانه پیگیری لحظه‌ای</span>
                      </button>
                    </div>
                  </div>
                )}

                {/* Action Buttons */}
                <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowPreInvoiceModal(true)}
                    className="px-5 py-2.5 rounded-xl border border-slate-700 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs flex items-center gap-2 transition-colors shadow-sm"
                  >
                    <FileText className="w-4 h-4 text-amber-400" />
                    <span>مشاهده و چاپ پیش‌فاکتور رسمی شرکتی</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setCartItems([]);
                      setOrderSuccess(false);
                      setCheckoutModalOpen(false);
                      setCartDrawerOpen(false);
                    }}
                    className={`px-6 py-2.5 ${theme.accentBtn} rounded-xl font-bold text-xs flex items-center gap-2 shadow-md`}
                  >
                    <ShoppingCart className="w-4 h-4" />
                    <span>ثبت سفارش جدید / بازگشت به فروشگاه</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* =========================================================================
          OFFICIAL PROFORMA INVOICE MODAL (پیش‌فاکتور رسمی شرکتی با مهر و امضا)
         ========================================================================= */}
      {showPreInvoiceModal && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 overflow-y-auto">
          <div className="bg-white text-slate-900 rounded-3xl w-full max-w-3xl p-6 sm:p-8 space-y-6 shadow-2xl my-auto max-h-[92vh] overflow-y-auto font-sans">
            
            {/* Invoice Top Action Bar */}
            <div className="flex items-center justify-between pb-4 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-rose-600" />
                <h3 className="font-bold text-base text-slate-900">
                  پیش‌فاکتور رسمی فروش تجهیزات و ادوات ابزاردقیق
                </h3>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold flex items-center gap-1.5 transition-colors shadow-xs"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>چاپ فاکتور (Print/PDF)</span>
                </button>
                <button
                  type="button"
                  onClick={() => setShowPreInvoiceModal(false)}
                  className="p-1.5 rounded-xl text-slate-500 hover:text-slate-900 hover:bg-slate-100 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Letterhead */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4 rounded-2xl bg-slate-50 border border-slate-200 text-xs">
              <div>
                <h2 className="text-lg font-black text-slate-900">
                  شرکت پیشگام صنعت اهواز (سهامی خاص)
                </h2>
                <p className="text-slate-600 text-[11px] mt-0.5">
                  تجهیزات تست، کالیبراسیون، ابزاردقیق و ادوات تخصصی صنایع نفت، گاز، پتروشیمی و فولاد
                </p>
                <div className="text-[10px] text-slate-500 mt-1 font-num flex items-center gap-3">
                  <span>شناسه ملی: ۱۰۸۶۰۵۲۹۳۴۱</span>
                  <span>شماره ثبت: ۴۱۸۹۵ اهواز</span>
                  <span>کد اقتصادی: ۴۱۱۵۸۹۳۲۶۴</span>
                </div>
              </div>
              <div className="text-left font-num space-y-1 shrink-0 text-xs">
                <div>
                  <span className="text-slate-500 font-sans">شماره فاکتور: </span>
                  <span className="font-bold text-slate-900">PI-{orderTrackingCode || '1403-8891'}</span>
                </div>
                <div>
                  <span className="text-slate-500 font-sans">تاریخ صدور: </span>
                  <span className="font-bold text-slate-900">۱۴۰۳/۰۸/۱۸</span>
                </div>
                <div>
                  <span className="text-slate-500 font-sans">کد پیگیری: </span>
                  <span className="font-bold text-rose-600">{orderTrackingCode || 'PG-749201'}</span>
                </div>
              </div>
            </div>

            {/* Buyer & Seller Details Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-num">
              {/* Seller */}
              <div className="p-3.5 rounded-2xl border border-slate-200 bg-slate-50/50 space-y-1.5">
                <span className="font-bold text-slate-900 font-sans block pb-1 border-b border-slate-200">
                  مشخصات فروشنده:
                </span>
                <div><span className="text-slate-500 font-sans">نام شخص حقوقی: </span><span className="font-bold text-slate-800 font-sans">شرکت پیشگام صنعت اهواز</span></div>
                <div><span className="text-slate-500 font-sans">نشانی دفتر مرکزی: </span><span className="text-slate-800 font-sans">اهواز، کوی نفت، خیابان بهارستان، مجتمع پیشگام</span></div>
                <div><span className="text-slate-500 font-sans">تلفن انبار و فروشگاه: </span><span className="text-slate-800">{storePhone}</span></div>
              </div>

              {/* Buyer */}
              <div className="p-3.5 rounded-2xl border border-slate-200 bg-slate-50/50 space-y-1.5">
                <span className="font-bold text-slate-900 font-sans block pb-1 border-b border-slate-200">
                  مشخصات خریدار / تحویل‌گیرنده:
                </span>
                <div><span className="text-slate-500 font-sans">نام شخص / ارگان: </span><span className="font-bold text-slate-800 font-sans">{needOfficialInvoice ? companyName : customerName}</span></div>
                {needOfficialInvoice && (
                  <div><span className="text-slate-500 font-sans">شناسه ملی خریدار: </span><span className="font-bold text-slate-800">{companyNationalId}</span></div>
                )}
                <div><span className="text-slate-500 font-sans">شماره تماس: </span><span className="text-slate-800">{customerPhone}</span></div>
                <div><span className="text-slate-500 font-sans">نشانی مقصد: </span><span className="text-slate-800 font-sans">{customerProvince}، {customerCity}، {customerAddress} (کد پستی: {postalCode})</span></div>
              </div>
            </div>

            {/* Items Table */}
            <div className="border border-slate-200 rounded-2xl overflow-hidden text-xs">
              <table className="w-full text-right">
                <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                  <tr>
                    <th className="p-2.5">ردیف</th>
                    <th className="p-2.5">شرح کالا و تجهیز ابزاردقیق</th>
                    <th className="p-2.5">مدل و برند</th>
                    <th className="p-2.5 text-center">تعداد</th>
                    <th className="p-2.5">قیمت واحد (تومان)</th>
                    <th className="p-2.5">مبلغ کل (تومان)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 font-num">
                  {cartItems.map((item, idx) => (
                    <tr key={idx} className="hover:bg-slate-50/50">
                      <td className="p-2.5 text-slate-500">{idx + 1}</td>
                      <td className="p-2.5 font-sans font-medium text-slate-900">
                        {item.product.name}
                        <div className="text-[10px] text-slate-500 font-sans">دارای برگه کالیبراسیون و گارانتی طلایی ۳۶ ماهه</div>
                      </td>
                      <td className="p-2.5 font-bold text-slate-700 font-sans">{item.product.model} ({item.product.brand})</td>
                      <td className="p-2.5 text-center font-bold text-slate-900">{item.quantity}</td>
                      <td className="p-2.5">{item.product.price.toLocaleString('en-US')}</td>
                      <td className="p-2.5 font-bold text-slate-900">{(item.product.price * item.quantity).toLocaleString('en-US')}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Total Calculation & Signature */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center pt-2">
              <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1.5 text-xs">
                <div className="font-bold text-slate-900">شرایط تحویل و ضمانت:</div>
                <div className="text-[11px] text-slate-600 leading-relaxed">
                  کلیه تجهیزات پیشگام صنعت دارای گواهی اصالت، تاییدیه اداره استاندارد و کالیبراسیون معتبر می‌باشند. در صورت هرگونه مغایرت فنی، وجه خریدار تا ۷ روز به صورت کامل مسترد خواهد شد.
                </div>
                <div className="pt-2 flex items-center gap-4 text-[10px] text-slate-500">
                  <div className="text-center">
                    <div className="w-16 h-12 rounded border border-dashed border-rose-300 bg-rose-50/50 flex items-center justify-center text-rose-600 font-bold text-[9px]">
                      مهر رسمی شرکت
                    </div>
                    <span className="mt-0.5 block">پیشگام صنعت اهواز</span>
                  </div>
                  <div className="text-center">
                    <div className="w-16 h-12 rounded border border-dashed border-slate-300 bg-slate-100 flex items-center justify-center text-slate-600 font-bold text-[9px]">
                      امضای مدیر مالی
                    </div>
                    <span className="mt-0.5 block">واحد فروش و حسابداری</span>
                  </div>
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-900 text-white space-y-2 font-num text-xs">
                <div className="flex justify-between text-slate-400">
                  <span className="font-sans">مجموع اقلام:</span>
                  <span>{cartSubtotal.toLocaleString('en-US')} تومان</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span className="font-sans">هزینه ارسال ({shippingMethod === 'express_ahvaz' ? 'پیک اهواز' : shippingMethod === 'tipax' ? 'تیپاکس' : 'باربری'}):</span>
                  <span>{shippingCost === 0 ? 'رایگان' : `${shippingCost.toLocaleString('en-US')} تومان`}</span>
                </div>
                {needOfficialInvoice && (
                  <div className="flex justify-between text-slate-400">
                    <span className="font-sans">مالیات بر ارزش افزوده (۱۰٪):</span>
                    <span>{vatCost.toLocaleString('en-US')} تومان</span>
                  </div>
                )}
                <div className="flex justify-between pt-2 border-t border-slate-700 text-sm font-bold">
                  <span className="font-sans">مبلغ کل پیش‌فاکتور:</span>
                  <span className="text-emerald-400">{cartFinalTotal.toLocaleString('en-US')} تومان</span>
                </div>
                <div className="text-[10px] text-slate-400 font-sans pt-1">
                  شیوه تسویه: {paymentMethod === 'snapp_pay' ? 'طرح اقساطی ۴ ماهه اسنپ‌پی' : paymentMethod === 'installment_in_person' ? 'خرید اقساطی با چک صیادی (هماهنگی حضوری)' : 'درگاه آنلاین سامان (سامانه پرداخت شتاب)'}
                </div>
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="flex justify-end gap-2 pt-2 border-t border-slate-200">
              <button
                type="button"
                onClick={() => setShowPreInvoiceModal(false)}
                className="px-5 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-bold transition-colors"
              >
                بستن پیش‌فاکتور
              </button>
              <button
                type="button"
                onClick={() => window.print()}
                className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold flex items-center gap-1.5 transition-colors shadow-sm"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>پرینت / ذخیره به صورت PDF</span>
              </button>
            </div>
          </div>
        </div>
      )}
      {/* =========================================================================
          ONLINE ORDER TRACKING MODAL (سامانه پیگیری آنلاین سفارشات با شماره موبایل)
         ========================================================================= */}
      {showOrderTrackingModal && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 overflow-y-auto">
          <div className={`${theme.bgSurface} border ${theme.borderPrimary} rounded-3xl w-full max-w-2xl p-5 sm:p-7 space-y-5 shadow-2xl my-auto max-h-[92vh] overflow-y-auto text-xs`}>
            
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-emerald-950 border border-emerald-600/50 flex items-center justify-center text-emerald-400 shrink-0">
                  <Truck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">
                    سامانه پیگیری آنلاین سفارشات و استعلام بارکد پستی
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    استعلام لحظه‌ای وضعیت مرسوله بدون نیاز به پیامک (پیشگام صنعت اهواز)
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowOrderTrackingModal(false)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Why SMS Fails Notice (راهنمای حل مشکل بلک‌لیست مخابرات) */}
            <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-1.5 text-[11px] text-slate-300">
              <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>پیامک کد رهگیری شما به خطتان ارسال نمی‌شود؟ نگران نباشید!</span>
              </div>
              <p className="leading-relaxed text-[11px] text-slate-300">
                در صورتی که پیامک‌های تبلیغاتی خط شما مسدود (بلک‌لیست) باشد یا گوشی شما در دسترس نبوده باشد، نیازی به تماس تلفنی نیست. کافیست <strong>شماره موبایل خریدار</strong> یا <strong>کد سفارش</strong> را در کادر زیر وارد کنید تا وضعیت بسته، بارکد پستی تیپاکس/پست و فاکتور در لحظه برایتان نمایش داده شود.
              </p>
            </div>

            {/* Search Input Box */}
            <div className="space-y-2">
              <label className="block text-slate-300 font-bold text-xs">
                شماره موبایل خریدار یا کد رهگیری سفارش:
              </label>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <input
                    type="text"
                    value={trackingSearchInput}
                    onChange={(e) => setTrackingSearchInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleSearchOrderTracking();
                      }
                    }}
                    placeholder="مثال: 09161117788 یا PG-834921"
                    className="w-full ps-9 pe-3 py-2.5 rounded-xl border border-slate-700 bg-slate-900 text-white font-num text-xs focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                  />
                  <Search className="w-4 h-4 text-slate-400 absolute start-3 top-3 pointer-events-none" />
                </div>
                <button
                  type="button"
                  onClick={() => handleSearchOrderTracking()}
                  className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 transition-colors shadow-sm shrink-0"
                >
                  <Search className="w-3.5 h-3.5" />
                  <span>استعلام سفارش</span>
                </button>
              </div>

              {/* Quick Test Demo Chips */}
              <div className="flex items-center gap-1.5 flex-wrap pt-1 text-[10px] text-slate-400">
                <span className="text-slate-500 font-medium">نمونه‌های آماده جهت تست:</span>
                <button
                  type="button"
                  onClick={() => {
                    setTrackingSearchInput('09163001234');
                    handleSearchOrderTracking('09163001234');
                  }}
                  className="px-2 py-0.5 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-num transition-colors"
                >
                  09163001234 (پتروشیمی ماهشهر)
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setTrackingSearchInput('09161117788');
                    handleSearchOrderTracking('09161117788');
                  }}
                  className="px-2 py-0.5 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-num transition-colors"
                >
                  09161117788 (توزیع برق اهواز)
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setTrackingSearchInput('PG-834921');
                    handleSearchOrderTracking('PG-834921');
                  }}
                  className="px-2 py-0.5 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-num transition-colors"
                >
                  PG-834921
                </button>
              </div>
            </div>

            {/* Results Section */}
            {hasSearchedTracking && (
              <div className="space-y-4 pt-2">
                {trackingSearchResult && trackingSearchResult.length > 0 ? (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between text-xs text-slate-400 font-num">
                      <span>تعداد {trackingSearchResult.length} سفارش با مشخصات شما یافت شد:</span>
                    </div>

                    {trackingSearchResult.map((order) => (
                      <div
                        key={order.id}
                        className="p-4 sm:p-5 rounded-2xl bg-black/60 border border-slate-700 space-y-4 font-sans"
                      >
                        {/* Order Header */}
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800 text-xs">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-white text-sm font-num">{order.trackingCode}</span>
                            <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                              order.status === 'delivered' ? 'bg-emerald-950 text-emerald-300 border border-emerald-600/50' :
                              order.status === 'shipped' ? 'bg-blue-950 text-blue-300 border border-blue-600/50' :
                              order.status === 'processing' ? 'bg-amber-950 text-amber-300 border border-amber-600/50' :
                              'bg-slate-800 text-slate-300'
                            }`}>
                              {order.status === 'delivered' ? 'تحویل داده شده به مشتری' :
                               order.status === 'shipped' ? 'تحویل به شرکت حمل (در مسیر مقصد)' :
                               order.status === 'processing' ? 'در حال آماده‌سازی و کالیبراسیون در انبار اهواز' :
                               'در انتظار تأیید اولیه انبار'}
                            </span>
                          </div>
                          <span className="text-[11px] text-slate-400 font-num">{order.createdAt}</span>
                        </div>

                        {/* Visual 4-Step Delivery Timeline */}
                        <div className="py-2">
                          <div className="grid grid-cols-4 gap-1 text-center text-[10px] font-medium">
                            <div className="space-y-1">
                              <div className="w-6 h-6 rounded-full bg-emerald-500 text-slate-950 font-bold flex items-center justify-center mx-auto">
                                <Check className="w-3.5 h-3.5" />
                              </div>
                              <span className="text-white block font-bold">ثبت و تسویه</span>
                            </div>
                            <div className="space-y-1">
                              <div className={`w-6 h-6 rounded-full font-bold flex items-center justify-center mx-auto ${
                                order.status !== 'pending' ? 'bg-emerald-500 text-slate-950' : 'bg-slate-800 text-slate-400'
                              }`}>
                                {order.status !== 'pending' ? <Check className="w-3.5 h-3.5" /> : '۲'}
                              </div>
                              <span className={order.status !== 'pending' ? 'text-white font-bold' : 'text-slate-500'}>کالیبراسیون فنی</span>
                            </div>
                            <div className="space-y-1">
                              <div className={`w-6 h-6 rounded-full font-bold flex items-center justify-center mx-auto ${
                                order.status === 'shipped' || order.status === 'delivered' ? 'bg-emerald-500 text-slate-950' : order.status === 'processing' ? 'bg-amber-500 text-slate-950 animate-pulse' : 'bg-slate-800 text-slate-400'
                              }`}>
                                {order.status === 'shipped' || order.status === 'delivered' ? <Check className="w-3.5 h-3.5" /> : '۳'}
                              </div>
                              <span className={order.status === 'shipped' || order.status === 'delivered' ? 'text-white font-bold' : order.status === 'processing' ? 'text-amber-300 font-bold' : 'text-slate-500'}>
                                بسته‌بندی و بارکد
                              </span>
                            </div>
                            <div className="space-y-1">
                              <div className={`w-6 h-6 rounded-full font-bold flex items-center justify-center mx-auto ${
                                order.status === 'delivered' ? 'bg-emerald-500 text-slate-950' : 'bg-slate-800 text-slate-400'
                              }`}>
                                {order.status === 'delivered' ? <Check className="w-3.5 h-3.5" /> : '۴'}
                              </div>
                              <span className={order.status === 'delivered' ? 'text-white font-bold' : 'text-slate-500'}>تحویل نهایی</span>
                            </div>
                          </div>
                        </div>

                        {/* Postal Barcode Highlight Box (حل قطعی مشکل نرسیدن بارکد پستی) */}
                        <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-700/80 space-y-2 text-xs">
                          <div className="flex items-center justify-between">
                            <span className="text-slate-300 font-bold flex items-center gap-1.5">
                              <Truck className="w-4 h-4 text-emerald-400" />
                              <span>بارکد رهگیری پستی / تیپاکس مرسوله:</span>
                            </span>
                            <span className="text-[10px] text-slate-400">
                              {order.shippingMethod === 'express_ahvaz' ? 'پیک اکسپرس اهواز' :
                               order.shippingMethod === 'tipax' ? 'تیپاکس سراسری' : 'باربری رسمی'}
                            </span>
                          </div>

                          {order.postalBarcode ? (
                            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 p-2.5 rounded-xl bg-black/60 border border-emerald-700/50">
                              <div className="font-num text-sm font-black text-emerald-400 tracking-wider">
                                {order.postalBarcode}
                              </div>
                              <a
                                href={
                                  order.postalBarcode.startsWith('TPX')
                                    ? `https://tipaxco.com/tracking?id=${order.postalBarcode}`
                                    : `https://tracking.post.ir/`
                                }
                                target="_blank"
                                rel="noopener noreferrer"
                                className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-colors shrink-0"
                              >
                                <span>استعلام لحظه‌ای در سامانه شرکت ملی پست ↗</span>
                                <ExternalLink className="w-3 h-3" />
                              </a>
                            </div>
                          ) : (
                            <div className="p-2.5 rounded-xl bg-black/40 border border-slate-800 text-[11px] text-slate-400">
                              بارکد پستی پس از تحویل اقلام به شرکت پست یا تیپاکس در همین بخش ثبت و فعال خواهد شد.
                            </div>
                          )}
                        </div>

                        {/* Recipient Details & Items */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-[11px] text-slate-300 font-num">
                          <div>
                            <span className="text-slate-400 font-sans">تحویل‌گیرنده: </span>
                            <span className="font-bold text-white font-sans">{order.customerName}</span>
                          </div>
                          <div>
                            <span className="text-slate-400 font-sans">شماره تماس: </span>
                            <span className="text-white">{order.customerPhone}</span>
                          </div>
                          <div className="sm:col-span-2">
                            <span className="text-slate-400 font-sans">نشانی مقصد: </span>
                            <span className="text-slate-200 font-sans">{order.address}</span>
                          </div>
                          <div>
                            <span className="text-slate-400 font-sans">روش پرداخت: </span>
                            <span className="font-bold text-sky-400 font-sans">
                              {order.paymentMethod === 'snapp_pay' ? 'اقساط ۴ ماهه اسنپ‌پی' :
                               order.paymentMethod === 'installment_in_person' ? 'خرید اقساطی چک صیادی (حضوری اهواز)' : 'درگاه آنلاین سامان (سامانه)'}
                            </span>
                          </div>
                          <div>
                            <span className="text-slate-400 font-sans">مبلغ کل سفارش: </span>
                            <span className="font-bold text-emerald-400">{order.totalAmount.toLocaleString('en-US')} تومان</span>
                          </div>
                        </div>

                        {/* Multi-channel Actions (WhatsApp & SMS Resend) */}
                        <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-800">
                          <button
                            type="button"
                            onClick={() => {
                              setResendSmsFeedback(`پیامک تایید سفارش و بارکد پستی با وب‌سرویس پترن خدماتی (بدون مسدودی) مجدداً به شماره ${order.customerPhone} ارسال شد.`);
                              setTimeout(() => setResendSmsFeedback(null), 4000);
                            }}
                            className="px-3 py-1.5 rounded-xl border border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-bold flex items-center gap-1.5 transition-colors"
                          >
                            <Send className="w-3 h-3 text-emerald-400" />
                            <span>ارسال مجدد پیامک خدماتی به خط من</span>
                          </button>

                          <a
                            href={`https://api.whatsapp.com/send?phone=98${order.customerPhone.replace(/^0/, '')}&text=${encodeURIComponent(
                              `پیگیری سفارش شرکت پیشگام صنعت اهواز:\nکد سفارش: ${order.trackingCode}\nخریدار: ${order.customerName}\nوضعیت: ${order.status}\nبارکد پستی: ${order.postalBarcode || 'در حال آماده‌سازی'}`
                            )}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="px-3 py-1.5 rounded-xl border border-emerald-700/60 bg-emerald-950/40 hover:bg-emerald-900/60 text-emerald-300 text-[11px] font-bold flex items-center gap-1.5 transition-colors"
                          >
                            <MessageSquare className="w-3 h-3 text-emerald-400" />
                            <span>دریافت وضعیت و فاکتور در واتساپ</span>
                          </a>
                        </div>

                        {resendSmsFeedback && (
                          <div className="p-2.5 rounded-xl bg-emerald-950/80 border border-emerald-600/70 text-emerald-300 text-[11px] flex items-center gap-2">
                            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                            <span>{resendSmsFeedback}</span>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="p-6 rounded-2xl bg-black/40 border border-slate-800 text-center space-y-2">
                    <AlertTriangle className="w-8 h-8 text-amber-400 mx-auto" />
                    <h4 className="text-sm font-bold text-white">سفارشی با این مشخصات یافت نشد</h4>
                    <p className="text-[11px] text-slate-400 max-w-md mx-auto leading-relaxed">
                      لطفاً شماره همراهی را که هنگام ثبت سفارش وارد کرده‌اید (مانند 09161112233) بدون فاصله بنویسید یا با واحد پیگیری انبار اهواز تماس حاصل فرمایید.
                    </p>
                    <div className="pt-2">
                      <span className="text-[11px] text-slate-300 font-num">تلفن پشتیبانی و پیگیری مرسولات اهواز: <strong>{storePhone}</strong></span>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* =========================================================================
          8. MODAL: TECHNICAL SPECS & DATASHEET
         ========================================================================= */}
      {activeModalProduct && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className={`${theme.bgSurface} border ${theme.borderPrimary} rounded-3xl w-full max-w-xl p-6 space-y-5 shadow-2xl`}>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <span className={`text-xs font-num font-bold ${theme.accentText}`}>{activeModalProduct.brand}</span>
                <h3 className="text-base font-bold text-white">
                  {activeModalProduct.name} ({activeModalProduct.model})
                </h3>
              </div>
              <button
                onClick={() => setActiveModalProduct(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs font-num">
              <div className="p-3 rounded-xl bg-black/50 border border-slate-800">
                <span className="text-slate-400 block mb-0.5 font-sans">رنج اندازه‌گیری:</span>
                <span className="font-bold text-white">{activeModalProduct.specs.voltageRange}</span>
              </div>
              <div className="p-3 rounded-xl bg-black/50 border border-slate-800">
                <span className="text-slate-400 block mb-0.5 font-sans">دقت فنی:</span>
                <span className="font-bold text-white">{activeModalProduct.specs.accuracy}</span>
              </div>
              <div className="p-3 rounded-xl bg-black/50 border border-slate-800">
                <span className="text-slate-400 block mb-0.5 font-sans">ایمنی صنعتی:</span>
                <span className="font-bold text-white">{activeModalProduct.specs.safetyRating}</span>
              </div>
              <div className="p-3 rounded-xl bg-black/50 border border-slate-800">
                <span className="text-slate-400 block mb-0.5 font-sans">ویژگی کلیدی:</span>
                <span className="font-bold font-sans text-white">{activeModalProduct.specs.feature}</span>
              </div>
            </div>

            <div className={`p-3 ${theme.accentBadgeBg} border ${theme.accentBadgeBorder} rounded-xl text-xs flex items-center justify-between`}>
              <div className="flex items-center gap-2">
                <Download className={`w-4 h-4 ${theme.accentText}`} />
                <span className="text-slate-200 font-semibold font-sans">
                  دانلود برگه اطلاعات فنی سازنده (DataSheet PDF)
                </span>
              </div>
              <button
                onClick={() => alert('کاتالوگ فنی سازنده دانلود شد.')}
                className={`px-3 py-1 ${theme.accentBtn} rounded-lg text-xs font-bold`}
              >
                دانلود
              </button>
            </div>

            {/* Payment Options in Specs Modal */}
            <div className="p-3.5 rounded-2xl bg-black/60 border border-slate-800 space-y-2 text-xs">
              <div className="flex items-center justify-between text-emerald-300 font-semibold font-num">
                <span className="flex items-center gap-1.5 font-sans">
                  <span className="px-1.5 py-0.2 rounded bg-emerald-500 text-slate-950 text-[10px] font-black">SnappPay</span>
                  <span>خرید اقساطی در ۴ قسط:</span>
                </span>
                <span className="font-bold text-white text-xs">
                  ۴ قسط {Math.round(activeModalProduct.price / 4).toLocaleString('en-US')} تومانی
                </span>
              </div>
              <div className="flex items-center justify-between text-[11px] text-amber-300 pt-1.5 border-t border-slate-800/80">
                <span className="flex items-center gap-1.5">
                  <FileText className="w-3.5 h-3.5 text-amber-400" />
                  <span>امکان خرید اقساطی با چک صیادی و ضمانت</span>
                </span>
                <span className="text-slate-400 font-sans">هماهنگی حضوری</span>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2">
              <div className="font-num text-base font-bold text-white">
                {activeModalProduct.price.toLocaleString('en-US')} تومان
              </div>
              <button
                onClick={() => {
                  handleAddToCart(activeModalProduct);
                  setActiveModalProduct(null);
                }}
                className={`px-5 py-2 text-xs font-bold ${theme.accentBtn} rounded-xl shadow-xs`}
              >
                افزودن به سبد خرید
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          9. MODAL: PARAMETRIC COMPARISON
         ========================================================================= */}
      {showCompareModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className={`${theme.bgSurface} border ${theme.borderPrimary} rounded-3xl w-full max-w-4xl p-6 space-y-6 shadow-2xl overflow-x-auto`}>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Scale className="w-5 h-5 text-amber-400" />
                <h3 className="text-base font-bold text-white">مقایسه فنی و مشخصات دستگاه‌ها</h3>
              </div>
              <button
                onClick={() => setShowCompareModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-3 gap-4 text-xs font-num">
              {compareList.map((prod) => (
                <div key={prod.id} className="p-4 rounded-2xl bg-black/40 border border-slate-800 space-y-3">
                  <div className="font-bold text-sm text-white font-sans">{prod.name}</div>
                  <div className={`${theme.accentText} text-xs font-bold`}>{prod.model} ({prod.brand})</div>
                  <div className="font-bold text-base text-white">{prod.price.toLocaleString('en-US')} تومان</div>
                  
                  <div className="space-y-2 pt-2 border-t border-slate-800 text-[11px]">
                    <div>
                      <span className="text-slate-400 block font-sans">رنج کاری:</span>
                      <span className="font-bold">{prod.specs.voltageRange}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block font-sans">دقت:</span>
                      <span className="font-bold">{prod.specs.accuracy}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block font-sans">ایمنی:</span>
                      <span className="font-bold">{prod.specs.safetyRating}</span>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      handleAddToCart(prod);
                      setShowCompareModal(false);
                    }}
                    className={`w-full py-2 ${theme.accentBtn} rounded-xl text-xs font-bold`}
                  >
                    افزودن به سبد خرید
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Discrete Corporate RFQ Modal */}
      {showRfqModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className={`${theme.bgSurface} border ${theme.borderPrimary} rounded-3xl w-full max-w-lg p-6 space-y-4 shadow-2xl text-xs`}>
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <FileText className={`w-4 h-4 ${theme.accentText}`} />
                <h3 className="font-bold text-sm text-white">درخواست پیش‌فاکتور رسمی برای شرکت‌ها و کارخانجات</h3>
              </div>
              <button
                onClick={() => setShowRfqModal(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-slate-300 leading-relaxed">
              اگر سازمان یا شرکت هستید، می‌توانید لیست قطعات خود را به همراه شناسه ملی جهت صدور پیش‌فاکتور رسمی با احتساب ارزش افزوده ارسال کنید.
            </p>

            <div className="space-y-3 font-medium">
              <div>
                <label className="block text-slate-400 mb-1">نام سازمان / شرکت:</label>
                <input
                  type="text"
                  placeholder="مثال: شرکت پتروشیمی اروند"
                  className="w-full p-2.5 rounded-xl border border-slate-800 bg-black/60 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">شماره تماس یا واتس‌اپ تدارکات:</label>
                <input
                  type="tel"
                  placeholder="0916..."
                  className="w-full p-2.5 rounded-xl border border-slate-800 bg-black/60 text-white font-num"
                />
              </div>
            </div>

            <button
              onClick={() => {
                alert('درخواست پیش‌فاکتور شما ثبت شد. کارشناس فروش ظرف ۳۰ دقیقه با شما تماس خواهد گرفت.');
                setShowRfqModal(false);
              }}
              className={`w-full py-2.5 ${theme.accentBtn} rounded-xl font-bold`}
            >
              ارسال درخواست استعلام رسمی
            </button>
          </div>
        </div>
      )}

      {/* =========================================================================
          EXIT-INTENT RETENTION POPUP (هشدار متناسب و جمع‌وجور هنگام خروج)
         ========================================================================= */}
      {showExitIntentModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
          <div className={`${theme.bgSurface} border border-rose-500/70 rounded-2xl w-full max-w-[420px] p-4 sm:p-5 space-y-3 shadow-[0_0_35px_rgba(225,29,72,0.25)] relative overflow-hidden animate-in zoom-in-95 duration-200`}>
            
            {/* Top Glowing Bar */}
            <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-rose-600 via-amber-500 to-emerald-500" />

            {/* Close Button */}
            <button
              onClick={handleDismissExitModal}
              className="absolute top-3 start-3 p-1 rounded-lg bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700 transition-colors"
              title="بستن"
            >
              <X className="w-4 h-4" />
            </button>

            {/* Header / Alert Icon */}
            <div className="text-center pt-1 space-y-1.5">
              <div className="w-10 h-10 rounded-xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center mx-auto text-rose-500 shadow-inner">
                {cartItems.length > 0 ? (
                  <ShoppingCart className="w-5 h-5 text-rose-500" />
                ) : (
                  <Gift className="w-5 h-5 animate-pulse text-amber-400" />
                )}
              </div>
              <div className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-rose-950/80 border border-rose-700/60 text-rose-300 text-[10px] font-bold">
                <AlertTriangle className="w-3 h-3 text-amber-400" />
                <span>یک لحظه صبر کنید! پیشنهاد ویژه پیشگام صنعت</span>
              </div>
              <h3 className="text-sm sm:text-base font-bold text-white">
                {cartItems.length > 0 
                  ? `سبد خرید شما منتظر شماست (${cartTotalQty} قلم)`
                  : 'دستگاه یا تجهیزات مدنظرتان را پیدا نکردید؟'}
              </h3>
            </div>

            {/* Conditional Content: Cart Waiting vs Empty Cart Discount */}
            {cartItems.length > 0 ? (
              <div className="space-y-2.5">
                <p className="text-[11px] text-slate-300 leading-relaxed text-center">
                  اقلام شما در انبار اهواز رزرو موقت شده‌اند. با توجه به تقاضای بالای صنایع خوزستان، موجودی تجهیزات تست محدود است!
                </p>

                {/* Mini Cart Preview */}
                <div className="p-2 rounded-xl bg-black/60 border border-slate-800 space-y-1.5 max-h-28 overflow-y-auto">
                  {cartItems.map((item) => (
                    <div key={item.product.id} className="flex items-center justify-between text-[11px] py-1 border-b border-slate-800/60 last:border-0">
                      <div className="flex items-center gap-2 min-w-0">
                        <img src={item.product.image} alt={item.product.name} className="w-7 h-7 rounded-md object-cover border border-slate-700 shrink-0" />
                        <div className="truncate">
                          <span className="text-white font-medium block truncate max-w-[170px]">{item.product.name}</span>
                          <span className="text-[9px] text-slate-400 font-num">{item.product.model} · {item.quantity} عدد</span>
                        </div>
                      </div>
                      <span className="font-num font-bold text-rose-400 shrink-0">
                        {(item.product.price * item.quantity).toLocaleString('en-US')} ت
                      </span>
                    </div>
                  ))}
                </div>

                {/* SnappPay Reminder */}
                <div className="p-2 rounded-xl bg-sky-950/40 border border-sky-600/40 flex items-center justify-between text-[11px]">
                  <div className="flex items-center gap-1.5">
                    <SnappPayLogo showTagline={false} className="px-1 py-0.5" />
                    <span className="text-sky-300 text-[10px] font-bold">پرداخت در ۴ قسط بدون سود و ضامن</span>
                  </div>
                  <span className="font-num text-sky-400 font-bold text-[11px]">
                    {Math.round(cartFinalTotal / 4).toLocaleString('en-US')} ت/ماه
                  </span>
                </div>
              </div>
            ) : (
              <div className="space-y-2.5">
                <p className="text-[11px] text-slate-300 leading-relaxed text-center">
                  برای اولین سفارش شما از انبار مرکزی اهواز، کد تخفیف ویژه در نظر گرفته‌ایم:
                </p>

                {/* Exclusive Voucher Code Box */}
                <div className="p-2.5 rounded-xl bg-gradient-to-r from-rose-950/60 via-black to-slate-900 border border-dashed border-rose-500/50 flex items-center justify-between gap-2">
                  <div>
                    <div className="text-[10px] text-rose-300 font-bold flex items-center gap-1">
                      <Tag className="w-3 h-3 text-amber-400" />
                      <span>کد ۵٪ سفارش اول:</span>
                    </div>
                    <div className="font-num text-sm sm:text-base font-black text-white tracking-wider mt-0.5">
                      {discountCode}
                    </div>
                  </div>
                  <button
                    onClick={handleCopyDiscount}
                    className={`px-2.5 py-1.5 rounded-lg text-[11px] font-bold flex items-center gap-1 transition-all shadow-xs ${
                      discountCopied
                        ? 'bg-emerald-600 text-white'
                        : 'bg-rose-600 hover:bg-rose-500 text-white'
                    }`}
                  >
                    {discountCopied ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>کپی شد</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>کپی کد</span>
                      </>
                    )}
                  </button>
                </div>

                {/* Value Propositions */}
                <div className="grid grid-cols-2 gap-1.5 text-[10px]">
                  <div className="p-1.5 rounded-lg bg-slate-900/90 border border-slate-800 flex items-center gap-1.5 text-slate-200">
                    <Truck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>ارسال ۲۴h اهواز</span>
                  </div>
                  <div className="p-1.5 rounded-lg bg-slate-900/90 border border-slate-800 flex items-center gap-1.5 text-slate-200">
                    <ShieldCheck className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                    <span>تضمین کالیبراسیون</span>
                  </div>
                </div>
              </div>
            )}

            {/* Action Buttons */}
            <div className="space-y-1.5 pt-2 border-t border-slate-800">
              {cartItems.length > 0 ? (
                <button
                  onClick={() => {
                    handleDismissExitModal();
                    setCheckoutModalOpen(true);
                  }}
                  className={`w-full py-2.5 ${theme.accentBtn} rounded-xl text-xs font-black shadow-md flex items-center justify-center gap-1.5`}
                >
                  <CreditCard className="w-3.5 h-3.5" />
                  <span>تکمیل سفارش و پرداخت (آنلاین یا اسنپ‌پی)</span>
                </button>
              ) : (
                <button
                  onClick={() => {
                    handleDismissExitModal();
                    const el = document.getElementById('catalog');
                    if (el) el.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className={`w-full py-2.5 ${theme.accentBtn} rounded-xl text-xs font-black shadow-md flex items-center justify-center gap-1.5`}
                >
                  <ShoppingCart className="w-3.5 h-3.5" />
                  <span>مشاهده کاتالوگ و استفاده از تخفیف</span>
                </button>
              )}

              <div className="flex items-center justify-between text-[10px] pt-0.5 px-0.5">
                <a
                  href="tel:06132230000"
                  className="text-slate-400 hover:text-white flex items-center gap-1"
                >
                  <Phone className="w-3 h-3 text-emerald-400" />
                  <span>مشاوره اهواز: 061-32230000</span>
                </a>
                <button
                  onClick={handleDismissExitModal}
                  className="text-slate-500 hover:text-slate-400 underline"
                >
                  صرف‌نظر و بستن
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          10. FOOTER WITH WAREHOUSE CREDENTIALS
         ========================================================================= */}
      <footer className="border-t border-slate-800/80 bg-black py-10 px-4 sm:px-8 text-xs text-slate-400 mt-16">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <div className="h-14 sm:h-16 px-3.5 py-1.5 bg-white rounded-2xl border-2 border-slate-700/80 flex items-center justify-center overflow-hidden shrink-0 shadow-md">
                <img
                  src="/pishgam-logo-hd.png"
                  alt="لوگوی رسمی پیشگام صنعت اهواز"
                  className="h-11 sm:h-13 w-auto max-w-[170px] sm:max-w-[200px] object-contain"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = '/public/assets/aistudio/_______596a28b5.jpg';
                  }}
                />
              </div>
              <div>
                <div className="text-sm font-bold text-white">پیشگام صنعت اهواز</div>
                <div className="text-[10px] text-slate-400">مرکز رسمی توزیع و کالیبراسیون تجهیزات تست</div>
              </div>
            </div>
            <p className="text-xs leading-relaxed text-slate-400">
              مرکز تخصصی تأمین و کالیبراسیون تجهیزات اندازه‌گیری دیجیتال، اتوماسیون صنعتی و ابزار دقیق با بیش از ۱۰ سال سابقه در اهواز و خوزستان.
            </p>
            {/* Payment Partners Visual Logos in Footer */}
            <div className="pt-2 space-y-2">
              <div className="text-[11px] font-bold text-slate-300 flex items-center gap-1.5">
                <CreditCard className="w-3.5 h-3.5 text-emerald-400" />
                <span>روش‌های پرداخت و تسویه اعتباری:</span>
              </div>
              <div className="flex flex-col sm:flex-row flex-wrap items-start gap-2.5">
                <SnappPayLogo showTagline={true} className="bg-sky-950/40 border-sky-500/40 hover:border-sky-400" />
                <button
                  type="button"
                  onClick={() => setShowInstallmentTermsModal(true)}
                  className="inline-flex items-center gap-2 rounded-2xl p-1.5 transition-all shadow-xs bg-slate-900/95 border border-amber-500/50 hover:border-amber-400 group text-start cursor-pointer"
                >
                  <div className="bg-amber-500/20 text-amber-400 rounded-xl px-2 py-1 flex items-center justify-center shrink-0 border border-amber-500/30 h-8 sm:h-9">
                    <FileText className="w-4 h-4 text-amber-400" />
                  </div>
                  <div className="text-right leading-tight pe-1">
                    <div className="text-[11px] font-black text-amber-300 flex items-center gap-1">
                      <span>خرید اقساطی با چک صیادی</span>
                      <span className="text-[9px] px-1 py-0.2 rounded bg-amber-500/20 text-amber-200 font-bold">حضوری</span>
                    </div>
                    <div className="text-[10px] text-slate-400 font-medium">ویژه شرکت‌ها و پیمانکاران اهواز</div>
                  </div>
                </button>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <div className="font-bold text-slate-200">دسته‌بندی‌های برتر</div>
            <ul className="space-y-1.5 text-slate-400">
              <li>مولتی‌مترهای دیجیتال صنعتی UNI-T</li>
              <li>کلمپ آمپرمترهای جریان مستک</li>
              <li>میگر و تسترهای عایق کیوریتسو ژاپن</li>
              <li>پرس‌های هیدرولیک کابلشو پیشگام</li>
            </ul>
          </div>

          <div className="space-y-3">
            <div className="font-bold text-slate-200">خدمات انبار و پیگیری سفارشات</div>
            {/* Prominent Order Tracking Box in Footer */}
            <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-emerald-500/50 hover:border-emerald-400 transition-colors shadow-md space-y-2">
              <div className="flex items-center gap-2">
                <Truck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span className="font-bold text-white text-xs">پیگیری سفارش با شماره همراه</span>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                مشاهده لحظه‌ای وضعیت مرسوله، بارکد پستی ۲۴ رقمی و رهگیری تیپاکس
              </p>
              <button
                type="button"
                onClick={() => {
                  setShowOrderTrackingModal(true);
                  setTrackingSearchInput('');
                  setTrackingSearchResult(null);
                  setHasSearchedTracking(false);
                }}
                className="w-full py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-colors shadow-xs"
              >
                <Truck className="w-3.5 h-3.5" />
                <span>ورود به سامانه رهگیری سفارشات</span>
              </button>
            </div>

            <ul className="space-y-1.5 text-slate-400 text-xs pt-1">
              <li>تضمین کالیبراسیون و اصالت قطعی تجهیزات</li>
              <li>ارسال اکسپرس در اهواز و تیپاکس سراسری</li>
              <li>امکان پرداخت اقساطی ۴ ماهه اسنپ‌پی و چک صیادی حضوری</li>
              <li>درگاه آنلاین بانک سامان (سامانه پرداخت اینترنتی)</li>
              <li>صدور فاکتور رسمی ارزش افزوده جهت شرکت‌ها</li>
            </ul>
          </div>

          <div className="space-y-2">
            <div className="font-bold text-slate-200">تماس با انبار مرکزی</div>
            <div className="text-slate-400 space-y-1">
              <div>{storeAddress}</div>
              <div className="font-num" dir="ltr">تلفن: {storePhone}</div>
              <div className="font-num" dir="ltr">همراه: {storeMobile}</div>
            </div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto pt-8 mt-8 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500">
          <div className="flex flex-wrap items-center gap-2 sm:gap-3">
            <span>© 1393 - 1405 پیشگام صنعت. تمامی حقوق محفوظ است.</span>
            <span>·</span>
            {isAdminAuthenticated ? (
              <button
                onClick={() => setShowAdminPanel(true)}
                className="text-amber-400 hover:text-amber-300 font-bold flex items-center gap-1 transition-colors"
              >
                <Settings className="w-3.5 h-3.5" />
                <span>پنل مدیریت انبار (فعال)</span>
              </button>
            ) : (
              <button
                onClick={() => {
                  setAdminPinInput('');
                  setAdminPinError('');
                  setShowAdminLoginModal(true);
                }}
                className="text-slate-600 hover:text-slate-400 flex items-center gap-1 transition-colors"
                title="تنظیمات"
              >
                <Settings className="w-3 h-3 text-slate-600" />
                <span>تنظیمات</span>
              </button>
            )}
          </div>
          <div className="flex flex-wrap items-center gap-3">
            {agenciesList.slice(0, 4).map((ag, i) => (
              <React.Fragment key={ag.id || i}>
                {i > 0 && <span>·</span>}
                <span className="hover:text-slate-300">
                  {ag.role.includes('نمایندگی') ? 'نمایندگی' : 'تأمین'} {ag.name}
                </span>
              </React.Fragment>
            ))}
          </div>
        </div>
      </footer>

      {/* =========================================================================
          ADMIN LOGIN / PIN VERIFICATION MODAL (تضمین حفاظت و عدم دسترسی مشتریان عادی)
         ========================================================================= */}
      {showAdminLoginModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-md p-6 sm:p-7 space-y-5 shadow-2xl text-slate-200 animate-in fade-in zoom-in-95 duration-150">
            {/* Header */}
            <div className="flex items-start justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
                  <Lock className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base text-white">ورود امن به مدیریت پیشگام صنعت</h3>
                  <p className="text-[11px] text-slate-400 mt-0.5">این بخش مختص مدیریت و انبارداران است</p>
                </div>
              </div>
              <button
                onClick={() => setShowAdminLoginModal(false)}
                className="text-slate-400 hover:text-white p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Explanation badge */}
            <div className="bg-slate-800/80 rounded-2xl p-3.5 border border-slate-700/80 text-xs text-slate-300 space-y-1.5 leading-relaxed">
              <div className="font-bold text-amber-400 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>حفظ حریم خصوصی و امنیت فروشگاه:</span>
              </div>
              <p className="text-[11px] text-slate-300">
                مشتریان عادی تنها به سبد خرید، قیمت‌ها و تجهیزات دسترسی دارند. تنظیمات تغییر نوار، کدهای تخفیف، سفارشات و انبار نیازمند رمز عبور است.
              </p>
            </div>

            {/* PIN Form */}
            <form onSubmit={handleAdminLoginSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  کد پین مدیر (PIN Code):
                </label>
                <div className="relative">
                  <input
                    type="password"
                    maxLength={10}
                    autoFocus
                    value={adminPinInput}
                    onChange={(e) => {
                      setAdminPinInput(e.target.value);
                      if (adminPinError) setAdminPinError('');
                    }}
                    placeholder="کد ۴ رقمی را وارد کنید (۱۲۳۴)"
                    className="w-full text-center tracking-widest text-lg font-num py-2.5 px-4 rounded-xl border border-slate-700 bg-slate-950 text-white focus:outline-none focus:ring-2 focus:ring-amber-500 font-bold placeholder:tracking-normal placeholder:text-xs placeholder:text-slate-500"
                  />
                  <Key className="w-4 h-4 text-slate-500 absolute start-3 top-3.5 pointer-events-none" />
                </div>
                {adminPinError && (
                  <p className="text-xs text-rose-400 font-medium mt-1.5 flex items-center gap-1">
                    <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                    <span>{adminPinError}</span>
                  </p>
                )}
              </div>

              {/* Quick shortcut helper for owner/client demo */}
              <div className="flex items-center justify-between text-[11px] px-1">
                <span className="text-slate-400">کد پین پیش‌فرض: <strong className="text-white font-num">1234</strong></span>
                <button
                  type="button"
                  onClick={() => {
                    setAdminPinInput('1234');
                    setIsAdminAuthenticated(true);
                    localStorage.setItem('pishgam_is_admin', 'true');
                    setShowAdminLoginModal(false);
                    setShowAdminPanel(true);
                  }}
                  className="text-amber-400 hover:text-amber-300 underline font-medium"
                >
                  ورود سریع با ۱۲۳۴ (تست مدیر)
                </button>
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAdminLoginModal(false)}
                  className="flex-1 py-2.5 rounded-xl border border-slate-700 text-slate-300 hover:bg-slate-800 text-xs font-medium transition-colors"
                >
                  انصراف (بازگشت به نمای مشتری)
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold transition-colors shadow-md flex items-center justify-center gap-1.5"
                >
                  <Unlock className="w-4 h-4" />
                  <span>ورود به پنل مدیریت</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* =========================================================================
          10. INSTALLMENT TERMS & CONDITIONS MODAL (شرایط خرید اقساطی با چک صیادی)
         ========================================================================= */}
      {showInstallmentTermsModal && (
        <div className="fixed inset-0 z-60 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#14141a] border border-amber-600/70 rounded-3xl w-full max-w-xl p-6 sm:p-7 space-y-5 shadow-2xl text-slate-200 animate-in fade-in zoom-in-95 duration-150 max-h-[90vh] overflow-y-auto">
            <div className="flex items-start justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base text-white">شرایط و مدارک خرید اقساطی با چک صیادی</h3>
                  <p className="text-[11px] text-amber-300/90 mt-0.5">فروش اعتباری ویژه سازمان‌ها، پیمانکاران و کارگاه‌های صنعتی</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowInstallmentTermsModal(false)}
                className="text-slate-400 hover:text-white p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Terms Body Text (Live configured from Admin Panel) */}
            <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 text-xs text-slate-200 leading-relaxed space-y-2 whitespace-pre-line font-sans">
              {installmentTermsText}
            </div>

            {/* Central Store Contact Callout */}
            <div className="p-3.5 rounded-2xl bg-amber-950/30 border border-amber-600/30 text-[11px] text-slate-300 space-y-2 font-num">
              <div className="font-bold text-amber-300 font-sans flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-amber-400" />
                <span>محل مراجعه حضوری و واحد اعتبارسنجی:</span>
              </div>
              <div className="text-slate-200 font-sans">{storeAddress}</div>
              <div className="flex flex-wrap gap-4 pt-1 border-t border-amber-800/40 text-slate-300">
                <div>تلفن دفتر: <span className="font-bold text-white" dir="ltr">{storePhone}</span></div>
                <div>همراه و واتس‌اپ: <span className="font-bold text-white" dir="ltr">{storeMobile}</span></div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center justify-between pt-2">
              <button
                type="button"
                onClick={() => setShowInstallmentTermsModal(false)}
                className="px-4 py-2.5 rounded-xl border border-slate-700 hover:bg-slate-800 text-slate-300 text-xs font-medium"
              >
                بستن پنجره
              </button>
              <button
                type="button"
                onClick={() => {
                  setPaymentMethod('installment_in_person');
                  setShowInstallmentTermsModal(false);
                }}
                className="px-5 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg"
              >
                <Check className="w-4 h-4" />
                <span>متوجه شدم، انتخاب خرید اقساطی</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          11. COMPREHENSIVE INTEGRATED ADMIN PANEL MODAL (پنل مدیریت جامع فروشگاه)
         ========================================================================= */}
      <AdminPanelModal
        isOpen={showAdminPanel}
        onClose={() => setShowAdminPanel(false)}
        products={productsList}
        onUpdateProduct={handleUpdateProduct}
        onAddProduct={handleAddProduct}
        onDeleteProduct={handleDeleteProduct}
        orders={ordersList}
        onUpdateOrderStatus={handleUpdateOrderStatus}
        onUpdateOrderDetails={handleUpdateOrderDetails}
        tickerText={tickerText}
        onUpdateTickerText={(text) => {
          setTickerText(text);
          localStorage.setItem('pishgam_ticker_text', text);
        }}
        agencies={agenciesList}
        onUpdateAgencies={(ag) => {
          setAgenciesList(ag);
          localStorage.setItem('pishgam_agencies', JSON.stringify(ag));
        }}
        discountCode={discountCode}
        onUpdateDiscountCode={handleUpdateDiscountCode}
        activeTheme={activeTheme}
        onSelectTheme={handleSelectTheme}
        storePhone={storePhone}
        onUpdateStorePhone={(ph) => {
          setStorePhone(ph);
          localStorage.setItem('pishgam_phone', ph);
        }}
        storeMobile={storeMobile}
        onUpdateStoreMobile={(mb) => {
          setStoreMobile(mb);
          localStorage.setItem('pishgam_mobile', mb);
        }}
        storeAddress={storeAddress}
        onUpdateStoreAddress={(ad) => {
          setStoreAddress(ad);
          localStorage.setItem('pishgam_address', ad);
        }}
        onPreviewExitIntent={() => {
          setShowAdminPanel(false);
          setShowExitIntentModal(true);
        }}
        installmentTermsText={installmentTermsText}
        onUpdateInstallmentTermsText={handleUpdateInstallmentTerms}
        bannerSlides={bannerSlides}
        onUpdateBannerSlides={handleUpdateBannerSlides}
        bannerInterval={bannerInterval}
        onUpdateBannerInterval={handleUpdateBannerInterval}
        specialOffers={specialOffers}
        onUpdateSpecialOffers={handleUpdateSpecialOffers}
        onResetSpecialOffersTimer={handleResetSpecialOffersTimer}
      />
    </div>
  );
};
