import React, { useState } from 'react';
import { ArrowLeft, ArrowRight, Sparkles, Building2, Globe, Target, AlertCircle, CheckCircle2, RefreshCw } from 'lucide-react';
import { RedesignProject, IndustryType, Language } from '../types/redesign';
import { SAMPLE_PROJECTS } from '../data/caseStudies';

interface ProjectIntakeProps {
  currentProject: RedesignProject;
  setCurrentProject: React.Dispatch<React.SetStateAction<RedesignProject>>;
  onAnalyzeSuccess: () => void;
  language: Language;
}

const COMMON_PAIN_POINTS_FA = [
  'طراحی بصری قدیمی و عدم هماهنگی با برند',
  'عدم واکنش‌گرایی و تجربه ضعیف در موبایل (Mobile UX)',
  'کندی بارگذاری صفحات و نارضایتی کاربران (Page Speed)',
  'ساختار گیج‌کننده منوها و معماری اطلاعات شلوغ',
  'فونت‌های ناخوانا و کنتراست رنگی ضعیف (Typography)',
  'نبود دکمه‌های اقدام فوری (CTA) مشخص و جذاب',
  'فرم‌های طولانی و پیچیده که مانع ارسال لید می‌شوند',
  'نبود مدارک اعتماد و نظرات معتبر مشتریان (Social Proof)',
];

const COMMON_PAIN_POINTS_EN = [
  'Dated visual styling and misaligned brand identity',
  'Poor mobile responsiveness and cramped touch targets',
  'Slow loading speeds and high bounce rate',
  'Cluttered navigation and confusing site hierarchy',
  'Illegible typography and low contrast ratios',
  'Missing or ineffective primary Call-to-Actions (CTAs)',
  'Overly complex forms causing high abandonment',
  'Lack of verifiable trust proof and testimonials',
];

const GOALS_FA = [
  'افزایش ۳ برابری سرنخ‌های فروش و تماس‌های تجاری',
  'ایجاد هویت بصری معتبر، مدرن و رده‌بالا (High-End)',
  'بهینه‌سازی ۱۰۰٪ برای کاربران موبایل و تبلت',
  'بهبود سرعت لود سایت به زیر ۱.۵ ثانیه',
  'ساده‌سازی مسیر خرید یا ثبت نوبت و کاهش مراحل',
  'ارتقای رتبه سئو و بهبود Core Web Vitals گوگل',
];

const GOALS_EN = [
  'Multiply inbound sales inquiries and lead conversion',
  'Establish a modern, authoritative brand presence',
  '100% seamless mobile-first user experience',
  'Sub-1.5s page load speed optimization',
  'Streamline checkout or booking workflows',
  'Strengthen technical SEO and Core Web Vitals',
];

const INDUSTRIES: { value: IndustryType; labelFa: string; labelEn: string }[] = [
  { value: 'medical_clinic', labelFa: 'کلینیک و خدمات پزشکی و درمانی', labelEn: 'Medical Clinic & Healthcare' },
  { value: 'ecommerce', labelFa: 'فروشگاه اینترنتی و خرده‌فروشی', labelEn: 'E-commerce & Retail' },
  { value: 'corporate_b2b', labelFa: 'شرکت صنعتی، مهندسی و بازرگانی (B2B)', labelEn: 'Industrial & Corporate B2B' },
  { value: 'education_tech', labelFa: 'آموزشگاه آنلاین و آکادمی تخصصی', labelEn: 'EdTech & Online Academy' },
  { value: 'creative_agency', labelFa: 'آژانس خلاق، استودیو معماری و دیزاین', labelEn: 'Creative Agency & Architecture' },
  { value: 'hospitality_restaurant', labelFa: 'رستوران، کافه و هتل', labelEn: 'Hospitality & Restaurant' },
  { value: 'real_estate', labelFa: 'املاک، ساختمانی و سرمایه‌گذاری', labelEn: 'Real Estate & Construction' },
  { value: 'personal_portfolio', labelFa: 'وب‌سایت شخصی و پورتفولیو متخصص', labelEn: 'Personal Portfolio & Consultant' },
];

export const ProjectIntake: React.FC<ProjectIntakeProps> = ({
  currentProject,
  setCurrentProject,
  onAnalyzeSuccess,
  language,
}) => {
  const isFa = language === 'fa';
  const [loading, setLoading] = useState(false);
  const [activePresetId, setActivePresetId] = useState<string>(currentProject.id);

  const painPointOptions = isFa ? COMMON_PAIN_POINTS_FA : COMMON_PAIN_POINTS_EN;
  const goalOptions = isFa ? GOALS_FA : GOALS_EN;

  const handleSelectPreset = (sample: RedesignProject) => {
    setActivePresetId(sample.id);
    setCurrentProject(sample);
  };

  const handleTogglePainPoint = (point: string) => {
    const exists = currentProject.currentPainPoints.includes(point);
    const updated = exists
      ? currentProject.currentPainPoints.filter((p) => p !== point)
      : [...currentProject.currentPainPoints, point];
    setCurrentProject({ ...currentProject, currentPainPoints: updated });
  };

  const handleToggleGoal = (goal: string) => {
    const exists = currentProject.primaryGoals.includes(goal);
    const updated = exists
      ? currentProject.primaryGoals.filter((g) => g !== goal)
      : [...currentProject.primaryGoals, goal];
    setCurrentProject({ ...currentProject, primaryGoals: updated });
  };

  const handleRunAnalysis = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/redesign/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          clientName: currentProject.clientName,
          websiteUrl: currentProject.websiteUrl,
          industry: currentProject.industryLabel,
          targetAudience: currentProject.targetAudience,
          primaryGoals: currentProject.primaryGoals,
          currentPainPoints: currentProject.currentPainPoints,
          notes: currentProject.notes,
          language,
        }),
      });

      const resData = await response.json();
      if (resData.success && resData.data) {
        setCurrentProject((prev) => ({
          ...prev,
          analysis: resData.data,
        }));
        onAnalyzeSuccess();
      }
    } catch (err) {
      console.error('Failed to run analysis:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 sm:px-6 lg:px-8 space-y-8">
      {/* Intro Hero & Practical Guidance */}
      <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl p-6 sm:p-8 shadow-xs">
        <div className="max-w-3xl space-y-3">
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-neutral-500 dark:text-neutral-400">
            <span>{isFa ? 'راهنمای عملی طراحان و فریلنسرها' : 'Designer & Developer Redesign Suite'}</span>
            <span>·</span>
            <span>{isFa ? 'متدولوژی استاندارد بازطراحی' : 'Standard Redesign Workflow'}</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-900 dark:text-white" style={{ textWrap: 'balance' }}>
            {isFa
              ? 'چطور سایت یک کارفرما را به‌صورت اصولی و سودآور بازطراحی کنیم؟'
              : 'How to Systematically Redesign a Client Website for Maximum Impact'}
          </h1>
          <p className="text-sm sm:text-base text-neutral-600 dark:text-neutral-300 leading-relaxed">
            {isFa
              ? 'برای بازطراحی موفق یک وب‌سایت، نباید صرفاً ظاهر آن را تغییر داد! ابتدا نقاط ضعف و افت لید سایت فعلی را عارضه‌یابی کنید، ارزش تجاری بازطراحی را برای کارفرما اثبات کنید، سپس با سیستم طراحی مدرن، پیش‌نمایش زنده و پروپوزال رسمی ارائه دهید.'
              : 'Redesigning a website succeeds when anchored in business outcomes, not just aesthetics. Diagnose the friction in the legacy site, substantiate the ROI of redesigning, preview the modern solution, and deliver a client-ready proposal.'}
          </p>
        </div>

        {/* Quick Presets Picker */}
        <div className="mt-6 pt-6 border-t border-neutral-100 dark:border-neutral-800">
          <div className="text-xs font-medium text-neutral-500 dark:text-neutral-400 mb-3">
            {isFa ? 'نمونه‌های آماده برای بررسی سریع یا شروع از صفر:' : 'Choose a ready case study or start blank:'}
          </div>
          <div className="flex flex-wrap gap-2">
            {SAMPLE_PROJECTS.map((sample) => (
              <button
                key={sample.id}
                onClick={() => handleSelectPreset(sample)}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-all ${
                  activePresetId === sample.id
                    ? 'bg-neutral-900 text-white border-neutral-900 dark:bg-white dark:text-neutral-900 dark:border-white shadow-xs'
                    : 'bg-white dark:bg-neutral-900 text-neutral-700 dark:text-neutral-300 border-neutral-200 dark:border-neutral-800 hover:border-neutral-400'
                }`}
              >
                {sample.clientName}
              </button>
            ))}
            <button
              onClick={() => {
                setActivePresetId('custom');
                setCurrentProject({
                  id: `project-${Date.now()}`,
                  clientName: '',
                  websiteUrl: '',
                  industry: 'corporate_b2b',
                  industryLabel: isFa ? 'خدمات شرکتی و B2B' : 'Corporate B2B',
                  targetAudience: '',
                  primaryGoals: [],
                  currentPainPoints: [],
                  notes: '',
                  budgetEstimate: isFa ? '۳۵,۰۰۰,۰۰۰ تومان' : '$2,500',
                  currency: isFa ? 'تومان' : 'USD',
                  createdAt: new Date().toISOString().split('T')[0],
                });
              }}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg border border-dashed transition-all ${
                activePresetId === 'custom'
                  ? 'bg-neutral-900 text-white border-neutral-900 dark:bg-white dark:text-neutral-900'
                  : 'text-neutral-600 dark:text-neutral-400 border-neutral-300 dark:border-neutral-700 hover:border-neutral-500'
              }`}
            >
              + {isFa ? 'ورود اطلاعات کارفرمای جدید' : 'New Custom Client'}
            </button>
          </div>
        </div>
      </div>

      {/* Main Intake Form */}
      <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl p-6 sm:p-8 space-y-8 shadow-xs">
        {/* Section 1: Client Info */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 text-sm font-semibold text-neutral-900 dark:text-white">
            <Building2 className="w-4 h-4 text-neutral-500" />
            <span>{isFa ? '۱. مشخصات کسب‌وکار و آدرس سایت فعلی' : '1. Business Profile & Legacy Website'}</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-neutral-700 dark:text-neutral-300 mb-1.5">
                {isFa ? 'نام کارفرما / برند تجاری' : 'Client / Brand Name'} *
              </label>
              <input
                type="text"
                value={currentProject.clientName}
                onChange={(e) => setCurrentProject({ ...currentProject, clientName: e.target.value })}
                placeholder={isFa ? 'مثال: کلینیک دندانپزشکی دکتر آریا' : 'e.g. Dr. Arya Dental Clinic'}
                className="w-full px-3.5 py-2 text-sm rounded-lg border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800/50 text-neutral-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-neutral-400 dark:focus:ring-neutral-600 transition-colors"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-700 dark:text-neutral-300 mb-1.5">
                {isFa ? 'آدرس وب‌سایت فعلی (یا دامنه)' : 'Current Website URL'}
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={currentProject.websiteUrl}
                  onChange={(e) => setCurrentProject({ ...currentProject, websiteUrl: e.target.value })}
                  placeholder={isFa ? 'www.dr-aryaclinic.ir' : 'www.client-website.com'}
                  dir="ltr"
                  className="w-full px-3.5 py-2 text-sm rounded-lg border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800/50 text-neutral-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-neutral-400 dark:focus:ring-neutral-600 transition-colors"
                />
                <Globe className="w-4 h-4 text-neutral-400 absolute end-3 top-2.5 pointer-events-none" />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-700 dark:text-neutral-300 mb-1.5">
                {isFa ? 'حوزه فعالیت و صنعت' : 'Industry & Domain'}
              </label>
              <select
                value={currentProject.industry}
                onChange={(e) => {
                  const val = e.target.value as IndustryType;
                  const item = INDUSTRIES.find((i) => i.value === val);
                  setCurrentProject({
                    ...currentProject,
                    industry: val,
                    industryLabel: isFa ? item?.labelFa || '' : item?.labelEn || '',
                  });
                }}
                className="w-full px-3.5 py-2 text-sm rounded-lg border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800/50 text-neutral-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-neutral-400 dark:focus:ring-neutral-600 transition-colors"
              >
                {INDUSTRIES.map((ind) => (
                  <option key={ind.value} value={ind.value}>
                    {isFa ? ind.labelFa : ind.labelEn}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-700 dark:text-neutral-300 mb-1.5">
                {isFa ? 'مخاطبان هدف و مشتریان بالقوه' : 'Target Audience'}
              </label>
              <input
                type="text"
                value={currentProject.targetAudience}
                onChange={(e) => setCurrentProject({ ...currentProject, targetAudience: e.target.value })}
                placeholder={isFa ? 'مثال: مراجعین درمان‌های زیبایی و ایمپلنت' : 'e.g. High-net-worth cosmetic patients'}
                className="w-full px-3.5 py-2 text-sm rounded-lg border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800/50 text-neutral-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-neutral-400 dark:focus:ring-neutral-600 transition-colors"
              />
            </div>
          </div>
        </div>

        {/* Section 2: Pain Points Diagnosis */}
        <div className="space-y-3 pt-4 border-t border-neutral-100 dark:border-neutral-800">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm font-semibold text-neutral-900 dark:text-white">
              <AlertCircle className="w-4 h-4 text-amber-500" />
              <span>{isFa ? '۲. عارضه‌ها و مشکلات سایت فعلی (Pain Points)' : '2. Legacy Website Pain Points'}</span>
            </div>
            <span className="text-xs text-neutral-500">
              {currentProject.currentPainPoints.length} {isFa ? 'مورد انتخاب شده' : 'selected'}
            </span>
          </div>
          <p className="text-xs text-neutral-500 dark:text-neutral-400">
            {isFa
              ? 'مواردی که در سایت فعلی باعث پرش مخاطبان، تجربه کاربری منفی یا نارضایتی کارفرما می‌شود را علامت بزنید:'
              : 'Check the specific flaws degrading user experience and conversion on the current site:'}
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2">
            {painPointOptions.map((point) => {
              const selected = currentProject.currentPainPoints.includes(point);
              return (
                <button
                  type="button"
                  key={point}
                  onClick={() => handleTogglePainPoint(point)}
                  className={`flex items-start gap-2.5 p-3 rounded-lg border text-start text-xs transition-colors ${
                    selected
                      ? 'bg-amber-50/70 dark:bg-amber-950/20 border-amber-300 dark:border-amber-800/60 text-amber-950 dark:text-amber-200 font-medium'
                      : 'bg-neutral-50/60 dark:bg-neutral-800/40 border-neutral-200 dark:border-neutral-800 text-neutral-700 dark:text-neutral-300 hover:border-neutral-300'
                  }`}
                >
                  <span
                    className={`mt-0.5 w-4 h-4 shrink-0 rounded flex items-center justify-center border ${
                      selected
                        ? 'bg-amber-500 border-amber-600 text-white'
                        : 'border-neutral-300 dark:border-neutral-600 bg-white dark:bg-neutral-700'
                    }`}
                  >
                    {selected && <CheckCircle2 className="w-3.5 h-3.5" />}
                  </span>
                  <span>{point}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Section 3: Strategic Goals */}
        <div className="space-y-3 pt-4 border-t border-neutral-100 dark:border-neutral-800">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm font-semibold text-neutral-900 dark:text-white">
              <Target className="w-4 h-4 text-emerald-500" />
              <span>{isFa ? '۳. اهداف تجاری بازطراحی (Key Redesign Outcomes)' : '3. Key Redesign Outcomes'}</span>
            </div>
            <span className="text-xs text-neutral-500">
              {currentProject.primaryGoals.length} {isFa ? 'هدف مشخص شده' : 'selected'}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2">
            {goalOptions.map((goal) => {
              const selected = currentProject.primaryGoals.includes(goal);
              return (
                <button
                  type="button"
                  key={goal}
                  onClick={() => handleToggleGoal(goal)}
                  className={`flex items-start gap-2.5 p-3 rounded-lg border text-start text-xs transition-colors ${
                    selected
                      ? 'bg-emerald-50/70 dark:bg-emerald-950/20 border-emerald-300 dark:border-emerald-800/60 text-emerald-950 dark:text-emerald-200 font-medium'
                      : 'bg-neutral-50/60 dark:bg-neutral-800/40 border-neutral-200 dark:border-neutral-800 text-neutral-700 dark:text-neutral-300 hover:border-neutral-300'
                  }`}
                >
                  <span
                    className={`mt-0.5 w-4 h-4 shrink-0 rounded flex items-center justify-center border ${
                      selected
                        ? 'bg-emerald-600 border-emerald-700 text-white'
                        : 'border-neutral-300 dark:border-neutral-600 bg-white dark:bg-neutral-700'
                    }`}
                  >
                    {selected && <CheckCircle2 className="w-3.5 h-3.5" />}
                  </span>
                  <span>{goal}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Action Trigger */}
        <div className="pt-6 border-t border-neutral-200 dark:border-neutral-800 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-xs text-neutral-500">
            {isFa
              ? 'موتور تحلیل هوشمند با بررسی ورودی‌ها، راهکار بهینه رابط و تجربه کاربری را استخراج می‌کند.'
              : 'Our design engine synthesizes inputs into a coherent architecture and proposal.'}
          </div>

          <button
            onClick={handleRunAnalysis}
            disabled={loading || !currentProject.clientName}
            className={`flex items-center gap-2 px-6 py-2.5 text-sm font-semibold rounded-lg transition-all ${
              loading || !currentProject.clientName
                ? 'bg-neutral-200 dark:bg-neutral-800 text-neutral-400 cursor-not-allowed'
                : 'bg-neutral-900 hover:bg-neutral-800 text-white dark:bg-white dark:text-neutral-900 dark:hover:bg-neutral-100 shadow-sm'
            }`}
          >
            {loading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>{isFa ? 'در حال تحلیل و تدوین نقشه راه...' : 'Analyzing & Synthesizing...'}</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>{isFa ? 'تحلیل عارضه‌ها و تدوین استراتژی بازطراحی' : 'Generate Redesign Strategy'}</span>
                {isFa ? <ArrowLeft className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
