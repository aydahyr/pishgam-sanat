import React, { useState, useRef, useCallback } from 'react';
import { Columns, SplitSquareVertical, Info, Sparkles, CheckCircle, AlertTriangle } from 'lucide-react';
import { RedesignProject, Language } from '../types/redesign';

interface BeforeAfterSliderProps {
  project: RedesignProject;
  language: Language;
}

export const BeforeAfterSlider: React.FC<BeforeAfterSliderProps> = ({ project, language }) => {
  const isFa = language === 'fa';
  const [sliderPosition, setSliderPosition] = useState<number>(50); // percentage 0 - 100
  const [viewMode, setViewMode] = useState<'slider' | 'sideBySide'>('slider');
  const [activeHotspot, setActiveHotspot] = useState<number | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const isDragging = useRef(false);

  const clientName = project.clientName || (isFa ? 'کسب‌وکار شما' : 'Client Website');

  const handlePointerDown = () => {
    isDragging.current = true;
  };

  const handlePointerUp = () => {
    isDragging.current = false;
  };

  const handlePointerMove = useCallback((e: React.PointerEvent<HTMLDivElement>) => {
    if (!isDragging.current || !containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const width = rect.width;
    let percentage = (x / width) * 100;
    if (percentage < 5) percentage = 5;
    if (percentage > 95) percentage = 95;
    setSliderPosition(percentage);
  }, []);

  const hotspots = [
    {
      id: 1,
      x: isFa ? 85 : 15,
      y: 8,
      titleFa: 'ناوبری ۳ قسمتی بدون ازدحام (3-Zone Top Bar)',
      titleEn: '3-Zone Streamlined Top Bar',
      descFa: 'حذف ۱۲ لینک ریز آبی و پراکنده؛ جایگزینی با لوگوی یکتا، ۴ لینک ضروری و یک دکمه اقدام هدفمند.',
      descEn: 'Replaced 12 cluttered links with a single wordmark, 4 essential links, and one high-intent action button.',
    },
    {
      id: 2,
      x: isFa ? 75 : 25,
      y: 28,
      titleFa: 'تیتر ارزش‌محور (Value-Driven Hook)',
      titleEn: 'Value-Driven Hook',
      descFa: 'حذف عبارت کلیشه‌ای و خسته‌کننده "به سایت ما خوش آمدید" و جایگزینی با نتیجه ملموس برای کاربر در ۳ ثانیه اول.',
      descEn: 'Removed dated "Welcome to our website" greeting in favor of an unmistakable, concrete value proposition.',
    },
    {
      id: 3,
      x: isFa ? 75 : 25,
      y: 44,
      titleFa: 'دکمه اقدام فوری متمرکز (Frictionless CTA)',
      titleEn: 'Frictionless Action CTA',
      descFa: 'یک دکمه مشخص با برچسب شفاف و مسیر مستقیم تبدیل، به جای دکمه‌های متفرقه چشمک‌زن و فرم‌های طولانی.',
      descEn: 'One prominent, high-intent action button instead of generic flash banners or multi-step barriers.',
    },
    {
      id: 4,
      x: isFa ? 25 : 75,
      y: 35,
      titleFa: 'تصویرسازی معتبر با کیفیت تجاری (Commercial Visual Asset)',
      titleEn: 'Commercial Visual Asset',
      descFa: 'حذف تصاویر کش‌آمده بی‌کیفیت و استوک‌های تکراری؛ استفاده از قاب دیجیتال اختصاصی و استانداردهای لوکس.',
      descEn: 'Eliminated distorted low-res stock clips in favor of authentic, high-fidelity visual presence.',
    },
    {
      id: 5,
      x: 50,
      y: 82,
      titleFa: 'اثبات اجتماعی ملموس (Social Proof & KPIs)',
      titleEn: 'Attributable Social Proof',
      descFa: 'نمایش آمار راستی‌آزمایی شده و رضایت واقعی مشتریان در مجاورت نقطه تبدیل برای کاهش هرگونه ریسک ذهنی.',
      descEn: 'Clear quantified metrics and verified customer outcomes placed directly adjacent to conversion actions.',
    },
  ];

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 sm:px-6 lg:px-8 space-y-6">
      {/* Title & Mode Switcher */}
      <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-xs">
        <div>
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-neutral-500 mb-1">
            <span>{isFa ? 'مقایسه تجسمی زنده' : 'Interactive Visual Comparison'}</span>
            <span>·</span>
            <span>{clientName}</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-neutral-900 dark:text-white">
            {isFa ? 'مقایسه سایت قدیمی در برابر کانسپت بازطراحی‌شده' : 'Legacy Site vs. Modern Redesign'}
          </h1>
        </div>

        {/* View Mode Segmented Control */}
        <div className="flex items-center p-1 bg-neutral-100 dark:bg-neutral-800 rounded-lg shrink-0">
          <button
            onClick={() => setViewMode('slider')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              viewMode === 'slider'
                ? 'bg-white dark:bg-neutral-900 text-neutral-900 dark:text-white shadow-xs font-semibold'
                : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
            }`}
          >
            <SplitSquareVertical className="w-3.5 h-3.5" />
            <span>{isFa ? 'اسلایدر کشویی' : 'Interactive Slider'}</span>
          </button>
          <button
            onClick={() => setViewMode('sideBySide')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              viewMode === 'sideBySide'
                ? 'bg-white dark:bg-neutral-900 text-neutral-900 dark:text-white shadow-xs font-semibold'
                : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
            }`}
          >
            <Columns className="w-3.5 h-3.5" />
            <span>{isFa ? 'نمای کنار هم' : 'Side-by-Side'}</span>
          </button>
        </div>
      </div>

      {/* Instructions bar */}
      <div className="flex items-center justify-between text-xs text-neutral-500 dark:text-neutral-400 px-2">
        <div className="flex items-center gap-2">
          <Info className="w-4 h-4 text-neutral-400" />
          <span>
            {isFa
              ? 'دستگیره خط وسط را به چپ و راست بکشید تا تحول طراحی و نقاط ارتقا را مشاهده کنید.'
              : 'Drag the split handle horizontally to reveal the before and after transformation.'}
          </span>
        </div>
        <div className="hidden sm:flex items-center gap-4">
          <span className="flex items-center gap-1 text-rose-600 dark:text-rose-400 font-medium">
            <AlertTriangle className="w-3.5 h-3.5" />
            {isFa ? 'سایت فعلی (ضعیف)' : 'Legacy Site'}
          </span>
          <span className="text-neutral-300 dark:text-neutral-700">|</span>
          <span className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-medium">
            <CheckCircle className="w-3.5 h-3.5" />
            {isFa ? 'کانسپت جدید (مدرن)' : 'Redesigned Concept'}
          </span>
        </div>
      </div>

      {/* Interactive Display Area */}
      {viewMode === 'slider' ? (
        <div
          ref={containerRef}
          onPointerDown={handlePointerDown}
          onPointerUp={handlePointerUp}
          onPointerMove={handlePointerMove}
          className="relative w-full h-[620px] rounded-2xl overflow-hidden select-none border border-neutral-300 dark:border-neutral-800 shadow-sm cursor-ew-resize bg-neutral-900"
        >
          {/* Base: Redesigned Site (Right side in RTL or Left side in LTR) */}
          <div className="absolute inset-0 w-full h-full bg-slate-900 text-slate-100 flex flex-col overflow-hidden">
            <RedesignedMockup project={project} isFa={isFa} />
          </div>

          {/* Overlay: Old Legacy Site (Clipped by slider position) */}
          <div
            className="absolute inset-y-0 start-0 overflow-hidden bg-[#eef1f5] text-slate-800 border-e-2 border-white shadow-2xl"
            style={{ width: `${sliderPosition}%` }}
          >
            {/* Inner fixed width container to prevent layout squishing */}
            <div className="w-[1152px] h-[620px] relative pointer-events-none">
              <LegacyMockup clientName={clientName} isFa={isFa} />
            </div>
          </div>

          {/* Slider Divider Handle */}
          <div
            className="absolute top-0 bottom-0 z-20 flex flex-col items-center justify-center pointer-events-none"
            style={{ left: `${sliderPosition}%`, transform: 'translateX(-50%)' }}
          >
            <div className="w-0.5 h-full bg-white shadow-md" />
            <div className="w-9 h-9 rounded-full bg-white dark:bg-neutral-900 text-neutral-800 dark:text-white shadow-xl flex items-center justify-center border-2 border-neutral-200 dark:border-neutral-700 cursor-ew-resize">
              <div className="flex gap-0.5">
                <div className="w-0.5 h-3 bg-neutral-400 rounded-full" />
                <div className="w-0.5 h-3 bg-neutral-400 rounded-full" />
              </div>
            </div>
            <div className="w-0.5 h-full bg-white shadow-md" />
          </div>

          {/* Label Badges */}
          <div className="absolute top-4 start-4 z-10 px-3 py-1 bg-rose-600/90 backdrop-blur-xs text-white text-xs font-bold rounded shadow-md pointer-events-none">
            {isFa ? 'سایت قدیمی کارفرما (قبل)' : 'Legacy Site (Before)'}
          </div>
          <div className="absolute top-4 end-4 z-10 px-3 py-1 bg-emerald-600/90 backdrop-blur-xs text-white text-xs font-bold rounded shadow-md pointer-events-none">
            {isFa ? 'طرح بازطراحی‌شده مدرن (بعد)' : 'Redesigned (After)'}
          </div>

          {/* Interactive Hotspot Pins on Redesign layer */}
          {sliderPosition < 80 &&
            hotspots.map((hs) => (
              <button
                key={hs.id}
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setActiveHotspot(activeHotspot === hs.id ? null : hs.id);
                }}
                className={`absolute z-30 w-7 h-7 -translate-x-1/2 -translate-y-1/2 rounded-full font-mono text-xs font-bold flex items-center justify-center transition-transform hover:scale-115 shadow-lg border-2 ${
                  activeHotspot === hs.id
                    ? 'bg-white text-neutral-900 border-neutral-900 ring-4 ring-neutral-400/40'
                    : 'bg-emerald-500 text-white border-white animate-bounce-subtle'
                }`}
                style={{
                  left: isFa ? `${100 - hs.x}%` : `${hs.x}%`,
                  top: `${hs.y}%`,
                }}
                title={isFa ? hs.titleFa : hs.titleEn}
              >
                {hs.id}
              </button>
            ))}
        </div>
      ) : (
        /* Side by Side Mode */
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Legacy Side */}
          <div className="border border-rose-300 dark:border-rose-900/40 rounded-2xl overflow-hidden shadow-xs">
            <div className="bg-rose-50 dark:bg-rose-950/30 px-4 py-2.5 border-b border-rose-200 dark:border-rose-900/50 flex items-center justify-between">
              <span className="text-xs font-bold text-rose-700 dark:text-rose-300">
                {isFa ? 'سایت فعلی کارفرما (معماری قدیمی و اصطکاک بالا)' : 'Current Legacy Website (High Friction)'}
              </span>
              <span className="text-[11px] text-rose-500">Bounce: 68% · LCP: 4.2s</span>
            </div>
            <div className="h-[520px] overflow-y-auto">
              <LegacyMockup clientName={clientName} isFa={isFa} />
            </div>
          </div>

          {/* Redesigned Side */}
          <div className="border border-emerald-300 dark:border-emerald-900/40 rounded-2xl overflow-hidden shadow-xs">
            <div className="bg-emerald-50 dark:bg-emerald-950/30 px-4 py-2.5 border-b border-emerald-200 dark:border-emerald-900/50 flex items-center justify-between">
              <span className="text-xs font-bold text-emerald-700 dark:text-emerald-300">
                {isFa ? 'کانسپت بازطراحی‌شده (هویت لوکس و بهینه برای تبدیل)' : 'Redesigned Concept (Conversion-Focused)'}
              </span>
              <span className="text-[11px] text-emerald-600 font-medium">Bounce: 24% · LCP: 1.1s</span>
            </div>
            <div className="h-[520px] overflow-y-auto bg-slate-900 text-slate-100">
              <RedesignedMockup project={project} isFa={isFa} />
            </div>
          </div>
        </div>
      )}

      {/* Hotspots Explanation Drawer / Bar */}
      <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl p-5 space-y-3 shadow-xs">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-emerald-500" />
          <h3 className="text-sm font-bold text-neutral-900 dark:text-white">
            {isFa ? 'استدلال‌های بازطراحی و نقاط تحول (نقاط ۱ تا ۵)' : 'Architectural Transformation Rationale'}
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {hotspots.map((hs) => (
            <div
              key={hs.id}
              onClick={() => setActiveHotspot(hs.id)}
              className={`p-3 rounded-xl border text-xs cursor-pointer transition-all ${
                activeHotspot === hs.id
                  ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 border-neutral-900 dark:border-white shadow-xs'
                  : 'bg-neutral-50 dark:bg-neutral-800/40 text-neutral-700 dark:text-neutral-300 border-neutral-200 dark:border-neutral-800 hover:border-neutral-300'
              }`}
            >
              <div className="flex items-center gap-2 font-bold mb-1">
                <span className="w-5 h-5 rounded-full bg-emerald-500 text-white flex items-center justify-center font-mono text-[11px]">
                  {hs.id}
                </span>
                <span>{isFa ? hs.titleFa : hs.titleEn}</span>
              </div>
              <p className={`text-[11px] leading-relaxed ${activeHotspot === hs.id ? 'opacity-90' : 'text-neutral-500 dark:text-neutral-400'}`}>
                {isFa ? hs.descFa : hs.descEn}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// Sub-Component: Realistic Old Clunky Website Mockup
const LegacyMockup: React.FC<{ clientName: string; isFa: boolean }> = ({ clientName, isFa }) => {
  return (
    <div className="p-4 sm:p-6 bg-[#f4f6f9] text-[#2c3e50] font-sans text-xs space-y-4 min-h-[620px]">
      {/* Old Chaotic Marquee */}
      <div className="bg-[#fff3cd] border border-[#ffeeba] text-[#856404] px-3 py-1 text-[11px] flex items-center justify-between font-mono">
        <span>⚠ {isFa ? 'اطلاعیه مهم: ساعات کاری در تعطیلات تغییر کرده است... لطفا تماس بگیرید!' : 'Notice: Operating hours have changed... Please call us!'}</span>
        <span className="text-[10px]">2014-03-12</span>
      </div>

      {/* Old Nested Header */}
      <div className="bg-[#2c3e50] text-white p-3 rounded-t-sm shadow-xs flex flex-col gap-2">
        <div className="flex items-center justify-between border-b border-slate-600 pb-2">
          <div className="text-base font-serif font-bold text-yellow-300">
            ★ {clientName} ★
          </div>
          <div className="text-[10px] text-gray-300">
            {isFa ? 'تلفن تماس: 021-88880000 | فکس: 021-88880001' : 'Tel: +1-800-555-0199'}
          </div>
        </div>

        {/* 12 Tiny Unordered Links */}
        <div className="flex flex-wrap gap-x-3 gap-y-1 text-[10px] text-blue-200 underline">
          <span>{isFa ? 'صفحه نخست' : 'Home'}</span>
          <span>{isFa ? 'درباره ما' : 'About'}</span>
          <span>{isFa ? 'تاریخچه شرکت' : 'History'}</span>
          <span>{isFa ? 'لیست خدمات و تعرفه‌ها' : 'Services'}</span>
          <span>{isFa ? 'گالری عکس پرسنل' : 'Staff'}</span>
          <span>{isFa ? 'اخبار و مقالات پزشکی' : 'Articles'}</span>
          <span>{isFa ? 'دانلود کاتالوگ PDF' : 'Download PDF'}</span>
          <span>{isFa ? 'پیوندهای مفید' : 'Useful Links'}</span>
          <span>{isFa ? 'همکاری با ما' : 'Careers'}</span>
          <span>{isFa ? 'فرم نظرسنجی' : 'Survey'}</span>
          <span>{isFa ? 'تماس با مدیریت' : 'Contact Us'}</span>
        </div>
      </div>

      {/* Old Hero Section */}
      <div className="bg-white p-4 border border-gray-300 shadow-xs space-y-3">
        <h2 className="text-base font-serif font-bold text-[#b71c1c] text-center border-b pb-1">
          {isFa ? '« به وب‌سایت رسمی و پایگاه اطلاع‌رسانی ما خوش آمدید »' : 'Welcome to Our Official Website & Portal'}
        </h2>

        <div className="grid grid-cols-3 gap-3 items-center">
          <div className="col-span-2 space-y-2 text-[11px] leading-relaxed text-gray-700">
            <p>
              {isFa
                ? 'مجموعه ما مفتخر است با سال‌ها سابقه درخشان در زمینه ارائه خدمات متنوع و بهره‌گیری از کادری مجرب و تجهیزات، در خدمت کلیه هموطنان و مشتریان گرامی باشد. جهت کسب اطلاعات تکمیلی و آشنایی با واحدها به بخش خدمات مراجعه نمایید.'
                : 'We are proud to offer our comprehensive range of general services with experienced staff and various departments. Please browse our links below to discover more about our organizational background.'}
            </p>
            <div className="flex gap-2 pt-1">
              <button className="bg-gradient-to-r from-red-600 to-red-700 text-white font-bold px-3 py-1 rounded text-[11px] shadow-xs border border-red-800">
                {isFa ? 'برای ثبت سفارش اینجا کلیک نمایید >>' : 'Click Here To Order >>'}
              </button>
              <button className="bg-gray-200 text-gray-700 px-2 py-1 rounded text-[10px] border">
                {isFa ? 'دانلود فرم خام' : 'Download Form'}
              </button>
            </div>
          </div>

          <div className="col-span-1 bg-gray-200 h-28 border border-gray-400 flex flex-col items-center justify-center text-gray-500 text-[10px] text-center p-2">
            <span>[تصویر قدیمی با رزولوشن پایین]</span>
            <span className="text-[9px] text-gray-400 mt-1">400x300.jpg (uncompressed)</span>
          </div>
        </div>
      </div>

      {/* Old 3 Column Boxes */}
      <div className="grid grid-cols-3 gap-2">
        <div className="bg-[#e8f4f8] p-2.5 border border-[#bce8f1] rounded text-[11px]">
          <div className="font-bold text-[#31708f] border-b pb-1 mb-1">
            {isFa ? '• بخش خدمات تخصصی' : 'Specialized Dept'}
          </div>
          <p className="text-gray-600 text-[10px]">
            {isFa ? 'ارائه خدمات با کادر متخصص و پاسخگویی در ساعات اداری.' : 'Services delivered during standard office hours.'}
          </p>
        </div>
        <div className="bg-[#fcf8e3] p-2.5 border border-[#faebcc] rounded text-[11px]">
          <div className="font-bold text-[#8a6d3b] border-b pb-1 mb-1">
            {isFa ? '• اطلاعیه پذیرش' : 'Intake Notice'}
          </div>
          <p className="text-gray-600 text-[10px]">
            {isFa ? 'جهت نوبت‌گیری فرم شماره ۴ را تکمیل و فکس نمایید.' : 'Fill form #4 and send via fax.'}
          </p>
        </div>
        <div className="bg-[#dff0d8] p-2.5 border border-[#d6e9c6] rounded text-[11px]">
          <div className="font-bold text-[#3c763d] border-b pb-1 mb-1">
            {isFa ? '• پیام مدیرعامل' : 'CEO Message'}
          </div>
          <p className="text-gray-600 text-[10px]">
            {isFa ? 'تلاش ما همواره بر جلب رضایت مشتریان استوار بوده است.' : 'Customer satisfaction is our utmost duty.'}
          </p>
        </div>
      </div>

      {/* Old Cluttered Footer */}
      <div className="bg-[#34495e] text-gray-300 p-3 rounded-b-sm text-[10px] flex items-center justify-between border-t-2 border-yellow-400">
        <div>{isFa ? 'تمامی حقوق برای این وب‌سایت محفوظ است © ۱۳۹۵-۱۳۹۰' : 'All Rights Reserved © 2014'}</div>
        <div className="font-mono bg-black/40 px-2 py-0.5 rounded text-green-400">
          {isFa ? 'بازدید امروز: ۰۰۱۴ | آنلاین: ۲ نفر' : 'Hits: 0014 | Online: 2'}
        </div>
      </div>
    </div>
  );
};

// Sub-Component: Sleek Modern Redesigned Mockup
const RedesignedMockup: React.FC<{ project: RedesignProject; isFa: boolean }> = ({ project, isFa }) => {
  const clientName = project.clientName || (isFa ? 'کلینیک و کسب‌وکار نوین' : 'Modern Platform');
  const headline = project.analysis?.conversionStrategy?.headlineImprovement || 
    (isFa ? 'ارائه بالاترین استانداردهای کیفیت و نوآوری با تجربه‌ای فراتر از انتظار' : 'Authoritative Quality Engineered for Modern Performance');
  const cta = project.analysis?.conversionStrategy?.primaryCtaRecommendation || 
    (isFa ? 'رزرو آنلاین نوبت در ۱ دقیقه' : 'Schedule Discovery Call');

  return (
    <div className="bg-slate-950 text-slate-100 flex flex-col justify-between h-full p-4 sm:p-6 font-sans">
      {/* Modern 3-Zone Clean Header */}
      <div className="flex items-center justify-between pb-4 border-b border-slate-800">
        <div className="text-base font-bold tracking-tight text-white flex items-center gap-2">
          <span className="w-6 h-6 rounded bg-emerald-500 text-slate-950 flex items-center justify-center font-mono text-xs font-black">
            ✦
          </span>
          <span>{clientName}</span>
        </div>

        <div className="hidden sm:flex items-center gap-5 text-xs text-slate-300">
          <span className="hover:text-white transition-colors">{isFa ? 'خدمات تخصصی' : 'Capabilities'}</span>
          <span className="hover:text-white transition-colors">{isFa ? 'نمونه‌کارها و نتایج' : 'Case Studies'}</span>
          <span className="hover:text-white transition-colors">{isFa ? 'درباره ما' : 'About'}</span>
          <span className="hover:text-white transition-colors">{isFa ? 'تعرفه‌ها' : 'Pricing'}</span>
        </div>

        <button className="px-3.5 py-1.5 text-xs font-semibold bg-white text-slate-950 rounded-lg hover:bg-slate-200 transition-colors shadow-xs">
          {cta}
        </button>
      </div>

      {/* Hero Section Split */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center py-4 my-auto">
        <div className="md:col-span-7 space-y-4">
          <div className="inline-flex items-center gap-2 text-[11px] text-emerald-400 font-medium">
            <span>{isFa ? 'استاندارد بازطراحی ۲۰۲۶' : '2026 Redesign Standard'}</span>
            <span>·</span>
            <span>{isFa ? 'بهینه‌شده برای موبایل و سئو' : 'Mobile-First & Sub-1.5s Speed'}</span>
          </div>

          <h2 className="text-lg sm:text-xl md:text-2xl font-bold tracking-tight text-white leading-snug" style={{ textWrap: 'balance' }}>
            {headline}
          </h2>

          <p className="text-xs text-slate-400 leading-relaxed max-w-xl">
            {isFa
              ? 'با معماری ساده و بدون سردرگمی، در کمتر از ۳ ثانیه پاسخ نیاز خود را بیابید و از خدمات پیشرفته ما با گارانتی رضایت بهره‌مند شوید.'
              : 'Zero cognitive friction, streamlined workflows, and certified excellence engineered to multiply your inbound conversions.'}
          </p>

          <div className="flex items-center gap-3 pt-1">
            <button className="px-4 py-2 text-xs font-semibold bg-emerald-500 hover:bg-emerald-400 text-slate-950 rounded-lg transition-colors shadow-sm">
              {cta}
            </button>
            <button className="px-4 py-2 text-xs font-medium border border-slate-700 text-slate-300 hover:text-white rounded-lg transition-colors">
              {isFa ? 'مشاهده نتایج مراجعین' : 'Explore Outcomes'}
            </button>
          </div>
        </div>

        {/* High-Fi Visual Asset Showcase */}
        <div className="md:col-span-5 relative">
          <div className="rounded-xl overflow-hidden border border-slate-700/80 shadow-2xl bg-slate-900">
            <img
              src="/src/assets/images/hero_redesign_studio_1794063201885.jpg"
              alt="Redesigned UI Studio"
              className="w-full h-44 object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="p-3 bg-slate-900/90 border-t border-slate-800 flex items-center justify-between text-xs">
              <span className="text-slate-300 font-medium">{isFa ? 'پروتوتایپ تعاملی نسخه موبایل' : 'Mobile Interactive Prototype'}</span>
              <span className="font-mono text-emerald-400 font-semibold">+۱۴۰٪ بازدهی</span>
            </div>
          </div>
        </div>
      </div>

      {/* 3 Metric Social Proof Strip */}
      <div className="pt-3 border-t border-slate-800 grid grid-cols-3 gap-4 text-center">
        <div>
          <div className="text-base font-bold font-mono text-white">۹۸.۶٪</div>
          <div className="text-[10px] text-slate-400">{isFa ? 'رضایت ثبت‌شده مراجعان' : 'Client Satisfaction'}</div>
        </div>
        <div>
          <div className="text-base font-bold font-mono text-white">۱.۱s</div>
          <div className="text-[10px] text-slate-400">{isFa ? 'سرعت لود اول در موبایل' : 'First Contentful Paint'}</div>
        </div>
        <div>
          <div className="text-base font-bold font-mono text-white">۳x</div>
          <div className="text-[10px] text-slate-400">{isFa ? 'افزایش رزرو و استعلام' : 'Lead Conversion Rate'}</div>
        </div>
      </div>
    </div>
  );
};
