import React, { useState } from 'react';
import { ShieldAlert, Check, Copy, Sparkles, Layers, Palette, Type, ArrowUpRight, CheckCircle2 } from 'lucide-react';
import { RedesignProject, Language, AuditItem } from '../types/redesign';

interface AuditViewProps {
  project: RedesignProject;
  language: Language;
  onNavigateToBeforeAfter: () => void;
  onNavigateToPrototype: () => void;
}

export const AuditView: React.FC<AuditViewProps> = ({
  project,
  language,
  onNavigateToBeforeAfter,
  onNavigateToPrototype,
}) => {
  const isFa = language === 'fa';
  const [copiedHex, setCopiedHex] = useState<string | null>(null);

  const analysis = project.analysis;

  const handleCopy = (hex: string) => {
    navigator.clipboard.writeText(hex);
    setCopiedHex(hex);
    setTimeout(() => setCopiedHex(null), 2000);
  };

  if (!analysis) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center space-y-4">
        <div className="w-12 h-12 mx-auto rounded-full bg-neutral-100 dark:bg-neutral-800 flex items-center justify-center text-neutral-500">
          <ShieldAlert className="w-6 h-6" />
        </div>
        <h2 className="text-xl font-bold text-neutral-900 dark:text-white">
          {isFa ? 'هنوز تحلیلی برای این پروژه ثبت نشده است' : 'No Analysis Found'}
        </h2>
        <p className="text-sm text-neutral-600 dark:text-neutral-400">
          {isFa
            ? 'لطفاً به تب "اطلاعات پروژه" برگردید و دکمه "تحلیل عارضه‌ها و تدوین استراتژی" را بزنید.'
            : 'Please navigate back to Project Intake to generate a redesign audit.'}
        </p>
      </div>
    );
  }

  const { brandPersonality, uxUiAudit, conversionStrategy, recommendedDesignSystem, recommendedSections } = analysis;

  const severityBadge = (sev: AuditItem['severity']) => {
    switch (sev) {
      case 'high':
        return (
          <span className="text-xs font-semibold text-rose-600 dark:text-rose-400">
            {isFa ? 'اولویت بحرانی' : 'Critical Priority'}
          </span>
        );
      case 'medium':
        return (
          <span className="text-xs font-semibold text-amber-600 dark:text-amber-400">
            {isFa ? 'اولویت متوسط' : 'Medium Priority'}
          </span>
        );
      default:
        return (
          <span className="text-xs font-semibold text-neutral-500 dark:text-neutral-400">
            {isFa ? 'بهبود تکمیلی' : 'Enhancement'}
          </span>
        );
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 sm:px-6 lg:px-8 space-y-8">
      {/* Overview Header */}
      <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl p-6 sm:p-8 space-y-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-medium text-neutral-500 dark:text-neutral-400 mb-1">
              <span>{project.clientName}</span>
              <span>·</span>
              <span className="font-mono text-xs">{project.websiteUrl || 'domain.com'}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold text-neutral-900 dark:text-white">
              {isFa ? 'گزارش عارضه‌یابی و استراتژی بازطراحی' : 'Comprehensive UX/UI Audit & Strategy'}
            </h1>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onNavigateToBeforeAfter}
              className="px-4 py-2 text-xs font-medium bg-neutral-900 hover:bg-neutral-800 text-white dark:bg-white dark:text-neutral-900 dark:hover:bg-neutral-100 rounded-lg transition-colors whitespace-nowrap shadow-xs"
            >
              {isFa ? 'مشاهده مقایسه قبل و بعد' : 'View Before vs After'}
            </button>
            <button
              onClick={onNavigateToPrototype}
              className="px-4 py-2 text-xs font-medium border border-neutral-200 dark:border-neutral-800 text-neutral-700 dark:text-neutral-200 hover:bg-neutral-50 dark:hover:bg-neutral-800 rounded-lg transition-colors whitespace-nowrap"
            >
              {isFa ? 'پیش‌نمایش زنده دیزاین' : 'Live Prototype'}
            </button>
          </div>
        </div>

        {/* Brand Personality & Positioning */}
        <div className="pt-4 border-t border-neutral-100 dark:border-neutral-800 flex flex-wrap items-center gap-3 text-xs">
          <span className="font-semibold text-neutral-700 dark:text-neutral-300">
            {isFa ? 'لحن و شخصیت بصری جدید:' : 'Brand Tone:'}
          </span>
          <span className="text-neutral-600 dark:text-neutral-300">{brandPersonality.tone}</span>
          <span className="text-neutral-300 dark:text-neutral-700">|</span>
          <div className="flex items-center gap-2 text-neutral-500 dark:text-neutral-400">
            {brandPersonality.attributes.map((attr, idx) => (
              <span key={idx}>
                {attr} {idx < brandPersonality.attributes.length - 1 ? '·' : ''}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* 4 Diagnostic Pillars */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl p-5 shadow-xs">
          <div className="text-xs text-neutral-500 dark:text-neutral-400 mb-1">
            {isFa ? 'شاخص اصطکاک ذهنی (Friction)' : 'Cognitive Friction'}
          </div>
          <div className="text-2xl font-bold font-mono text-neutral-900 dark:text-white mb-1">
            ۷۴ <span className="text-xs font-normal text-rose-500">→ هدف: ۱۲</span>
          </div>
          <p className="text-xs text-neutral-500">
            {isFa ? 'سایت فعلی سردرگمی ایجاد می‌کند و لیدها ریزش دارند.' : 'High friction leading to drop-offs.'}
          </p>
        </div>

        <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl p-5 shadow-xs">
          <div className="text-xs text-neutral-500 dark:text-neutral-400 mb-1">
            {isFa ? 'آمادگی نسخه موبایل (Mobile UX)' : 'Mobile Readiness'}
          </div>
          <div className="text-2xl font-bold font-mono text-neutral-900 dark:text-white mb-1">
            ۳۵٪ <span className="text-xs font-normal text-emerald-500">→ هدف: ۹۸٪</span>
          </div>
          <p className="text-xs text-neutral-500">
            {isFa ? 'دکمه‌های فشرده و منوی تودرتو در موبایل.' : 'Cramped touch targets in legacy layout.'}
          </p>
        </div>

        <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl p-5 shadow-xs">
          <div className="text-xs text-neutral-500 dark:text-neutral-400 mb-1">
            {isFa ? 'وضوح ارزش پیشنهادی (Clarity)' : 'Value Clarity'}
          </div>
          <div className="text-2xl font-bold font-mono text-neutral-900 dark:text-white mb-1">
            ۲۸٪ <span className="text-xs font-normal text-emerald-500">→ هدف: ۹۵٪</span>
          </div>
          <p className="text-xs text-neutral-500">
            {isFa ? 'مخاطب در ۳ ثانیه اول متوجه پیام کارفرما نمی‌شود.' : '3-second hook is missing.'}
          </p>
        </div>

        <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl p-5 shadow-xs">
          <div className="text-xs text-neutral-500 dark:text-neutral-400 mb-1">
            {isFa ? 'سرعت بارگذاری لود اول (LCP)' : 'First Page Speed (LCP)'}
          </div>
          <div className="text-2xl font-bold font-mono text-neutral-900 dark:text-white mb-1">
            ۴.۲s <span className="text-xs font-normal text-emerald-500">→ هدف: ۱.۱s</span>
          </div>
          <p className="text-xs text-neutral-500">
            {isFa ? 'تصاویر سنگین و کدهای بهینه‌نشده.' : 'Heavy unoptimized assets.'}
          </p>
        </div>
      </div>

      {/* Audit Findings Table / Cards */}
      <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl p-6 sm:p-8 space-y-6 shadow-xs">
        <div>
          <h2 className="text-lg font-bold text-neutral-900 dark:text-white">
            {isFa ? 'جزئیات عارضه‌ها و راهکارهای معماری بازطراحی' : 'Identified Pain Points & Solutions'}
          </h2>
          <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">
            {isFa
              ? 'این موارد مهم‌ترین استدلال‌های شما در جلسات دفاع با کارفرما برای توجیه هزینه و ضرورت بازطراحی است.'
              : 'These points form your core rationale during client discovery and proposal defence.'}
          </p>
        </div>

        <div className="space-y-4">
          {uxUiAudit.map((item, index) => (
            <div
              key={index}
              className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-4 sm:p-5 hover:border-neutral-300 dark:hover:border-neutral-700 transition-colors"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs text-neutral-400 font-medium">0{index + 1}.</span>
                  <h3 className="text-sm font-bold text-neutral-900 dark:text-white">{item.issue}</h3>
                </div>
                {severityBadge(item.severity)}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-3 text-xs leading-relaxed">
                <div className="bg-neutral-50 dark:bg-neutral-800/40 p-3 rounded-lg border border-neutral-100 dark:border-neutral-800/80">
                  <span className="font-semibold text-neutral-700 dark:text-neutral-300 block mb-1">
                    {isFa ? 'اثر مخرب بر کسب‌وکار (Impact):' : 'Business Impact:'}
                  </span>
                  <p className="text-neutral-600 dark:text-neutral-400">{item.impact}</p>
                </div>

                <div className="bg-emerald-50/50 dark:bg-emerald-950/20 p-3 rounded-lg border border-emerald-100 dark:border-emerald-900/30">
                  <span className="font-semibold text-emerald-800 dark:text-emerald-300 block mb-1">
                    {isFa ? 'راهکار بازطراحی استاندارد (Redesign Solution):' : 'Recommended Solution:'}
                  </span>
                  <p className="text-emerald-900 dark:text-emerald-200">{item.recommendation}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recommended Design System & Tokens */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Color Palette Tokens */}
        <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl p-6 space-y-4 shadow-xs">
          <div className="flex items-center gap-2">
            <Palette className="w-4 h-4 text-neutral-500" />
            <h3 className="text-base font-bold text-neutral-900 dark:text-white">
              {isFa ? 'پالت رنگی استاندارد (Design Tokens)' : 'Recommended Color Tokens'}
            </h3>
          </div>
          <p className="text-xs text-neutral-500">
            {isFa
              ? 'توزیع رنگی ۶۰-۳۰-۱۰ (۶۰٪ بوم خنثی، ۳۰٪ سطوح ساختاری، ۱۰٪ رنگ تأکیدی اکشن)'
              : 'Disciplined 60-30-10 color allocation for accessible contrast.'}
          </p>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-2">
            {Object.entries(recommendedDesignSystem.colorPalette).map(([key, hex]) => (
              <button
                key={key}
                type="button"
                onClick={() => handleCopy(hex)}
                className="group p-2.5 rounded-xl border border-neutral-200 dark:border-neutral-800 hover:border-neutral-400 text-start transition-all"
              >
                <div
                  className="w-full h-10 rounded-lg mb-2 shadow-xs border border-black/5 dark:border-white/10"
                  style={{ backgroundColor: hex }}
                />
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-medium text-neutral-600 dark:text-neutral-400 capitalize">
                    {key}
                  </span>
                  {copiedHex === hex ? (
                    <Check className="w-3 h-3 text-emerald-500" />
                  ) : (
                    <Copy className="w-3 h-3 opacity-0 group-hover:opacity-100 text-neutral-400 transition-opacity" />
                  )}
                </div>
                <span className="text-xs font-mono font-semibold text-neutral-900 dark:text-white block mt-0.5">
                  {hex}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Typography & Spacing Rules */}
        <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl p-6 space-y-4 shadow-xs">
          <div className="flex items-center gap-2">
            <Type className="w-4 h-4 text-neutral-500" />
            <h3 className="text-base font-bold text-neutral-900 dark:text-white">
              {isFa ? 'سیستم تایپوگرافی و هندسه فضاها' : 'Typography & Spatial Rules'}
            </h3>
          </div>

          <div className="space-y-3 text-xs leading-relaxed">
            <div className="p-3 rounded-xl bg-neutral-50 dark:bg-neutral-800/40 border border-neutral-200 dark:border-neutral-800">
              <span className="font-semibold text-neutral-800 dark:text-neutral-200 block mb-1">
                {isFa ? 'فونت تیترها و عناوین (Display):' : 'Display Typography:'}
              </span>
              <p className="text-neutral-600 dark:text-neutral-300 font-medium">
                {recommendedDesignSystem.typography.displayFont}
              </p>
            </div>

            <div className="p-3 rounded-xl bg-neutral-50 dark:bg-neutral-800/40 border border-neutral-200 dark:border-neutral-800">
              <span className="font-semibold text-neutral-800 dark:text-neutral-200 block mb-1">
                {isFa ? 'فونت متن بدنه و پاراگراف‌ها (Body):' : 'Body Typography:'}
              </span>
              <p className="text-neutral-600 dark:text-neutral-300 font-medium">
                {recommendedDesignSystem.typography.bodyFont}
              </p>
            </div>

            <div className="p-3 rounded-xl bg-neutral-50 dark:bg-neutral-800/40 border border-neutral-200 dark:border-neutral-800">
              <span className="font-semibold text-neutral-800 dark:text-neutral-200 block mb-1">
                {isFa ? 'چرا این ترکیب تایپوگرافی؟' : 'Pairing Rationale:'}
              </span>
              <p className="text-neutral-600 dark:text-neutral-400">
                {recommendedDesignSystem.typography.reason}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Wireframe Strategy Section */}
      <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl p-6 sm:p-8 space-y-6 shadow-xs">
        <div className="flex items-center gap-2">
          <Layers className="w-5 h-5 text-neutral-600 dark:text-neutral-400" />
          <h2 className="text-lg font-bold text-neutral-900 dark:text-white">
            {isFa ? 'راهبرد چیدمان و معماری بخش‌های صفحه اصلی' : 'Homepage Wireframe & Section Architecture'}
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {recommendedSections.map((sec, idx) => (
            <div
              key={idx}
              className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-5 space-y-3 bg-neutral-50/30 dark:bg-neutral-850/30"
            >
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-bold text-neutral-900 dark:text-white">
                  0{idx + 1}. {sec.sectionName}
                </h4>
              </div>

              <div className="space-y-1.5 text-xs">
                <div>
                  <span className="text-neutral-500 font-medium">{isFa ? 'هدف بخش: ' : 'Purpose: '}</span>
                  <span className="text-neutral-700 dark:text-neutral-300">{sec.purpose}</span>
                </div>
                <div>
                  <span className="text-neutral-500 font-medium">{isFa ? 'معماری چیدمان: ' : 'Layout: '}</span>
                  <span className="text-neutral-700 dark:text-neutral-300">{sec.wireframeLayout}</span>
                </div>
              </div>

              <div className="pt-2 border-t border-neutral-200 dark:border-neutral-800/80">
                <span className="text-[11px] font-semibold text-neutral-500 block mb-1.5">
                  {isFa ? 'المان‌های کلیدی این بخش:' : 'Key Elements:'}
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {sec.keyElements.map((el, elIdx) => (
                    <span
                      key={elIdx}
                      className="text-xs text-neutral-700 dark:text-neutral-300 flex items-center gap-1 bg-white dark:bg-neutral-800 px-2 py-0.5 rounded border border-neutral-200 dark:border-neutral-700"
                    >
                      <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                      {el}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
