import React, { useState } from 'react';
import { Sparkles, Copy, Check, RefreshCw } from 'lucide-react';
import { Language } from '../types/redesign';

interface CopywritingHelperProps {
  businessName: string;
  industry: string;
  language: Language;
  onApplyCopy?: (text: string) => void;
}

export const CopywritingHelper: React.FC<CopywritingHelperProps> = ({
  businessName,
  industry,
  language,
  onApplyCopy,
}) => {
  const isFa = language === 'fa';
  const [loading, setLoading] = useState(false);
  const [copiedItem, setCopiedItem] = useState<string | null>(null);

  const [headlines, setHeadlines] = useState<string[]>(
    isFa
      ? [
          `ارائه بالاترین استانداردهای ${industry || 'تخصصی'} با تجربه‌ای متمایز و مدرن`,
          `طراحی دوباره هویت دیجیتال برای ارتباط سریع و پایدار با مشتریان`,
          `کیفیت و شفافیتی که مخاطبان شما شایسته آن هستند`,
        ]
      : [
          `Transforming ${industry || 'solutions'} with verified high-performance standards`,
          `Streamlining digital workflows to accelerate customer conversion`,
          `Engineered precision tailored for sustainable business growth`,
        ]
  );

  const [ctas, setCtas] = useState<string[]>(
    isFa
      ? ['دریافت مشاوره و ارزیابی رایگان', 'رزرو آنلاین نوبت در ۱ دقیقه', 'شروع همکاری در چند گام ساده']
      : ['Schedule Strategic Discovery', 'Book Consultation in 1 Minute', 'Explore Interactive Demo']
  );

  const handleGenerate = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/redesign/generate-copy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          businessName,
          industry,
          sectionType: 'Hero',
          targetAction: 'Conversion',
          language,
        }),
      });
      const data = await res.json();
      if (data.headlines && data.ctas) {
        setHeadlines(data.headlines);
        setCtas(data.ctas);
      }
    } catch (err) {
      console.error('Failed to generate copy:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedItem(text);
    setTimeout(() => setCopiedItem(null), 2000);
  };

  return (
    <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl p-5 sm:p-6 space-y-5 shadow-xs">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-emerald-500" />
          <h3 className="text-sm font-bold text-neutral-900 dark:text-white">
            {isFa ? 'دستیار کپی‌رایتینگ و نگارش تیترهای جذاب' : 'AI Copywriting & Headline Assistant'}
          </h3>
        </div>

        <button
          onClick={handleGenerate}
          disabled={loading}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-800 dark:hover:bg-neutral-700 text-neutral-800 dark:text-neutral-200 rounded-lg transition-colors"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>{isFa ? 'تولید گزینه‌های جدید' : 'Generate More'}</span>
        </button>
      </div>

      {/* Headlines List */}
      <div className="space-y-2">
        <div className="text-xs font-semibold text-neutral-600 dark:text-neutral-400">
          {isFa ? 'تیترهای پیشنهادی برای بخش هیرو:' : 'Suggested Hero Headlines:'}
        </div>
        <div className="space-y-1.5">
          {headlines.map((hl, i) => (
            <div
              key={i}
              className="p-3 rounded-lg border border-neutral-200 dark:border-neutral-800 flex items-center justify-between gap-3 text-xs text-neutral-800 dark:text-neutral-200 hover:border-neutral-300"
            >
              <span>{hl}</span>
              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => handleCopy(hl)}
                  className="p-1 rounded text-neutral-400 hover:text-neutral-900 dark:hover:text-white"
                  title={isFa ? 'کپی متن' : 'Copy'}
                >
                  {copiedItem === hl ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
                {onApplyCopy && (
                  <button
                    type="button"
                    onClick={() => onApplyCopy(hl)}
                    className="text-[11px] font-medium text-emerald-600 hover:underline"
                  >
                    {isFa ? 'اعمال' : 'Apply'}
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* CTA Buttons List */}
      <div className="space-y-2 pt-2 border-t border-neutral-100 dark:border-neutral-800">
        <div className="text-xs font-semibold text-neutral-600 dark:text-neutral-400">
          {isFa ? 'برچسب‌های هدفمند دکمه اقدام (CTA):' : 'High-Intent CTA Button Copy:'}
        </div>
        <div className="flex flex-wrap gap-2">
          {ctas.map((cta, i) => (
            <button
              key={i}
              type="button"
              onClick={() => handleCopy(cta)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-neutral-200 dark:border-neutral-800 text-xs text-neutral-700 dark:text-neutral-300 hover:border-neutral-400"
            >
              <span>{cta}</span>
              {copiedItem === cta ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3 text-neutral-400" />}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
