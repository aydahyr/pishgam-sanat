import React, { useState } from 'react';
import { CheckSquare, Square, AlertCircle, Lightbulb, CheckCircle2, ChevronDown, ChevronUp } from 'lucide-react';
import { Language } from '../types/redesign';

interface RoadmapChecklistProps {
  language: Language;
}

interface StepItem {
  id: string;
  titleFa: string;
  titleEn: string;
  tipFa: string;
  tipEn: string;
  pitfallFa: string;
  pitfallEn: string;
  tasks: {
    id: string;
    textFa: string;
    textEn: string;
  }[];
}

const STEPS: StepItem[] = [
  {
    id: 'stage-1',
    titleFa: 'مرحله ۱: کشف، ارزیابی عمیق و نیازسنجی تجاری',
    titleEn: 'Stage 1: Discovery, Audit & Business Alignment',
    tipFa: 'هرگز بدون جلسه بریفینگ شروع به دیزاین نکنید! از کارفرما بپرسید: «اگر وب‌سایت جدید فقط یک کار انجام دهد که شما آن را موفق بدانید، آن کار چیست؟» (مثلاً: ثبت ۱۰ استعلام در روز).',
    tipEn: 'Never start designing without discovery! Ask the client: "If the new website only accomplishes ONE goal to be deemed successful, what is it?"',
    pitfallFa: 'دام رایج: شروع مستقیم با انتخاب رنگ و قالب بدون دانستن اینکه سایت فعلی چرا مشتری را فراری می‌دهد.',
    pitfallEn: 'Pitfall: Starting with aesthetic themes without identifying current leakage points.',
    tasks: [
      {
        id: 't1-1',
        textFa: 'بررسی آمار گوگل آنالیتیکس سایت فعلی (صفحات با بیشترین بانس ریت و افت کاربر)',
        textEn: 'Audit Google Analytics or heatmaps for highest drop-off pages',
      },
      {
        id: 't1-2',
        textFa: 'مصاحبه ۲۰ دقیقه‌ای با کارفرما درباره پرسونای بهترین مشتریان و رقبا',
        textEn: '20-min client discovery interview on ideal customer profiles and key rivals',
      },
      {
        id: 't1-3',
        textFa: 'استخراج ۳ تا ۵ ارزش پیشنهادی یکتا (Unique Selling Proposition) کسب‌وکار',
        textEn: 'Extract 3-5 concrete Unique Value Propositions',
      },
      {
        id: 't1-4',
        textFa: 'تعیین شاخص‌های کلیدی موفقیت (مثلاً افزایش ۳۰ درصدی تماس‌های تلفنی)',
        textEn: 'Define quantifiable target KPIs (e.g. +30% inquiry completions)',
      },
    ],
  },
  {
    id: 'stage-2',
    titleFa: 'مرحله ۲: مهندسی معماری اطلاعات (IA) و وایرفریمینگ',
    titleEn: 'Stage 2: Information Architecture & Wireframing',
    tipFa: 'وایرفریم‌ها را بدون رنگ و در قالب خاکستری (Greyscale) به کارفرما نشان دهید تا تمرکز او فقط روی ساختار اطلاعات، محتوا و ترتیب پیام‌ها باشد نه سلیقه رنگی.',
    tipEn: 'Present wireframes strictly in grayscale so the client evaluates content hierarchy and flow, rather than arguing over personal color tastes.',
    pitfallFa: 'دام رایج: ایجاد منوهای تودرتوی عمیق. قانون طلایی: کاربر باید با حداکثر ۳ کلیک به هر هدفی در سایت برسد.',
    pitfallEn: 'Pitfall: Deep nested navigation. Apply the 3-click maximum reachability rule.',
    tasks: [
      {
        id: 't2-1',
        textFa: 'طراحی نقشه سایت (Sitemap) تمیز با حذف صفحات تکراری و بی‌فایده قدیمی',
        textEn: 'Produce streamlined sitemap eliminating redundant legacy pages',
      },
      {
        id: 't2-2',
        textFa: 'وایرفریمینگ بخش هیرو بر اساس قاعده قلاب ۳ ثانیه‌ای (تیتر + پیام ارزش + دکمه اقدام)',
        textEn: 'Wireframe hero using the 3-second hook rule (Headline + Value + CTA)',
      },
      {
        id: 't2-3',
        textFa: 'طراحی فرم‌های تماس تک‌مرحله‌ای با حداقل فیلدهای ضروری برای موبایل',
        textEn: 'Design single-step frictionless lead capture forms for mobile',
      },
      {
        id: 't2-4',
        textFa: 'جلسه تایید ساختار و چیدمان محتوا با کارفرما قبل از ورود به فیگما',
        textEn: 'Sign off structural content arrangement with client before visual polish',
      },
    ],
  },
  {
    id: 'stage-3',
    titleFa: 'مرحله ۳: سیستم طراحی (Design System) و UI با کیفیت تجاری',
    titleEn: 'Stage 3: Design System & High-Fidelity UI',
    tipFa: 'از قانون ۶۰-۳۰-۱۰ استفاده کنید: ۶۰٪ پس‌زمینه تمیز، ۳۰٪ ساختار و کارت‌ها، ۱۰٪ رنگ تأکیدی (تنها برای دکمه‌های اصلی و اقدامات مهم). از فونت‌های استاندارد وب فارسی مانند وزیرمتن بهره بگیرید.',
    tipEn: 'Apply the 60-30-10 color discipline and pair high-legibility display with accessible body typography.',
    pitfallFa: 'دام رایج: استفاده از دکمه‌های کپسولی متعدد (Pill Badges)، شیب‌های بنفش مصنوعی و آیکون‌های تزئینی بی‌هدف.',
    pitfallEn: 'Pitfall: AI slop aesthetics (candy capsules, gratuitous sparkle icons, low contrast type).',
    tasks: [
      {
        id: 't3-1',
        textFa: 'تعریف پالت رنگی استاندارد همراه با کنتراست تایید شده WCAG AA (حداقل ۴.۵ به ۱)',
        textEn: 'Define color tokens meeting WCAG AA 4.5:1 text contrast standard',
      },
      {
        id: 't3-2',
        textFa: 'تنظیم سلسله‌مراتب تایپوگرافی ۲ وزنی (تیترهای متعادل و متن بدنه با خوانایی بالا)',
        textEn: 'Establish refined 2-font typographic hierarchy with balanced headlines',
      },
      {
        id: 't3-3',
        textFa: 'طراحی پروتوتایپ کامل نسخه‌های دسکتاپ (۱۴۴۰px) و موبایل (۳۷۵px) در فیگما',
        textEn: 'Craft high-fidelity desktop (1440px) and mobile (375px) screens',
      },
      {
        id: 't3-4',
        textFa: 'استفاده از تصاویر واقعی، اختصاصی و مرتبط (جایگزین استوک‌های بی‌کیفیت)',
        textEn: 'Integrate authentic, context-specific commercial visual assets',
      },
    ],
  },
  {
    id: 'stage-4',
    titleFa: 'مرحله ۴: تست کاربری و تاییدیه نهایی کارفرما',
    titleEn: 'Stage 4: Usability Validation & Sign-off',
    tipFa: 'طرح پروتوتایپ فیگما را روی گوشی واقعی خود کارفرما باز کنید تا خودش دکمه‌ها را لمس کند؛ این کار ۹۰٪ ابهامات و مخالفت‌ها را رفع می‌کند.',
    tipEn: 'Hand your phone to the client with the clickable prototype running full-screen to test touch ergonomics.',
    pitfallFa: 'دام رایج: پذیرفتن تغییرات سلیقه‌ای بی‌پایان (Scope Creep). هر تغییر جدید را با ملاک «آیا این تغییر لید بیشتری می‌آورد؟» بسنجید.',
    pitfallEn: 'Pitfall: Unbounded scope creep. Measure every request against the primary business objective.',
    tasks: [
      {
        id: 't4-1',
        textFa: 'تست فلوچارت ثبت سفارش یا نوبت با ۳ کاربر واقعی و ثبت نقاط گیر افتادن',
        textEn: 'Conduct 3 quick user usability sessions on mobile touch flows',
      },
      {
        id: 't4-2',
        textFa: 'بررسی ارگونومی دست در موبایل (اندازه دکمه‌ها حداقل ۴۴ پیکسل)',
        textEn: 'Verify minimum 44px thumb target ergonomics across critical inputs',
      },
      {
        id: 't4-3',
        textFa: 'دریافت تاییدیه مکتوب نسخه UI پیش از شروع کدنویسی',
        textEn: 'Obtain written milestone sign-off before entering production code',
      },
    ],
  },
  {
    id: 'stage-5',
    titleFa: 'مرحله ۵: توسعه، بهینه‌سازی سرعت و مهاجرت امن سئو',
    titleEn: 'Stage 5: Production Code, Speed & SEO Migration',
    tipFa: 'هنگام تغییر آدرس صفحات سایت قدیمی، حتماً ریدایرکت‌های ۳۰۱ (Redirect 301) را تنظیم کنید تا رتبه سئو و لینک‌های ورودی کارفرما نسوزد.',
    tipEn: 'Never break legacy search engine rankings! Map and set 301 redirects for every changed URL.',
    pitfallFa: 'دام رایج: آپلود تصاویر بزرگ چند مگابایتی و غافل شدن از فشرده‌سازی WebP و کش مرورگر.',
    pitfallEn: 'Pitfall: Large uncompressed images destroying mobile speed scores.',
    tasks: [
      {
        id: 't5-1',
        textFa: 'توسعه فرانت‌اند استاندارد، ماژولار و ریسپانسیو با ری‌اکت و تیل‌ویند',
        textEn: 'Build responsive, production-ready frontend using React & Tailwind',
      },
      {
        id: 't5-2',
        textFa: 'بهینه‌سازی تصاویر به فرمت مدرن WebP و دستیابی به سرعت زیر ۱.۵ ثانیه',
        textEn: 'Compress all media to WebP and ensure sub-1.5s Core Web Vitals',
      },
      {
        id: 't5-3',
        textFa: 'تنظیم جدول ریدایرکت‌های ۳۰۱ از URLهای قدیمی به صفحات جدید',
        textEn: 'Configure complete 301 redirect map for legacy indexed URLs',
      },
      {
        id: 't5-4',
        textFa: 'تست نهایی درگاه پرداخت، فرم‌های پیامک و آموزش تحویل به کارفرما',
        textEn: 'Validate form pipelines, webhook integrations, and client handoff training',
      },
    ],
  },
];

export const RoadmapChecklist: React.FC<RoadmapChecklistProps> = ({ language }) => {
  const isFa = language === 'fa';
  const [completedTasks, setCompletedTasks] = useState<Record<string, boolean>>({
    't1-1': true,
    't1-2': true,
  });
  const [expandedSteps, setExpandedSteps] = useState<Record<string, boolean>>({
    'stage-1': true,
    'stage-2': true,
  });

  const totalTasks = STEPS.reduce((acc, step) => acc + step.tasks.length, 0);
  const doneCount = Object.values(completedTasks).filter(Boolean).length;
  const progressPercent = Math.round((doneCount / totalTasks) * 100);

  const toggleTask = (taskId: string) => {
    setCompletedTasks((prev) => ({
      ...prev,
      [taskId]: !prev[taskId],
    }));
  };

  const toggleStep = (stepId: string) => {
    setExpandedSteps((prev) => ({
      ...prev,
      [stepId]: !prev[stepId],
    }));
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 sm:px-6 lg:px-8 space-y-6">
      {/* Header & Overall Progress */}
      <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl p-6 sm:p-8 space-y-4 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 text-xs font-semibold text-neutral-500 mb-1">
              <span>{isFa ? 'نقشه راه استاندارد طراحی' : 'Executive Methodology'}</span>
              <span>·</span>
              <span>{isFa ? '۵ گام کلیدی' : '5 Core Stages'}</span>
            </div>
            <h1 className="text-2xl font-bold text-neutral-900 dark:text-white">
              {isFa ? 'چک‌لیست گام به گام بازطراحی وب‌سایت برای طراحان' : 'Step-by-Step Website Redesign Master Checklist'}
            </h1>
          </div>

          <div className="text-end sm:text-start bg-neutral-50 dark:bg-neutral-800/60 p-3 rounded-xl border border-neutral-200 dark:border-neutral-700/60 shrink-0">
            <div className="text-xs text-neutral-500 mb-1">
              {isFa ? 'پیشرفت کل پروژه:' : 'Total Progress:'}
            </div>
            <div className="flex items-center gap-2">
              <div className="text-xl font-bold font-mono text-neutral-900 dark:text-white">
                {progressPercent}٪
              </div>
              <span className="text-xs text-neutral-400">
                ({doneCount} {isFa ? 'از' : 'of'} {totalTasks})
              </span>
            </div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-neutral-100 dark:bg-neutral-800 h-2 rounded-full overflow-hidden">
          <div
            className="bg-neutral-900 dark:bg-white h-full transition-all duration-300"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>

      {/* 5 Stages Accordion */}
      <div className="space-y-4">
        {STEPS.map((step, idx) => {
          const isExpanded = expandedSteps[step.id] ?? true;
          const stepDoneCount = step.tasks.filter((t) => completedTasks[t.id]).length;
          const isStepFullyDone = stepDoneCount === step.tasks.length;

          return (
            <div
              key={step.id}
              className={`bg-white dark:bg-neutral-900 border rounded-2xl overflow-hidden transition-all shadow-xs ${
                isStepFullyDone
                  ? 'border-emerald-300 dark:border-emerald-800/60'
                  : 'border-neutral-200 dark:border-neutral-800'
              }`}
            >
              {/* Step Header */}
              <button
                type="button"
                onClick={() => toggleStep(step.id)}
                className="w-full p-5 sm:p-6 flex items-center justify-between text-start hover:bg-neutral-50/50 dark:hover:bg-neutral-800/40 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <span
                    className={`w-7 h-7 rounded-lg font-mono text-xs font-bold flex items-center justify-center shrink-0 ${
                      isStepFullyDone
                        ? 'bg-emerald-500 text-white'
                        : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300'
                    }`}
                  >
                    0{idx + 1}
                  </span>
                  <div>
                    <h3 className="text-sm sm:text-base font-bold text-neutral-900 dark:text-white">
                      {isFa ? step.titleFa : step.titleEn}
                    </h3>
                    <span className="text-xs text-neutral-500">
                      {stepDoneCount} {isFa ? 'از' : 'of'} {step.tasks.length} {isFa ? 'وظیفه تکمیل شد' : 'completed'}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2 text-neutral-400">
                  {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                </div>
              </button>

              {/* Step Content */}
              {isExpanded && (
                <div className="p-5 sm:p-6 pt-0 border-t border-neutral-100 dark:border-neutral-800 space-y-4">
                  {/* Practical Advice & Pitfall */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-3">
                    <div className="p-3.5 rounded-xl bg-amber-50/60 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/40 text-xs space-y-1">
                      <div className="flex items-center gap-1.5 font-bold text-amber-900 dark:text-amber-300">
                        <Lightbulb className="w-3.5 h-3.5" />
                        <span>{isFa ? 'توصیه طلایی در جلسه با کارفرما:' : 'Client Presentation Tip:'}</span>
                      </div>
                      <p className="text-amber-950 dark:text-amber-200 leading-relaxed">
                        {isFa ? step.tipFa : step.tipEn}
                      </p>
                    </div>

                    <div className="p-3.5 rounded-xl bg-rose-50/60 dark:bg-rose-950/20 border border-rose-200 dark:border-rose-900/40 text-xs space-y-1">
                      <div className="flex items-center gap-1.5 font-bold text-rose-900 dark:text-rose-300">
                        <AlertCircle className="w-3.5 h-3.5" />
                        <span>{isFa ? 'اشتباه مرگبار برای اجتناب:' : 'Common Fatal Pitfall:'}</span>
                      </div>
                      <p className="text-rose-950 dark:text-rose-200 leading-relaxed">
                        {isFa ? step.pitfallFa : step.pitfallEn}
                      </p>
                    </div>
                  </div>

                  {/* Tasks List */}
                  <div className="space-y-2 pt-2">
                    <div className="text-xs font-semibold text-neutral-700 dark:text-neutral-300">
                      {isFa ? 'اقدامات عملی این مرحله:' : 'Actionable Tasks:'}
                    </div>

                    <div className="space-y-1.5">
                      {step.tasks.map((task) => {
                        const isDone = completedTasks[task.id];
                        return (
                          <button
                            type="button"
                            key={task.id}
                            onClick={() => toggleTask(task.id)}
                            className={`w-full p-3 rounded-xl border text-start text-xs flex items-center gap-3 transition-colors ${
                              isDone
                                ? 'bg-neutral-50 dark:bg-neutral-800/40 border-neutral-200 dark:border-neutral-700/60 text-neutral-500 line-through'
                                : 'bg-white dark:bg-neutral-850 border-neutral-200 dark:border-neutral-800 text-neutral-800 dark:text-neutral-200 hover:border-neutral-300'
                            }`}
                          >
                            <span className="shrink-0 text-neutral-400">
                              {isDone ? (
                                <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                              ) : (
                                <Square className="w-4 h-4" />
                              )}
                            </span>
                            <span className="leading-relaxed">{isFa ? task.textFa : task.textEn}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
