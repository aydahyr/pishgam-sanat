import React, { useState } from 'react';
import { Monitor, Tablet, Smartphone, Code, CheckCircle, Send, Sparkles, X, ChevronRight, Menu } from 'lucide-react';
import { RedesignProject, Language } from '../types/redesign';

interface LivePrototypeProps {
  project: RedesignProject;
  language: Language;
}

type DeviceMode = 'desktop' | 'tablet' | 'mobile';
type ThemeStyle = 'minimalist' | 'luxury' | 'tech' | 'clinical';

export const LivePrototype: React.FC<LivePrototypeProps> = ({ project, language }) => {
  const isFa = language === 'fa';
  const [device, setDevice] = useState<DeviceMode>('desktop');
  const [theme, setTheme] = useState<ThemeStyle>('minimalist');
  const [showInspector, setShowInspector] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Interactive Form State
  const [formName, setFormName] = useState('');
  const [formPhone, setFormPhone] = useState('');
  const [formSubmitted, setFormSubmitted] = useState(false);

  const clientName = project.clientName || (isFa ? 'برند و کسب‌وکار شما' : 'Acme Studio');
  const analysis = project.analysis;
  const headline = analysis?.conversionStrategy?.headlineImprovement || 
    (isFa ? 'طراحی مجدد هویت دیجیتال برای افزایش ۳ برابری سرنخ‌های فروش' : 'Accelerating Qualified Inbound Conversions With Modern Architecture');
  const cta = analysis?.conversionStrategy?.primaryCtaRecommendation || 
    (isFa ? 'دریافت مشاوره و ارزیابی رایگان' : 'Schedule Discovery Call');

  const themes = {
    minimalist: {
      nameFa: 'مینیمال مدرن',
      nameEn: 'Modern Minimal',
      bg: 'bg-white dark:bg-neutral-950',
      text: 'text-neutral-900 dark:text-neutral-100',
      accent: 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 hover:bg-neutral-800',
      secondaryBtn: 'border border-neutral-300 dark:border-neutral-700 text-neutral-800 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-neutral-800',
      cardBg: 'bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800',
      accentColorHex: '#0F172A',
    },
    luxury: {
      nameFa: 'ادیتوریال لوکس',
      nameEn: 'Editorial Luxury',
      bg: 'bg-[#FAF8F5] dark:bg-[#181614]',
      text: 'text-[#2C2825] dark:text-[#EDE8E3]',
      accent: 'bg-[#3D352E] text-[#FAF8F5] dark:bg-[#D6C7B2] dark:text-[#2C2825] hover:opacity-90',
      secondaryBtn: 'border border-[#D6C7B2] text-[#3D352E] dark:text-[#D6C7B2] hover:bg-[#F2ECE4] dark:hover:bg-[#25221F]',
      cardBg: 'bg-[#F4EFEA] dark:bg-[#221F1C] border border-[#E3DACF] dark:border-[#38332D]',
      accentColorHex: '#3D352E',
    },
    tech: {
      nameFa: 'تک‌ساآس پیشرفته',
      nameEn: 'Tech SaaS Slate',
      bg: 'bg-slate-950',
      text: 'text-slate-100',
      accent: 'bg-emerald-500 text-slate-950 hover:bg-emerald-400 font-semibold',
      secondaryBtn: 'border border-slate-700 text-slate-300 hover:bg-slate-800 hover:text-white',
      cardBg: 'bg-slate-900 border border-slate-800',
      accentColorHex: '#10B981',
    },
    clinical: {
      nameFa: 'پزشکی و شرکتی تمیز',
      nameEn: 'Clinical Clean',
      bg: 'bg-sky-50/40 dark:bg-slate-950',
      text: 'text-slate-900 dark:text-slate-100',
      accent: 'bg-sky-600 text-white hover:bg-sky-700 font-semibold',
      secondaryBtn: 'border border-sky-300 dark:border-sky-800 text-sky-900 dark:text-sky-200 hover:bg-sky-100 dark:hover:bg-sky-950/40',
      cardBg: 'bg-white dark:bg-slate-900 border border-sky-100 dark:border-slate-800',
      accentColorHex: '#0284C7',
    },
  };

  const currentTheme = themes[theme];

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName || !formPhone) return;
    setFormSubmitted(true);
    setTimeout(() => {
      setFormSubmitted(false);
      setFormName('');
      setFormPhone('');
    }, 4000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8 space-y-6">
      {/* Controls Bar: Device Switcher & Theme Picker */}
      <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl p-4 sm:p-5 flex flex-wrap items-center justify-between gap-4 shadow-xs">
        {/* Device Switcher */}
        <div className="flex items-center gap-1 p-1 bg-neutral-100 dark:bg-neutral-800 rounded-lg">
          <button
            onClick={() => setDevice('desktop')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              device === 'desktop'
                ? 'bg-white dark:bg-neutral-900 text-neutral-900 dark:text-white shadow-xs font-semibold'
                : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900'
            }`}
          >
            <Monitor className="w-3.5 h-3.5" />
            <span>{isFa ? 'دسکتاپ (1440px)' : 'Desktop'}</span>
          </button>
          <button
            onClick={() => setDevice('tablet')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              device === 'tablet'
                ? 'bg-white dark:bg-neutral-900 text-neutral-900 dark:text-white shadow-xs font-semibold'
                : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900'
            }`}
          >
            <Tablet className="w-3.5 h-3.5" />
            <span>{isFa ? 'تبلت (768px)' : 'Tablet'}</span>
          </button>
          <button
            onClick={() => setDevice('mobile')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              device === 'mobile'
                ? 'bg-white dark:bg-neutral-900 text-neutral-900 dark:text-white shadow-xs font-semibold'
                : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>{isFa ? 'موبایل (375px)' : 'Mobile'}</span>
          </button>
        </div>

        {/* Theme Picker */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-neutral-500 font-medium">
            {isFa ? 'سبک بصری:' : 'Aesthetic:'}
          </span>
          <div className="flex items-center gap-1 p-1 bg-neutral-100 dark:bg-neutral-800 rounded-lg">
            {(Object.keys(themes) as ThemeStyle[]).map((tKey) => (
              <button
                key={tKey}
                onClick={() => setTheme(tKey)}
                className={`px-2.5 py-1 text-xs rounded-md font-medium transition-colors ${
                  theme === tKey
                    ? 'bg-white dark:bg-neutral-900 text-neutral-900 dark:text-white shadow-xs font-semibold'
                    : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900'
                }`}
              >
                {isFa ? themes[tKey].nameFa : themes[tKey].nameEn}
              </button>
            ))}
          </div>

          {/* Code & Tokens Inspector Button */}
          <button
            onClick={() => setShowInspector(!showInspector)}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors ${
              showInspector
                ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 border-neutral-900 dark:border-white'
                : 'border-neutral-200 dark:border-neutral-700 text-neutral-700 dark:text-neutral-300 hover:bg-neutral-50 dark:hover:bg-neutral-800'
            }`}
          >
            <Code className="w-3.5 h-3.5" />
            <span>{isFa ? 'کد و توکن‌های دیزاین' : 'Tokens'}</span>
          </button>
        </div>
      </div>

      {/* Main Canvas Container */}
      <div className="flex justify-center bg-neutral-200/60 dark:bg-neutral-900/40 p-4 sm:p-8 rounded-2xl border border-neutral-200 dark:border-neutral-800 overflow-x-auto min-h-[720px] transition-all">
        {/* Responsive Frame */}
        <div
          className={`transition-all duration-300 shadow-2xl overflow-hidden rounded-xl border border-neutral-300 dark:border-neutral-700 ${
            device === 'desktop'
              ? 'w-full max-w-5xl'
              : device === 'tablet'
              ? 'w-[768px]'
              : 'w-[375px]'
          } ${currentTheme.bg} ${currentTheme.text}`}
        >
          {/* Simulated Browser Chrome */}
          <div className="bg-neutral-100 dark:bg-neutral-850 px-4 py-2 border-b border-neutral-200 dark:border-neutral-800 flex items-center justify-between text-xs text-neutral-500">
            <div className="flex items-center gap-1.5">
              <div className="w-2.5 h-2.5 rounded-full bg-rose-400" />
              <div className="w-2.5 h-2.5 rounded-full bg-amber-400" />
              <div className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
            </div>
            <div className="bg-white dark:bg-neutral-900 px-4 py-0.5 rounded text-[11px] font-mono border border-neutral-200 dark:border-neutral-800 truncate max-w-[280px]">
              https://{project.websiteUrl || 'client-website.com'}
            </div>
            <div className="w-4" />
          </div>

          {/* Prototype Website Body */}
          <div className="space-y-12 pb-16">
            {/* Top Bar (3-Zone Contract) */}
            <header className="px-6 py-4 border-b border-neutral-200/50 dark:border-neutral-800/60 flex items-center justify-between gap-6">
              {/* Zone 1: Brand Wordmark */}
              <div className="text-base font-bold tracking-tight whitespace-nowrap shrink-0 flex items-center gap-2">
                <span className="w-6 h-6 rounded bg-neutral-900 dark:bg-white text-white dark:text-neutral-900 flex items-center justify-center font-bold text-xs">
                  {clientName.charAt(0)}
                </span>
                <span>{clientName}</span>
              </div>

              {/* Zone 2: Nav Links (Desktop/Tablet) */}
              <nav className="hidden md:flex items-center gap-6 text-xs font-medium opacity-80">
                <a href="#services" className="hover:opacity-100 transition-opacity whitespace-nowrap">
                  {isFa ? 'خدمات تخصصی' : 'Capabilities'}
                </a>
                <a href="#results" className="hover:opacity-100 transition-opacity whitespace-nowrap">
                  {isFa ? 'داستان‌های موفقیت' : 'Outcomes'}
                </a>
                <a href="#about" className="hover:opacity-100 transition-opacity whitespace-nowrap">
                  {isFa ? 'درباره ما' : 'About'}
                </a>
                <a href="#contact" className="hover:opacity-100 transition-opacity whitespace-nowrap">
                  {isFa ? 'تماس مستقیم' : 'Contact'}
                </a>
              </nav>

              {/* Zone 3: Primary Action */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    const el = document.getElementById('prototype-contact-form');
                    el?.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className={`hidden sm:inline-flex px-3.5 py-1.5 text-xs rounded-lg transition-colors whitespace-nowrap ${currentTheme.accent}`}
                >
                  {cta}
                </button>

                {/* Mobile Hamburger Toggle */}
                <button
                  onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                  className="md:hidden p-1.5 rounded-lg border border-neutral-300 dark:border-neutral-700"
                >
                  <Menu className="w-4 h-4" />
                </button>
              </div>
            </header>

            {/* Mobile Drawer (if open) */}
            {mobileMenuOpen && (
              <div className="px-6 py-4 border-b border-neutral-200 dark:border-neutral-800 space-y-3 text-xs bg-neutral-50 dark:bg-neutral-900/80">
                <div className="space-y-2">
                  <div className="py-1 font-medium">{isFa ? 'خدمات تخصصی' : 'Capabilities'}</div>
                  <div className="py-1 font-medium">{isFa ? 'داستان‌های موفقیت' : 'Outcomes'}</div>
                  <div className="py-1 font-medium">{isFa ? 'درباره ما' : 'About'}</div>
                  <div className="py-1 font-medium">{isFa ? 'تماس مستقیم' : 'Contact'}</div>
                </div>
                <button
                  onClick={() => setMobileMenuOpen(false)}
                  className={`w-full py-2 text-xs rounded-lg font-semibold ${currentTheme.accent}`}
                >
                  {cta}
                </button>
              </div>
            )}

            {/* Hero Section */}
            <section className="px-6 sm:px-10 pt-4">
              <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
                <div className="md:col-span-7 space-y-4">
                  <div className="inline-flex items-center gap-2 text-xs font-semibold opacity-70">
                    <span>{isFa ? 'استاندارد بازطراحی اختصاصی' : 'Bespoke Redesign Architecture'}</span>
                    <span>·</span>
                    <span>{isFa ? 'زیر ۱.۲ ثانیه لود' : 'High Performance'}</span>
                  </div>

                  <h1 className="text-xl sm:text-2xl md:text-3xl font-extrabold tracking-tight leading-tight" style={{ textWrap: 'balance' }}>
                    {headline}
                  </h1>

                  <p className="text-xs sm:text-sm opacity-80 leading-relaxed max-w-xl">
                    {isFa
                      ? 'دیگر نیازی به فرم‌های طولانی و منوهای خسته‌کننده نیست. تمامی فرایندها برای راحتی شما و دستیابی به بالاترین نتایج بازطراحی شده‌اند.'
                      : 'Eliminate friction, shorten customer consideration cycles, and establish undeniable industry leadership with verified outcomes.'}
                  </p>

                  <div className="flex flex-wrap items-center gap-3 pt-2">
                    <button
                      onClick={() => {
                        const el = document.getElementById('prototype-contact-form');
                        el?.scrollIntoView({ behavior: 'smooth' });
                      }}
                      className={`px-4 py-2.5 text-xs font-semibold rounded-lg transition-colors shadow-xs ${currentTheme.accent}`}
                    >
                      {cta}
                    </button>
                    <button className={`px-4 py-2.5 text-xs font-medium rounded-lg transition-colors ${currentTheme.secondaryBtn}`}>
                      {isFa ? 'مشاهده کاتالوگ و نمونه‌ها' : 'Explore Portfolio'}
                    </button>
                  </div>
                </div>

                {/* Hero Showcase Image */}
                <div className="md:col-span-5">
                  <div className="rounded-xl overflow-hidden border border-neutral-200/80 dark:border-neutral-800 shadow-xl">
                    <img
                      src="/src/assets/images/site_concept_modern_1794063202120.jpg"
                      alt="Modern Redesigned Concept"
                      className="w-full h-52 sm:h-64 object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                </div>
              </div>
            </section>

            {/* Asymmetric Bento Grid Capabilities */}
            <section id="services" className="px-6 sm:px-10 space-y-4">
              <div>
                <h2 className="text-base sm:text-lg font-bold tracking-tight">
                  {isFa ? 'قابلیت‌ها و خدمات ارتقایافته' : 'Engineered Capabilities'}
                </h2>
                <p className="text-xs opacity-70">
                  {isFa ? 'چیدمان بنتو (Bento Grid) بدون کارت‌های تکراری و خسته‌کننده' : 'Asymmetric layout prioritizing core user workflows'}
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className={`md:col-span-2 p-5 rounded-xl ${currentTheme.cardBg} space-y-3`}>
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs opacity-50 font-bold">01.</span>
                    <span className="text-xs font-semibold opacity-80">{isFa ? 'خدمت Marquee' : 'Marquee Service'}</span>
                  </div>
                  <h3 className="text-sm sm:text-base font-bold">
                    {isFa ? 'سیستم یکپارچه و سریع ارائه خدمات بدون اتلاف وقت' : 'Streamlined Core Workflow Engine'}
                  </h3>
                  <p className="text-xs opacity-75 leading-relaxed">
                    {isFa
                      ? 'مخاطب تنها با ۲ کلیک می‌تواند درخواست خود را ثبت کند، وضعیت را آنلاین پیگیری نماید و از شفافیت کامل قیمت‌ها مطلع شود.'
                      : 'Eliminate friction points with a 2-click interaction model, verifiable tracking, and transparent terms.'}
                  </p>
                  <div className="pt-2 flex items-center gap-4 text-xs font-mono font-semibold">
                    <span>{isFa ? 'سرعت لود: ۱.۱ ثانیه' : 'Speed: 1.1s'}</span>
                    <span>·</span>
                    <span>{isFa ? 'بهینه‌سازی موبایل: ۱۰۰٪' : 'Mobile Score: 100%'}</span>
                  </div>
                </div>

                <div className={`p-5 rounded-xl ${currentTheme.cardBg} space-y-3`}>
                  <div className="font-mono text-xs opacity-50 font-bold">02.</div>
                  <h3 className="text-sm font-bold">
                    {isFa ? 'مشاوره اختصاصی و پشتیبانی' : 'Dedicated Consultation'}
                  </h3>
                  <p className="text-xs opacity-75 leading-relaxed">
                    {isFa
                      ? 'ارتباط مستقیم با کارشناسان ارشد، بدون انتظار پشت خطوط تلفن.'
                      : 'Direct access to senior advisors with real-time slot scheduling.'}
                  </p>
                </div>

                <div className={`p-5 rounded-xl ${currentTheme.cardBg} space-y-3`}>
                  <div className="font-mono text-xs opacity-50 font-bold">03.</div>
                  <h3 className="text-sm font-bold">
                    {isFa ? 'شفافیت کامل در تعرفه‌ها' : 'Clear Transparent Pricing'}
                  </h3>
                  <p className="text-xs opacity-75 leading-relaxed">
                    {isFa ? 'بدون هزینه‌های پنهان، با امکان مقایسه بسته‌ها.' : 'Zero hidden charges with structured milestone guarantees.'}
                  </p>
                </div>

                <div className={`md:col-span-2 p-5 rounded-xl ${currentTheme.cardBg} space-y-3`}>
                  <div className="font-mono text-xs opacity-50 font-bold">04.</div>
                  <h3 className="text-sm font-bold">
                    {isFa ? 'استاندارد امنیتی و دسترسی‌پذیری جهانی' : 'Certified Accessibility & Standards'}
                  </h3>
                  <p className="text-xs opacity-75 leading-relaxed">
                    {isFa
                      ? 'رعایت پروتکل‌های WCAG AA برای افراد کم‌بینا و سازگاری با تمامی مرورگرهای روز دنیا.'
                      : 'Strict WCAG AA contrast compliance and cross-device ergonomic baseline.'}
                  </p>
                </div>
              </div>
            </section>

            {/* Social Proof Strip */}
            <section id="results" className="px-6 sm:px-10">
              <div className={`p-6 rounded-xl ${currentTheme.cardBg} grid grid-cols-1 sm:grid-cols-3 gap-6 text-center`}>
                <div className="space-y-1">
                  <div className="text-2xl font-bold font-mono">+۱۴۰٪</div>
                  <div className="text-xs opacity-70">
                    {isFa ? 'افزایش نرخ ثبت لید و تماس' : 'Qualified Lead Growth'}
                  </div>
                </div>
                <div className="space-y-1">
                  <div className="text-2xl font-bold font-mono">۴۵- روز</div>
                  <div className="text-xs opacity-70">
                    {isFa ? 'بازگشت کامل سرمایه بازطراحی' : 'Average Payback Period'}
                  </div>
                </div>
                <div className="space-y-1">
                  <div className="text-2xl font-bold font-mono">۹۹.۴٪</div>
                  <div className="text-xs opacity-70">
                    {isFa ? 'رضایت ثبت‌شده مراجعان' : 'Client Approval Rating'}
                  </div>
                </div>
              </div>
            </section>

            {/* Interactive Lead Submission Form */}
            <section id="prototype-contact-form" className="px-6 sm:px-10">
              <div className={`p-6 sm:p-8 rounded-2xl ${currentTheme.cardBg} max-w-2xl mx-auto space-y-6 shadow-sm`}>
                <div className="text-center space-y-1.5">
                  <h2 className="text-lg font-bold">
                    {isFa ? 'ثبت نوبت / درخواست مشاوره سریع' : 'Initiate Priority Consultation'}
                  </h2>
                  <p className="text-xs opacity-70">
                    {isFa
                      ? 'اطلاعات خود را وارد کنید، در کمتر از ۱۵ دقیقه با شما تماس خواهیم گرفت.'
                      : 'Provide essential details to schedule your discovery evaluation.'}
                  </p>
                </div>

                {formSubmitted ? (
                  <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-center space-y-2">
                    <CheckCircle className="w-8 h-8 text-emerald-500 mx-auto" />
                    <div className="text-sm font-bold text-emerald-600 dark:text-emerald-400">
                      {isFa ? 'درخواست شما با موفقیت ثبت شد!' : 'Inquiry Successfully Submitted!'}
                    </div>
                    <p className="text-xs opacity-80">
                      {isFa ? 'کارشناس ما به زودی با شماره اعلامی هماهنگ خواهد کرد.' : 'Our team will contact you shortly.'}
                    </p>
                  </div>
                ) : (
                  <form onSubmit={handleFormSubmit} className="space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-medium mb-1">
                          {isFa ? 'نام و نام خانوادگی' : 'Full Name'} *
                        </label>
                        <input
                          type="text"
                          required
                          value={formName}
                          onChange={(e) => setFormName(e.target.value)}
                          placeholder={isFa ? 'مثال: علیرضا راد' : 'John Doe'}
                          className="w-full px-3 py-2 text-xs rounded-lg border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 focus:outline-none focus:ring-1 focus:ring-neutral-500"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-medium mb-1">
                          {isFa ? 'شماره تماس همراه' : 'Phone Number'} *
                        </label>
                        <input
                          type="tel"
                          required
                          value={formPhone}
                          onChange={(e) => setFormPhone(e.target.value)}
                          placeholder={isFa ? '۰۹۱۲۳۴۵۶۷۸۹' : '+1 555 0199'}
                          dir="ltr"
                          className="w-full px-3 py-2 text-xs rounded-lg border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 focus:outline-none focus:ring-1 focus:ring-neutral-500"
                        />
                      </div>
                    </div>

                    <button
                      type="submit"
                      className={`w-full py-2.5 text-xs font-semibold rounded-lg flex items-center justify-center gap-2 transition-colors ${currentTheme.accent}`}
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>{isFa ? 'ارسال درخواست نوبت / مشاوره' : 'Submit Consultation Request'}</span>
                    </button>
                  </form>
                )}
              </div>
            </section>

            {/* Quiet Footer */}
            <footer className="px-6 sm:px-10 pt-6 border-t border-neutral-200/50 dark:border-neutral-800/60 flex flex-col sm:flex-row items-center justify-between gap-3 text-[11px] opacity-60">
              <div>
                © 2026 {clientName}. {isFa ? 'تمامی حقوق محفوظ است.' : 'All rights reserved.'}
              </div>
              <div className="flex gap-4">
                <span>{isFa ? 'حفظ حریم خصوصی' : 'Privacy'}</span>
                <span>{isFa ? 'شرایط استفاده' : 'Terms'}</span>
                <span>{isFa ? 'امنیت' : 'Security'}</span>
              </div>
            </footer>
          </div>
        </div>
      </div>

      {/* Code & Tokens Inspector Side Drawer */}
      {showInspector && (
        <div className="fixed inset-y-0 end-0 z-50 w-full max-w-md bg-white dark:bg-neutral-900 border-s border-neutral-200 dark:border-neutral-800 shadow-2xl p-6 overflow-y-auto space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-neutral-200 dark:border-neutral-800">
            <div className="flex items-center gap-2">
              <Code className="w-4 h-4 text-neutral-500" />
              <h3 className="text-sm font-bold text-neutral-900 dark:text-white">
                {isFa ? 'توکن‌ها و کلاس‌های Tailwind کانسپت' : 'Tailwind Design Tokens'}
              </h3>
            </div>
            <button
              onClick={() => setShowInspector(false)}
              className="p-1 rounded-md text-neutral-400 hover:text-neutral-900 dark:hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="space-y-4 text-xs font-mono">
            <div>
              <span className="text-neutral-500 font-sans block mb-1 font-semibold">
                {isFa ? 'پالت رنگی CSS Theme:' : 'Active Palette:'}
              </span>
              <pre className="p-3 rounded-lg bg-neutral-100 dark:bg-neutral-800 text-[11px] overflow-x-auto">
{`--color-canvas: ${currentTheme.accentColorHex};
--font-display: "Vazirmatn", "Plus Jakarta Sans";
--radius-container: 16px;
--radius-control: 8px;
--border-hairline: 1px solid rgba(0,0,0,0.08);`}
              </pre>
            </div>

            <div>
              <span className="text-neutral-500 font-sans block mb-1 font-semibold">
                {isFa ? 'کلاس‌های هدر سه‌قسمتی:' : 'Top Bar Classes:'}
              </span>
              <pre className="p-3 rounded-lg bg-neutral-100 dark:bg-neutral-800 text-[11px] overflow-x-auto whitespace-pre-wrap">
{`flex items-center justify-between gap-8 px-6 py-4 border-b`}
              </pre>
            </div>

            <div>
              <span className="text-neutral-500 font-sans block mb-1 font-semibold">
                {isFa ? 'کلاس‌های کارت بنتو:' : 'Bento Grid Classes:'}
              </span>
              <pre className="p-3 rounded-lg bg-neutral-100 dark:bg-neutral-800 text-[11px] overflow-x-auto whitespace-pre-wrap">
{`col-span-2 p-5 rounded-xl border border-neutral-200 dark:border-neutral-800 shadow-xs`}
              </pre>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
