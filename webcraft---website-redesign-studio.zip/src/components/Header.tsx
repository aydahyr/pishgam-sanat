import React from 'react';
import { Sparkles, Moon, Sun, Globe, FileText, CheckSquare, Layers, Eye, SlidersHorizontal, Zap } from 'lucide-react';
import { Language } from '../types/redesign';

export type TabType = 'pishgamStore' | 'intake' | 'audit' | 'beforeAfter' | 'prototype' | 'proposal' | 'roadmap';

interface HeaderProps {
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  language: Language;
  setLanguage: (lang: Language) => void;
  isDark: boolean;
  setIsDark: (dark: boolean) => void;
  onNewProject: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  language,
  setLanguage,
  isDark,
  setIsDark,
  onNewProject,
}) => {
  const isFa = language === 'fa';

  const navLinks = [
    { id: 'pishgamStore', label: isFa ? 'فروشگاه جدید پیشگام' : 'Redesigned Store', icon: Zap },
    { id: 'beforeAfter', label: isFa ? 'مقایسه قبل و بعد' : 'Before vs After', icon: Layers },
    { id: 'audit', label: isFa ? 'تحلیل و عارضه‌یابی' : 'Audit & UX', icon: Eye },
    { id: 'proposal', label: isFa ? 'پروپوزال کارفرما' : 'Client Proposal', icon: FileText },
    { id: 'prototype', label: isFa ? 'شخصی‌سازی کانسپت' : 'Customizer', icon: Sparkles },
    { id: 'roadmap', label: isFa ? 'چک‌لیست مراحل' : '5-Step Guide', icon: CheckSquare },
  ] as const;

  return (
    <header className="sticky top-0 z-40 bg-white/90 dark:bg-neutral-900/90 backdrop-blur-md border-b border-neutral-200 dark:border-neutral-800 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Brand Wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="w-9 h-9 rounded-lg bg-blue-600 text-white flex items-center justify-center font-bold text-lg shadow-sm">
            <Zap className="w-5 h-5" />
          </div>
          <button
            onClick={() => setActiveTab('pishgamStore')}
            className="text-lg font-bold tracking-tight text-neutral-900 dark:text-neutral-100 hover:text-neutral-600 dark:hover:text-neutral-300 transition-colors whitespace-nowrap text-start"
          >
            {isFa ? 'پیشگام صنعت · کانسپت بازطراحی' : 'Pishgam Sanat Redesign'}
          </button>
        </div>

        {/* Zone 2: Navigation Links (Single-line, whitespace-nowrap) */}
        <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
          {navLinks.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as TabType)}
                className={`flex items-center gap-1.5 px-3 py-1.5 text-xs xl:text-sm font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                  isActive
                    ? 'bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800/80 font-bold'
                    : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-200 hover:bg-neutral-50 dark:hover:bg-neutral-800/50'
                }`}
              >
                <Icon className="w-3.5 h-3.5 opacity-80" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Single Primary Action & Essential Toggles */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {/* Language Toggle */}
          <button
            onClick={() => setLanguage(isFa ? 'en' : 'fa')}
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-neutral-600 dark:text-neutral-300 hover:text-neutral-900 dark:hover:text-white border border-neutral-200 dark:border-neutral-800 rounded-lg hover:bg-neutral-50 dark:hover:bg-neutral-800 transition-colors whitespace-nowrap"
            title={isFa ? 'Switch to English' : 'تغییر به فارسی'}
          >
            <Globe className="w-3.5 h-3.5" />
            <span className="font-sans">{isFa ? 'EN' : 'فا'}</span>
          </button>

          {/* Theme Toggle */}
          <button
            onClick={() => setIsDark(!isDark)}
            className="p-1.5 text-neutral-600 dark:text-neutral-300 hover:text-neutral-900 dark:hover:text-white border border-neutral-200 dark:border-neutral-800 rounded-lg hover:bg-neutral-50 dark:hover:bg-neutral-800 transition-colors"
            title={isDark ? 'حالت روشن' : 'حالت تیره'}
            aria-label="Toggle theme"
          >
            {isDark ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
          </button>

          {/* Primary Action Button */}
          <button
            onClick={() => setActiveTab('pishgamStore')}
            className="px-3.5 py-1.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors whitespace-nowrap shadow-xs"
          >
            {isFa ? 'مشاهده فروشگاه جدید' : 'View Store'}
          </button>
        </div>
      </div>

      {/* Mobile Horizontal Sub-Navigation */}
      <div className="lg:hidden flex items-center gap-1 px-4 py-2 border-t border-neutral-200 dark:border-neutral-800 overflow-x-auto no-scrollbar">
        {navLinks.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as TabType)}
              className={`flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded-md whitespace-nowrap shrink-0 transition-colors ${
                isActive
                  ? 'bg-blue-600 text-white font-bold'
                  : 'text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800'
              }`}
            >
              <Icon className="w-3 h-3" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>
    </header>
  );
};
