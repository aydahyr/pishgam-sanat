import React, { useState } from 'react';
import { Printer, Copy, Check, Sparkles, Building, Calendar, DollarSign, Layers, CheckCircle2 } from 'lucide-react';
import { RedesignProject, Language } from '../types/redesign';

interface ProposalViewProps {
  project: RedesignProject;
  language: Language;
}

export const ProposalView: React.FC<ProposalViewProps> = ({ project, language }) => {
  const isFa = language === 'fa';
  const [copied, setCopied] = useState(false);
  const [customPrice, setCustomPrice] = useState(project.budgetEstimate || (isFa ? '۳۸,۰۰۰,۰۰۰ تومان' : '$3,200'));
  const [agencyName, setAgencyName] = useState(isFa ? 'استودیو دیزاین و فناوری وب‌کرافت' : 'WebCraft Design Studio');

  const analysis = project.analysis;
  const clientName = project.clientName || (isFa ? 'کارفرمای محترم' : 'Valued Client');
  const dateStr = new Date().toLocaleDateString(isFa ? 'fa-IR' : 'en-US');

  const executiveSummary = analysis?.clientProposalPitch?.executiveSummary || 
    (isFa
      ? `وب‌سایت فعلی ${clientName} دارای پتانسیل تجاری قابل‌توجهی است، اما معماری قدیمی و اصطکاک‌های تجربه کاربری مانع از تبدیل حداکثری مراجعان به مشتریان پایدار می‌شود. این پروپوزال، راهبرد جامع بازطراحی وب‌سایت با رویکرد موبایل-فرست، افزایش نرخ تبدیل و ارتقای جایگاه برند را تشریح می‌کند.`
      : `The current ${clientName} web presence possesses substantial market potential; however, legacy structural friction and mobile degradation limit customer acquisition. This proposal outlines an authoritative redesign strategy engineered to maximize conversion and elevate brand authority.`);

  const roiJustification = analysis?.clientProposalPitch?.roiJustification ||
    (isFa
      ? 'کاهش نرخ پرش (Bounce Rate) تا حداقل ۴۰٪، تسریع بارگذاری صفحات به زیر ۱.۵ ثانیه و افزایش تماس‌ها و رزروهای آنلاین تا ۲.۵ برابر.'
      : 'Projected 40% reduction in bounce rate, sub-1.5s Core Web Vitals, and 2.5x increase in qualified inquiries.');

  const phases = analysis?.clientProposalPitch?.estimatedPhases || [
    {
      phase: isFa ? 'فاز ۱: تحقیقات، کشف و معماری اطلاعات (IA)' : 'Phase 1: Discovery & Wireframing',
      duration: isFa ? '۷ روز کاری' : '7 business days',
      deliverables: isFa
        ? ['تحلیل رقبا و عارضه‌یابی دقیق', 'نقشه سایت (Sitemap) جدید', 'وایرفریم‌های ساختاری صفحات']
        : ['Competitive analysis', 'Revised sitemap', 'Low-fidelity structural wireframes'],
    },
    {
      phase: isFa ? 'فاز ۲: طراحی UI و سیستم طراحی در فیگما' : 'Phase 2: High-Fi UI & Design System',
      duration: isFa ? '۱۰ روز کاری' : '10 business days',
      deliverables: isFa
        ? ['طراحی کامل نسخه‌های دسکتاپ و موبایل', 'دیزاین سیستم و رنگ‌های استاندارد', 'پروتوتایپ تعاملی جهت تست']
        : ['Full desktop & mobile artboards', 'Component design tokens', 'Interactive clickable prototype'],
    },
    {
      phase: isFa ? 'فاز ۳: توسعه فرانت‌اند و بهینه‌سازی سرعت' : 'Phase 3: Production Development & Speed',
      duration: isFa ? '۱۴ روز کاری' : '14 business days',
      deliverables: isFa
        ? ['کدنویسی تمیز و بهینه‌شده', 'سازگاری ۱۰۰٪ با تمامی نمایشگرها', 'بهینه‌سازی Core Web Vitals']
        : ['Clean production code', 'Responsive QA matrix', 'Sub-1.5s performance hardening'],
    },
    {
      phase: isFa ? 'فاز ۴: تست نهایی، مهاجرت سئو و لانچ' : 'Phase 4: Launch & Quality Assurance',
      duration: isFa ? '۵ روز کاری' : '5 business days',
      deliverables: isFa
        ? ['تست فرم‌ها و درگاه‌ها', 'انتقال امن ریدایرکت‌های سئو', 'آموزش به تیم و استقرار نهایی']
        : ['Comprehensive QA check', 'SEO redirect migration', 'Team handoff & production release'],
    },
  ];

  const handlePrint = () => {
    window.print();
  };

  const handleCopyText = () => {
    const textContent = `
========================================
${isFa ? 'پروپوزال رسمی بازطراحی وب‌سایت' : 'OFFICIAL WEBSITE REDESIGN PROPOSAL'}
========================================
${isFa ? 'کارفرما:' : 'Client:'} ${clientName}
${isFa ? 'مجری پروژه:' : 'Prepared by:'} ${agencyName}
${isFa ? 'تاریخ:' : 'Date:'} ${dateStr}

1. ${isFa ? 'خلاصه مدیریتی' : 'Executive Summary'}
${executiveSummary}

2. ${isFa ? 'توجیه ارزش تجاری و بازگشت سرمایه (ROI)' : 'Business Value & ROI'}
${roiJustification}

3. ${isFa ? 'فازبندی و زمان‌بندی پروژه' : 'Project Phases & Deliverables'}
${phases
  .map(
    (p, i) =>
      `\n[${i + 1}] ${p.phase} (${p.duration})\n` +
      p.deliverables.map((d) => `  - ${d}`).join('\n')
  )
  .join('\n')}

4. ${isFa ? 'برآورد سرمایه‌گذاری و شرایط پرداخت' : 'Investment & Payment Terms'}
${isFa ? 'مبلغ کل برآوردی:' : 'Total Investment:'} ${customPrice}
${isFa ? 'شرایط پرداخت: ۴۰٪ پیش‌پرداخت هنگام عقد قرارداد، ۳۰٪ پس از تایید طرح در فیگما، ۳۰٪ هنگام استقرار نهایی و تست.' : 'Terms: 40% kickoff deposit, 30% upon Figma approval, 30% on live handoff.'}
`;

    navigator.clipboard.writeText(textContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 sm:px-6 lg:px-8 space-y-6">
      {/* Action Toolbar (Hidden during print) */}
      <div className="print:hidden bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl p-4 sm:p-5 flex flex-wrap items-center justify-between gap-4 shadow-xs">
        <div>
          <div className="text-xs font-semibold text-neutral-500 mb-0.5">
            {isFa ? 'آماده برای جلسه با کارفرما' : 'Client-Ready Deliverable'}
          </div>
          <h2 className="text-base font-bold text-neutral-900 dark:text-white">
            {isFa ? 'پروپوزال رسمی بازطراحی و توجیه تجاری' : 'Executive Redesign Pitch & Proposal'}
          </h2>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleCopyText}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium border border-neutral-200 dark:border-neutral-700 rounded-lg hover:bg-neutral-50 dark:hover:bg-neutral-800 text-neutral-700 dark:text-neutral-200 transition-colors whitespace-nowrap"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? (isFa ? 'کپی شد!' : 'Copied!') : (isFa ? 'کپی متن پروپوزال' : 'Copy Text')}</span>
          </button>

          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold bg-neutral-900 hover:bg-neutral-800 text-white dark:bg-white dark:text-neutral-900 dark:hover:bg-neutral-100 rounded-lg transition-colors whitespace-nowrap shadow-xs"
          >
            <Printer className="w-4 h-4" />
            <span>{isFa ? 'چاپ و خروجی PDF' : 'Print / Export PDF'}</span>
          </button>
        </div>
      </div>

      {/* Official Proposal Document (Clean Editorial Layout for Screen & Print) */}
      <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl p-8 sm:p-12 space-y-10 shadow-sm print:border-none print:shadow-none print:p-0">
        {/* Document Header */}
        <div className="border-b border-neutral-200 dark:border-neutral-800 pb-8 flex flex-col sm:flex-row justify-between items-start gap-6">
          <div className="space-y-2">
            <span className="text-xs font-mono font-bold uppercase tracking-wider text-neutral-400">
              {isFa ? 'سند پیشنهادی همکاری' : 'STRATEGIC DESIGN PROPOSAL'}
            </span>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 dark:text-white">
              {isFa ? `پروپوزال بازطراحی و ارتقای وب‌سایت ${clientName}` : `Website Redesign Proposal for ${clientName}`}
            </h1>
            <div className="flex items-center gap-4 text-xs text-neutral-500 dark:text-neutral-400">
              <span className="flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5" />
                {dateStr}
              </span>
              <span>·</span>
              <span>Ref: PRJ-{Date.now().toString().slice(-6)}</span>
            </div>
          </div>

          <div className="text-end space-y-1 print:text-start">
            <span className="text-xs text-neutral-400 block">{isFa ? 'ارائه‌دهنده:' : 'Prepared by:'}</span>
            <input
              type="text"
              value={agencyName}
              onChange={(e) => setAgencyName(e.target.value)}
              className="text-sm font-bold text-neutral-900 dark:text-white bg-transparent border-b border-dashed border-neutral-300 dark:border-neutral-700 focus:outline-none text-end print:text-start"
            />
          </div>
        </div>

        {/* Section 1: Executive Summary */}
        <section className="space-y-3">
          <h3 className="text-sm font-bold tracking-tight uppercase text-neutral-900 dark:text-white flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-neutral-900 dark:bg-white" />
            <span>01. {isFa ? 'خلاصه مدیریتی و ضرورت بازطراحی' : 'Executive Summary & Context'}</span>
          </h3>
          <p className="text-xs sm:text-sm text-neutral-700 dark:text-neutral-300 leading-relaxed text-justify">
            {executiveSummary}
          </p>
        </section>

        {/* Section 2: Business Justification & ROI */}
        <section className="space-y-3">
          <h3 className="text-sm font-bold tracking-tight uppercase text-neutral-900 dark:text-white flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-neutral-900 dark:bg-white" />
            <span>02. {isFa ? 'توجیه ارزش تجاری و بازگشت سرمایه (ROI)' : 'Business Value & Expected ROI'}</span>
          </h3>
          <div className="p-4 rounded-xl bg-neutral-50 dark:bg-neutral-800/40 border border-neutral-200 dark:border-neutral-800 text-xs sm:text-sm text-neutral-700 dark:text-neutral-300 leading-relaxed">
            {roiJustification}
          </div>
        </section>

        {/* Section 3: Phased Timeline & Deliverables */}
        <section className="space-y-4">
          <h3 className="text-sm font-bold tracking-tight uppercase text-neutral-900 dark:text-white flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-neutral-900 dark:bg-white" />
            <span>03. {isFa ? 'مراحل اجرایی و خروجی‌های تحویلی' : 'Project Phases & Deliverables'}</span>
          </h3>

          <div className="space-y-3">
            {phases.map((ph, idx) => (
              <div
                key={idx}
                className="p-4 rounded-xl border border-neutral-200 dark:border-neutral-800 flex flex-col sm:flex-row justify-between gap-4"
              >
                <div className="space-y-1.5">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-neutral-900 dark:text-white font-mono">
                      0{idx + 1}.
                    </span>
                    <h4 className="text-xs sm:text-sm font-bold text-neutral-900 dark:text-white">
                      {ph.phase}
                    </h4>
                  </div>
                  <ul className="text-xs text-neutral-600 dark:text-neutral-400 space-y-1 ps-5 list-disc">
                    {ph.deliverables.map((del, dIdx) => (
                      <li key={dIdx}>{del}</li>
                    ))}
                  </ul>
                </div>

                <div className="shrink-0 text-end sm:self-center">
                  <span className="text-xs font-medium text-neutral-500 bg-neutral-100 dark:bg-neutral-800 px-3 py-1 rounded-md">
                    {ph.duration}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Section 4: Commercial Terms & Pricing */}
        <section className="space-y-4 pt-4 border-t border-neutral-200 dark:border-neutral-800">
          <h3 className="text-sm font-bold tracking-tight uppercase text-neutral-900 dark:text-white flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-neutral-900 dark:bg-white" />
            <span>04. {isFa ? 'سرمایه‌گذاری برآوردی و شرایط پرداخت' : 'Investment & Commercial Terms'}</span>
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-neutral-50 dark:bg-neutral-800/40 border border-neutral-200 dark:border-neutral-800 space-y-2">
              <span className="text-xs text-neutral-500 block">
                {isFa ? 'مبلغ کل سرمایه‌گذاری بازطراحی:' : 'Total Investment:'}
              </span>
              <div className="flex items-center gap-2">
                <DollarSign className="w-4 h-4 text-neutral-500" />
                <input
                  type="text"
                  value={customPrice}
                  onChange={(e) => setCustomPrice(e.target.value)}
                  className="text-lg font-bold font-mono text-neutral-900 dark:text-white bg-transparent border-b border-neutral-300 dark:border-neutral-700 focus:outline-none w-full"
                />
              </div>
              <p className="text-[11px] text-neutral-500">
                {isFa ? 'شامل تمامی مراحل طراحی، پروتوتایپ، توسعه و استقرار.' : 'Inclusive of all design, prototype and QA deliverables.'}
              </p>
            </div>

            <div className="p-4 rounded-xl bg-neutral-50 dark:bg-neutral-800/40 border border-neutral-200 dark:border-neutral-800 space-y-2 text-xs">
              <span className="text-xs text-neutral-500 block font-semibold">
                {isFa ? 'مراحل پرداخت توافقی:' : 'Standard Milestone Payments:'}
              </span>
              <div className="space-y-1 text-neutral-700 dark:text-neutral-300">
                <div className="flex items-center justify-between">
                  <span>{isFa ? 'پیش‌پرداخت شروع پروژه:' : 'Kickoff Deposit:'}</span>
                  <span className="font-mono font-bold">۴۰٪</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>{isFa ? 'پس از تایید طرح در فیگما:' : 'Upon High-Fi Approval:'}</span>
                  <span className="font-mono font-bold">۳۰٪</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>{isFa ? 'هنگام تحویل و استقرار نهایی:' : 'Live Handoff:'}</span>
                  <span className="font-mono font-bold">۳۰٪</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Section 5: Signatures block */}
        <section className="pt-8 border-t border-neutral-200 dark:border-neutral-800 grid grid-cols-2 gap-8 text-xs text-neutral-500">
          <div className="space-y-6">
            <div>{isFa ? 'امضا و مهر کارفرما:' : 'Client Representative Sign-off:'}</div>
            <div className="h-14 border-b border-neutral-300 dark:border-neutral-700" />
            <div>{clientName}</div>
          </div>

          <div className="space-y-6">
            <div>{isFa ? 'امضا و مهر مجری پروژه:' : 'Design Studio Sign-off:'}</div>
            <div className="h-14 border-b border-neutral-300 dark:border-neutral-700" />
            <div>{agencyName}</div>
          </div>
        </section>
      </div>
    </div>
  );
};
