import React, { useState } from 'react';
import { 
  X, LayoutDashboard, Package, ShoppingCart, Settings, Award, Tag, Check, 
  Plus, Trash2, Edit3, Phone, MapPin, Printer, ShieldCheck, Eye, Search, 
  AlertTriangle, Truck, CreditCard, RefreshCw, Sparkles, FileText, CheckCircle2,
  Calendar, Clock, DollarSign, ArrowUpRight, Image as ImageIcon, Camera, Upload, Link as LinkIcon,
  MessageSquare, Send, Share2, Smartphone, ExternalLink, Copy, Flame, Timer, Sliders, Zap, ChevronLeft, ChevronRight, Layers
} from 'lucide-react';
import { ProductItem, AgencyItem, ThemePalette } from './PishgamStore';

export const PRODUCT_IMAGE_PRESETS = [
  {
    name: 'مولتی‌متر دیجیتال True RMS',
    url: '/src/assets/images/multimeter_digital_unit_1794071576297.jpg',
    category: 'مولتی‌متر'
  },
  {
    name: 'کلمپ‌آمپرمتر صنعتی جریان بالا',
    url: '/src/assets/images/clamp_meter_multimeter_1794071608967.jpg',
    category: 'کلمپ‌متر'
  },
  {
    name: 'میگر و تستر عایق ولتاژ قوی',
    url: '/src/assets/images/megger_insulation_tester_1794071592640.jpg',
    category: 'میگر'
  },
  {
    name: 'پرس کابلشو هیدرولیک صنعتی',
    url: '/src/assets/images/hydraulic_crimper_tool_1794071644814.jpg',
    category: 'هیدرولیک'
  },
  {
    name: 'دوربین ترموویژن مادون قرمز',
    url: '/src/assets/images/thermal_camera_infrared_1794071625759.jpg',
    category: 'ترموویژن'
  },
  {
    name: 'تجهیزات آزمایشگاه کالیبراسیون',
    url: '/src/assets/images/industrial_instruments_hero_1794067115735.jpg',
    category: 'کالیبراتور'
  },
  {
    name: 'انبار مرکزی و بسته‌بندی اهواز',
    url: '/src/assets/images/industrial_warehouse_hero_1794067115867.jpg',
    category: 'انبار'
  },
  {
    name: 'استودیو بازبینی فنی ابزاردقیق',
    url: '/src/assets/images/hero_redesign_studio_1794063201885.jpg',
    category: 'کنترل کیفیت'
  },
  {
    name: 'پاورآنالایزر و مانیتورینگ توان',
    url: '/src/assets/images/site_concept_analytics_1794063203219.jpg',
    category: 'مانیتورینگ'
  },
  {
    name: 'پایلوت صنعتی اتوماسیون برق',
    url: '/src/assets/images/site_concept_modern_1794063202120.jpg',
    category: 'اتوماسیون'
  },
];

export interface BannerSlide {
  id: string;
  badge: string;
  title: string;
  description: string;
  buttonText: string;
  buttonLink: string;
  secondaryButtonText?: string;
  secondaryButtonLink?: string;
  image: string;
  active: boolean;
  type: 'main' | 'new_products' | 'brands' | 'custom';
  accentColor?: string;
  tagline?: string;
}

export interface SpecialOfferItem {
  productId: string;
  discountPercent: number;
  stockLeft: number;
  customBadge?: string;
}

export interface SpecialOffersConfig {
  enabled: boolean;
  title: string;
  subtitle: string;
  durationHours: number;
  targetEndTime: number; // timestamp in ms
  items: SpecialOfferItem[];
}

export interface AdminOrder {
  id: string;
  trackingCode: string;
  customerName: string;
  customerPhone: string;
  city: string;
  address: string;
  shippingMethod: 'express_ahvaz' | 'tipax' | 'freight';
  paymentMethod: 'online' | 'snapp_pay' | 'installment_in_person' | 'torob_pay' | 'bank_transfer';
  totalAmount: number;
  items: { product: ProductItem; quantity: number }[];
  status: 'pending' | 'processing' | 'shipped' | 'delivered';
  createdAt: string;
  postalBarcode?: string; // بارکد ۲۴ رقمی اداره پست یا کد رهگیری تیپاکس
  smsStatus?: 'delivered' | 'sent' | 'failed' | 'pending';
  smsSentAt?: string;
}

interface AdminPanelModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: ProductItem[];
  onUpdateProduct: (product: ProductItem) => void;
  onAddProduct: (product: ProductItem) => void;
  onDeleteProduct: (productId: string) => void;
  orders: AdminOrder[];
  onUpdateOrderStatus: (orderId: string, status: AdminOrder['status']) => void;
  onUpdateOrderDetails?: (orderId: string, updates: Partial<AdminOrder>) => void;
  tickerText: string;
  onUpdateTickerText: (newText: string) => void;
  agencies: AgencyItem[];
  onUpdateAgencies: (newAgencies: AgencyItem[]) => void;
  discountCode: string;
  onUpdateDiscountCode: (newCode: string) => void;
  activeTheme: ThemePalette;
  onSelectTheme: (theme: ThemePalette) => void;
  storePhone: string;
  onUpdateStorePhone: (phone: string) => void;
  storeMobile: string;
  onUpdateStoreMobile: (mobile: string) => void;
  storeAddress: string;
  onUpdateStoreAddress: (address: string) => void;
  onPreviewExitIntent: () => void;
  installmentTermsText?: string;
  onUpdateInstallmentTermsText?: (text: string) => void;
  // Dynamic Banners
  bannerSlides: BannerSlide[];
  onUpdateBannerSlides: (slides: BannerSlide[]) => void;
  bannerInterval: number;
  onUpdateBannerInterval: (interval: number) => void;
  // Special / Flash Offers
  specialOffers: SpecialOffersConfig;
  onUpdateSpecialOffers: (config: SpecialOffersConfig) => void;
  onResetSpecialOffersTimer: (hours?: number) => void;
}

type AdminTab = 'dashboard' | 'orders' | 'products' | 'banners' | 'specialOffers' | 'installment' | 'ticker' | 'agencies' | 'retention' | 'settings';

export const AdminPanelModal: React.FC<AdminPanelModalProps> = ({
  isOpen,
  onClose,
  products,
  onUpdateProduct,
  onAddProduct,
  onDeleteProduct,
  orders,
  onUpdateOrderStatus,
  onUpdateOrderDetails,
  tickerText,
  onUpdateTickerText,
  agencies,
  onUpdateAgencies,
  discountCode,
  onUpdateDiscountCode,
  activeTheme,
  onSelectTheme,
  storePhone,
  onUpdateStorePhone,
  storeMobile,
  onUpdateStoreMobile,
  storeAddress,
  onUpdateStoreAddress,
  onPreviewExitIntent,
  installmentTermsText,
  onUpdateInstallmentTermsText,
  bannerSlides,
  onUpdateBannerSlides,
  bannerInterval,
  onUpdateBannerInterval,
  specialOffers,
  onUpdateSpecialOffers,
  onResetSpecialOffersTimer,
}) => {
  const [activeTab, setActiveTab] = useState<AdminTab>('dashboard');
  const [orderFilter, setOrderFilter] = useState<'all' | AdminOrder['status']>('all');
  const [selectedOrderDetails, setSelectedOrderDetails] = useState<AdminOrder | null>(null);
  const [editingPostalBarcode, setEditingPostalBarcode] = useState('');
  const [smsActionFeedback, setSmsActionFeedback] = useState<string | null>(null);

  const handleSelectOrder = (ord: AdminOrder) => {
    setSelectedOrderDetails(ord);
    setEditingPostalBarcode(ord.postalBarcode || '');
    setSmsActionFeedback(null);
  };

  // Local state for ticker editing
  const [localTicker, setLocalTicker] = useState(tickerText);

  // Local state for discount code
  const [localDiscount, setLocalDiscount] = useState(discountCode);

  // Local state for contacts
  const [localPhone, setLocalPhone] = useState(storePhone);
  const [localMobile, setLocalMobile] = useState(storeMobile);
  const [localAddress, setLocalAddress] = useState(storeAddress);

  // Local state for installment terms editing (شرایط خرید اقساطی با چک صیادی و ضمانت)
  const defaultTermsFallback = `شرایط و مدارک لازم جهت خرید اقساطی با چک صیادی (پیشگام صنعت اهواز):

۱. ویژه سازمان‌ها، پیمانکاران محترم، شرکت‌های صنعتی، کارگاه‌ها و اصناف خوزستان و سراسر کشور.
۲. نیازمند ارائه چک صیادی معتبر (بنفش رنگ) ثبت‌شده در سامانه یکپارچه صیاد بانک مرکزی به نام شخص یا شرکت خریدار.
۳. هماهنگی نهایی، اعتبارسنجی حساب بانکی و تحویل اصل چک‌ها در محل دفتر مرکزی و انبار اهواز (طالقانی، خیابان نظامی) انجام می‌پذیرد.
۴. ارائه مدارک شناسایی معتبر، احراز هویت شغلی (پروانه کسب معتبر یا معرفی‌نامه رسمی شرکت با سربرگ و مهر) الزامی است.
۵. پس از ثبت این درخواست در سایت، کارشناس واحد فروش اعتباری جهت تعیین وقت جلسه حضوری و تکمیل پرونده ظرف ۱ ساعت کاری با شما تماس خواهد گرفت.`;

  const [localInstallmentTerms, setLocalInstallmentTerms] = useState(installmentTermsText || defaultTermsFallback);
  const [installmentSavedSuccess, setInstallmentSavedSuccess] = useState(false);

  const handleSaveInstallmentTerms = () => {
    if (onUpdateInstallmentTermsText) {
      onUpdateInstallmentTermsText(localInstallmentTerms);
    }
    setInstallmentSavedSuccess(true);
    setTimeout(() => setInstallmentSavedSuccess(false), 3000);
  };

  React.useEffect(() => {
    if (installmentTermsText) {
      setLocalInstallmentTerms(installmentTermsText);
    }
  }, [installmentTermsText]);

  // Banner Slider Management State (مدیریت اسلایدر بنرهای متغیر)
  const [editingSlide, setEditingSlide] = useState<BannerSlide | null>(null);
  const [showAddBannerModal, setShowAddBannerModal] = useState(false);
  const [newBannerTitle, setNewBannerTitle] = useState('');
  const [newBannerBadge, setNewBannerBadge] = useState('ورود جدید به انبار');
  const [newBannerDescription, setNewBannerDescription] = useState('');
  const [newBannerBtnText, setNewBannerBtnText] = useState('مشاهده و ثبت سفارش');
  const [newBannerBtnLink, setNewBannerBtnLink] = useState('#catalog');
  const [newBannerImage, setNewBannerImage] = useState('/src/assets/images/industrial_instruments_hero_1794067115735.jpg');
  const [bannerToast, setBannerToast] = useState<string | null>(null);

  // Dedicated Banner Photo Gallery Picker State (انتخاب مستقیم عکس بنر از آلبوم)
  const [photoPickerSlideId, setPhotoPickerSlideId] = useState<string | null>(null);
  const [photoGalleryCategory, setPhotoGalleryCategory] = useState<string>('all');
  const [customPhotoInput, setCustomPhotoInput] = useState<string>('');

  // Agency Modal State (مدیریت و افزودن نمایندگی جدید)
  const [showAddAgencyModal, setShowAddAgencyModal] = useState(false);
  const [newAgencyName, setNewAgencyName] = useState('');
  const [newAgencyCountry, setNewAgencyCountry] = useState('ژاپن (Tokyo, Japan)');
  const [newAgencyRole, setNewAgencyRole] = useState('عاملیت مجاز توزیع مستقیم و کالیبراسیون در خوزستان');
  const [newAgencyBadge, setNewAgencyBadge] = useState('سرتیفیکیت معتبر');
  const [newAgencySpecialties, setNewAgencySpecialties] = useState('مولتی‌متر True RMS، کلمپ جریان، تستر عایق');
  const [newAgencyDescription, setNewAgencyDescription] = useState('تامین مستقیم تجهیزات اصل با گارانتی طلایی و سرتیفیکیت رسمی');
  const [agencyToast, setAgencyToast] = useState<string | null>(null);

  // Manager Email & SMTP Notification Settings (تنظیمات ارسال ایمیل فاکتور به مدیر)
  const [managerEmailInput, setManagerEmailInput] = useState(() => localStorage.getItem('pishgam_manager_email') || 'info@pishgams.com');
  const [smtpHostInput, setSmtpHostInput] = useState(() => {
    try {
      const s = localStorage.getItem('pishgam_smtp_config');
      return s ? JSON.parse(s).host : 'mail.pishgams.com';
    } catch {
      return 'mail.pishgams.com';
    }
  });
  const [smtpPortInput, setSmtpPortInput] = useState(() => {
    try {
      const s = localStorage.getItem('pishgam_smtp_config');
      return s ? JSON.parse(s).port : '465';
    } catch {
      return '465';
    }
  });
  const [smtpUserInput, setSmtpUserInput] = useState(() => {
    try {
      const s = localStorage.getItem('pishgam_smtp_config');
      return s ? JSON.parse(s).user : '';
    } catch {
      return '';
    }
  });
  const [smtpPassInput, setSmtpPassInput] = useState(() => {
    try {
      const s = localStorage.getItem('pishgam_smtp_config');
      return s ? JSON.parse(s).pass : '';
    } catch {
      return '';
    }
  });
  const [emailTestingStatus, setEmailTestingStatus] = useState<string | null>(null);

  // Special 24H Offers Management State (مدیریت پیشنهادات شگفت‌انگیز ۲۴ ساعته)
  const [specialOfferProductSelect, setSpecialOfferProductSelect] = useState<string>('');
  const [specialOfferDiscountInput, setSpecialOfferDiscountInput] = useState<number>(15);
  const [specialOfferStockInput, setSpecialOfferStockInput] = useState<number>(3);
  const [specialOfferToast, setSpecialOfferToast] = useState<string | null>(null);

  // New Product Modal state
  const [showAddProductModal, setShowAddProductModal] = useState(false);
  const [newProdName, setNewProdName] = useState('');
  const [newProdModel, setNewProdModel] = useState('');
  const [newProdBrand, setNewProdBrand] = useState<'Fluke' | 'Kyoritsu' | 'Mastech' | 'Pishgam' | 'UNI-T'>('UNI-T');
  const [newProdCategory, setNewProdCategory] = useState<'multimeter' | 'megger' | 'thermal' | 'hydraulic' | 'calibrator'>('multimeter');
  const [newProdPrice, setNewProdPrice] = useState(5500000);
  const [newProdAccuracy, setNewProdAccuracy] = useState('±(0.05%+2)');
  const [newProdVoltage, setNewProdVoltage] = useState('1000V AC/DC');
  const [newProdFeature, setNewProdFeature] = useState('نمایشگر با نور پس‌زمینه و گواهی کالیبراسیون');
  const [newProdImage, setNewProdImage] = useState('/src/assets/images/multimeter_digital_unit_1794071576297.jpg');

  // Quick Price Edit state
  const [editingPriceId, setEditingPriceId] = useState<string | null>(null);
  const [tempPrice, setTempPrice] = useState<number>(0);

  // Dedicated Product Image Editing state (قابلیت تنظیم و تغییر عکس محصول)
  const [editingImageProduct, setEditingImageProduct] = useState<ProductItem | null>(null);
  const [selectedImageUrl, setSelectedImageUrl] = useState<string>('');
  const [customImageUrlInput, setCustomImageUrlInput] = useState<string>('');

  const handleImageFileUpload = (e: React.ChangeEvent<HTMLInputElement>, forNewProduct = false) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 8 * 1024 * 1024) {
        alert('حجم عکس حداکثر می‌تواند ۸ مگابایت باشد.');
        return;
      }
      const reader = new FileReader();
      reader.onload = () => {
        const base64 = reader.result as string;
        if (forNewProduct) {
          setNewProdImage(base64);
        } else {
          setSelectedImageUrl(base64);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveProductImage = () => {
    if (editingImageProduct && selectedImageUrl) {
      onUpdateProduct({ ...editingImageProduct, image: selectedImageUrl });
      setEditingImageProduct(null);
    }
  };

  if (!isOpen) return null;

  const filteredOrders = orders.filter((o) => {
    if (orderFilter === 'all') return true;
    return o.status === orderFilter;
  });

  const totalSalesVolume = orders.reduce((sum, o) => sum + o.totalAmount, 0);
  const snappPayCount = orders.filter((o) => o.paymentMethod === 'snapp_pay').length;
  const installmentInPersonCount = orders.filter((o) => o.paymentMethod === 'installment_in_person').length;
  const onlinePayCount = orders.filter((o) => o.paymentMethod === 'online' || o.paymentMethod === 'bank_transfer').length;

  const handleSaveTicker = () => {
    onUpdateTickerText(localTicker);
    alert('متن نوار متحرک بالای سایت با موفقیت به‌روزرسانی شد.');
  };

  const handleSaveDiscount = () => {
    onUpdateDiscountCode(localDiscount);
    alert('کد تخفیف خروج مشتری با موفقیت به‌روزرسانی شد.');
  };

  const handleSaveStoreSettings = () => {
    onUpdateStorePhone(localPhone);
    onUpdateStoreMobile(localMobile);
    onUpdateStoreAddress(localAddress);
    alert('تنظیمات انبار مرکزی اهواز و اطلاعات تماس ذخیره شدند.');
  };

  const handleSaveNewProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProdName || !newProdModel) {
      alert('لطفاً نام و مدل دستگاه را وارد کنید.');
      return;
    }
    const newProduct: ProductItem = {
      id: `prod-${Date.now()}`,
      name: newProdName,
      model: newProdModel,
      brand: newProdBrand,
      category: newProdCategory,
      categoryLabelFa: 
        newProdCategory === 'multimeter' ? 'مولتی‌متر و کلمپ' :
        newProdCategory === 'megger' ? 'میگر و عایق‌سنج' :
        newProdCategory === 'thermal' ? 'ترموویژن و حرارت‌سنج' :
        newProdCategory === 'hydraulic' ? 'ابزار کابل و هیدرولیک' : 'کالیبراتور ابزار دقیق',
      price: Number(newProdPrice),
      inStock: true,
      specs: {
        voltageRange: newProdVoltage,
        accuracy: newProdAccuracy,
        safetyRating: 'CAT III 1000V',
        feature: newProdFeature,
      },
      datasheetUrl: '#datasheet',
      image: newProdImage,
    };
    onAddProduct(newProduct);
    setShowAddProductModal(false);
    // Reset
    setNewProdName('');
    setNewProdModel('');
  };

  const handleStartEditPrice = (prod: ProductItem) => {
    setEditingPriceId(prod.id);
    setTempPrice(prod.price);
  };

  const handleCommitEditPrice = (prod: ProductItem) => {
    onUpdateProduct({ ...prod, price: tempPrice });
    setEditingPriceId(null);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 animate-in fade-in duration-200">
      <div className="bg-[#101014] border border-slate-800 rounded-3xl w-full max-w-6xl h-[92vh] flex flex-col shadow-[0_0_60px_rgba(0,0,0,0.8)] overflow-hidden text-slate-100 font-sans">
        
        {/* =========================================================================
            ADMIN TOP BAR
           ========================================================================= */}
        {/* =========================================================================
            ADMIN TOP BAR (COMPACT & MODERN)
           ========================================================================= */}
        <div className="px-3.5 py-2.5 sm:py-3 border-b border-slate-800/90 bg-[#14141a] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-rose-600/20 border border-rose-500/40 flex items-center justify-center text-rose-500 shadow-inner shrink-0">
              <LayoutDashboard className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm sm:text-base font-black text-white">
                  پنل مدیریت مرکزی پیشگام صنعت اهواز
                </h2>
                <span className="text-[10px] px-2 py-0.2 rounded-full bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 font-bold flex items-center gap-1 font-num">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  سرور انبار فعال
                </span>
              </div>
              <p className="text-[10px] sm:text-[11px] text-slate-400 hidden sm:block">
                مدیریت محصولات، سفارشات اسنپ‌پی و اقساط، بنرها، نمایندگی‌ها و کدهای تخفیف
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={onPreviewExitIntent}
              className="px-2.5 py-1.5 rounded-xl border border-rose-800/70 bg-rose-950/60 hover:bg-rose-900/80 text-rose-300 text-[11px] font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
              title="تست و بازکردن پاپ‌آپ هشدار خروج"
            >
              <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden sm:inline">تست هشدار خروج</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-xl bg-slate-800/80 text-slate-400 hover:text-white hover:bg-slate-700 transition-colors cursor-pointer"
              title="بستن پنل مدیریت"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* =========================================================================
            ADMIN NAVIGATION TABS (COMPACT, SLEEK & 100% ACCESSIBLE)
           ========================================================================= */}
        <div className="border-b border-slate-800 bg-[#0c0d12] p-1.5 sm:p-2 flex flex-wrap items-center gap-1 sm:gap-1.5 shrink-0">
          {[
            { id: 'dashboard', label: 'داشبورد', icon: LayoutDashboard },
            { 
              id: 'orders', 
              label: 'سفارشات', 
              icon: ShoppingCart, 
              badge: orders.length > 0 ? orders.length : undefined 
            },
            { id: 'products', label: 'محصولات و انبار', icon: Package },
            { id: 'banners', label: 'بنرها و اسلایدر', icon: ImageIcon, badge: bannerSlides?.length },
            { id: 'specialOffers', label: 'تایمر شگفت‌انگیز', icon: Flame, badge: specialOffers?.items?.length },
            { id: 'installment', label: 'شرایط اقساط', icon: FileText },
            { id: 'ticker', label: 'نوار اعلان', icon: Edit3 },
            { id: 'agencies', label: 'نمایندگی‌ها و برندها', icon: Award, badge: agencies?.length },
            { id: 'retention', label: 'پاپ‌آپ خروج', icon: Tag },
            { id: 'settings', label: 'تنظیمات انبار', icon: Settings },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as AdminTab)}
                className={`py-1.5 px-2.5 sm:px-3 text-[11px] sm:text-xs font-bold rounded-xl transition-all flex items-center gap-1.5 cursor-pointer ${
                  isActive
                    ? 'bg-rose-600 text-white shadow-md shadow-rose-950/60 ring-1 ring-rose-400'
                    : 'bg-slate-900/85 hover:bg-slate-800 text-slate-300 border border-slate-800/80 hover:text-white'
                }`}
                title={tab.label}
              >
                <Icon className="w-3.5 h-3.5 shrink-0" />
                <span>{tab.label}</span>
                {tab.badge !== undefined && (
                  <span className={`px-1.5 py-0.2 rounded-full font-num text-[10px] font-black ${
                    isActive ? 'bg-white text-rose-700' : 'bg-rose-600 text-white'
                  }`}>
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* =========================================================================
            ADMIN CONTENT AREA
           ========================================================================= */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-[#0a0a0c]">
          
          {/* TAB 1: DASHBOARD & ANALYTICS */}
          {activeTab === 'dashboard' && (
            <div className="space-y-6">
              {/* Stat Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="p-4 rounded-2xl bg-[#14141a] border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between text-xs text-slate-400">
                    <span>فروش کل سفارشات</span>
                    <DollarSign className="w-4 h-4 text-emerald-400" />
                  </div>
                  <div className="text-xl font-black text-white font-num">
                    {totalSalesVolume.toLocaleString('en-US')} تومان
                  </div>
                  <div className="text-[11px] text-emerald-400 font-bold flex items-center gap-1">
                    <ArrowUpRight className="w-3.5 h-3.5" />
                    <span>+24٪ رشد سفارشات ماه جاری</span>
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-[#14141a] border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between text-xs text-slate-400">
                    <span>کل سفارشات فعال</span>
                    <ShoppingCart className="w-4 h-4 text-sky-400" />
                  </div>
                  <div className="text-xl font-black text-white font-num">
                    {orders.length} سفارش
                  </div>
                  <div className="text-[11px] text-slate-400">
                    تحویل سریع با پیک در اهواز و تیپاکس
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-[#14141a] border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between text-xs text-slate-400">
                    <span>تجهیزات فعال کاتالوگ</span>
                    <Package className="w-4 h-4 text-amber-400" />
                  </div>
                  <div className="text-xl font-black text-white font-num">
                    {products.length} قلم دستگاه
                  </div>
                  <div className="text-[11px] text-emerald-400 font-medium">
                    موجودی انبار طالقانی اهواز
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-[#14141a] border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between text-xs text-slate-400">
                    <span>سهم پرداخت اقساطی اسنپ‌پی</span>
                    <CreditCard className="w-4 h-4 text-rose-400" />
                  </div>
                  <div className="text-xl font-black text-white font-num">
                    {orders.length > 0 ? Math.round((snappPayCount / orders.length) * 100) : 50}%
                  </div>
                  <div className="text-[11px] text-sky-400 font-medium">
                    {snappPayCount} سفارش با ۴ قسط اسنپ‌پی
                  </div>
                </div>
              </div>

              {/* Payment Methods Breakdown */}
              <div className="p-5 rounded-2xl bg-[#14141a] border border-slate-800 space-y-4">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <CreditCard className="w-4 h-4 text-rose-500" />
                  <span>عملکرد روش‌های پرداخت فروشگاه (اسنپ‌پی، چک صیادی، درگاه سامان)</span>
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="p-3 rounded-xl bg-sky-950/30 border border-sky-600/40 space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-sky-300">خرید اقساطی اسنپ‌پی (SnappPay)</span>
                      <span className="font-num font-black text-sky-400">{snappPayCount} سفارش</span>
                    </div>
                    <p className="text-[10px] text-slate-400 leading-relaxed">
                      ۴ قسط بدون بهره بدون نیاز به چک و ضامن برای کارشناسان و مهندسین
                    </p>
                  </div>

                  <div className="p-3 rounded-xl bg-amber-950/30 border border-amber-600/40 space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-amber-300">اقساط با چک صیادی (حضوری اهواز)</span>
                      <span className="font-num font-black text-amber-400">{installmentInPersonCount} سفارش</span>
                    </div>
                    <p className="text-[10px] text-slate-400 leading-relaxed">
                      تأمین تجهیزات به صورت اعتباری با چک صیادی بنفش و هماهنگی حضوری
                    </p>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-900 border border-slate-700 space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-slate-200">درگاه پرداخت آنلاین سامان (شتاب)</span>
                      <span className="font-num font-black text-slate-300">{onlinePayCount} سفارش</span>
                    </div>
                    <p className="text-[10px] text-slate-400 leading-relaxed">
                      تسویه آنی از طریق کلیه کارت‌های عضو سامانه شتاب با فاکتور رسمی
                    </p>
                  </div>
                </div>
              </div>

              {/* Quick Actions Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-5 rounded-2xl bg-[#14141a] border border-slate-800 space-y-3">
                  <h4 className="text-xs font-bold text-white flex items-center gap-2">
                    <Clock className="w-4 h-4 text-amber-400" />
                    <span>آخرین سفارشات نیازمند رسیدگی انبار</span>
                  </h4>
                  <div className="space-y-2">
                    {orders.slice(0, 3).map((o) => (
                      <div key={o.id} className="p-2.5 rounded-xl bg-black/50 border border-slate-800/80 flex items-center justify-between text-xs">
                        <div>
                          <div className="font-bold text-white flex items-center gap-2 font-num">
                            <span>{o.trackingCode}</span>
                            <span className="text-slate-400 font-sans font-normal">· {o.customerName}</span>
                          </div>
                          <div className="text-[10px] text-slate-400 font-sans mt-0.5">
                            {o.items.length} قلم کالا · {o.city}
                          </div>
                        </div>
                        <div className="text-end">
                          <div className="font-num font-bold text-rose-400">
                            {o.totalAmount.toLocaleString('en-US')} ت
                          </div>
                          <span className={`text-[9px] px-2 py-0.5 rounded-full font-bold ${
                            o.status === 'delivered' ? 'bg-emerald-950 text-emerald-400' :
                            o.status === 'shipped' ? 'bg-blue-950 text-blue-400' :
                            'bg-amber-950 text-amber-400'
                          }`}>
                            {o.status === 'delivered' ? 'تحویل شد' : o.status === 'shipped' ? 'ارسال شد' : 'در حال پردازش'}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="p-5 rounded-2xl bg-[#14141a] border border-slate-800 space-y-3">
                  <h4 className="text-xs font-bold text-white flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-emerald-400" />
                    <span>دسترسی‌های سریع مدیریت</span>
                  </h4>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <button
                      onClick={() => setActiveTab('products')}
                      className="p-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-start space-y-1 transition-colors"
                    >
                      <Package className="w-4 h-4 text-rose-500" />
                      <div className="font-bold text-white">ویرایش قیمت و موجودی</div>
                      <div className="text-[10px] text-slate-400">تغییر لحظه‌ای قیمت‌های انبار</div>
                    </button>
                    <button
                      onClick={() => setActiveTab('ticker')}
                      className="p-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-start space-y-1 transition-colors"
                    >
                      <Edit3 className="w-4 h-4 text-amber-400" />
                      <div className="font-bold text-white">ویرایش نوار اطلاعیه</div>
                      <div className="text-[10px] text-slate-400">تغییر پیام متحرک بالای سایت</div>
                    </button>
                    <button
                      onClick={() => setActiveTab('orders')}
                      className="p-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-start space-y-1 transition-colors"
                    >
                      <ShoppingCart className="w-4 h-4 text-sky-400" />
                      <div className="font-bold text-white">صدور فاکتور و پیگیری</div>
                      <div className="text-[10px] text-slate-400">تغییر وضعیت ارسال به تیپاکس</div>
                    </button>
                    <button
                      onClick={() => setActiveTab('retention')}
                      className="p-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-start space-y-1 transition-colors"
                    >
                      <Tag className="w-4 h-4 text-emerald-400" />
                      <div className="font-bold text-white">کد تخفیف خروج مشتری</div>
                      <div className="text-[10px] text-slate-400">تغییر کد ۵٪ پیشنهاد ترک سایت</div>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: ORDERS MANAGEMENT */}
          {activeTab === 'orders' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-bold text-white">لیست سفارش‌های ثبت‌شده مشتریان</h3>
                  <span className="text-xs text-slate-400 font-num">({filteredOrders.length} سفارش)</span>
                </div>

                <div className="flex items-center gap-1.5 overflow-x-auto text-xs">
                  {[
                    { id: 'all', label: 'همه سفارش‌ها' },
                    { id: 'pending', label: 'در انتظار تایید' },
                    { id: 'processing', label: 'در حال آماده‌سازی' },
                    { id: 'shipped', label: 'ارسال شده' },
                    { id: 'delivered', label: 'تحویل داده شده' },
                  ].map((f) => (
                    <button
                      key={f.id}
                      onClick={() => setOrderFilter(f.id as any)}
                      className={`px-3 py-1.5 rounded-xl font-bold transition-colors ${
                        orderFilter === f.id
                          ? 'bg-rose-600 text-white shadow-xs'
                          : 'bg-slate-900 text-slate-300 border border-slate-800 hover:bg-slate-800'
                      }`}
                    >
                      {f.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Orders Table */}
              <div className="overflow-x-auto rounded-2xl border border-slate-800 bg-[#14141a]">
                <table className="w-full text-xs text-start">
                  <thead className="bg-[#181822] text-slate-400 border-b border-slate-800 text-[11px]">
                    <tr>
                      <th className="p-3 text-start">کد رهگیری</th>
                      <th className="p-3 text-start">مشتری و تلفن</th>
                      <th className="p-3 text-start">مقصد و روش ارسال</th>
                      <th className="p-3 text-start">روش پرداخت</th>
                      <th className="p-3 text-start">مبلغ کل</th>
                      <th className="p-3 text-start">وضعیت سفارش</th>
                      <th className="p-3 text-start">اقدامات مدیریت</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/70 text-slate-300">
                    {filteredOrders.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="text-center py-12 text-slate-500">
                          هیچ سفارشی در این وضعیت یافت نشد.
                        </td>
                      </tr>
                    ) : (
                      filteredOrders.map((ord) => (
                        <tr key={ord.id} className="hover:bg-slate-800/30 transition-colors">
                          <td className="p-3 font-num font-bold text-white">
                            {ord.trackingCode}
                          </td>
                          <td className="p-3">
                            <div className="font-bold text-white">{ord.customerName}</div>
                            <div className="font-num text-[11px] text-slate-400" dir="ltr">{ord.customerPhone}</div>
                          </td>
                          <td className="p-3">
                            <div className="text-slate-200">{ord.city}</div>
                            <div className="text-[10px] text-slate-400">
                              {ord.shippingMethod === 'express_ahvaz' ? 'پیک سریع اهواز' :
                               ord.shippingMethod === 'tipax' ? 'تیپاکس پیشتاز' : 'باربری'}
                            </div>
                          </td>
                          <td className="p-3">
                            {ord.paymentMethod === 'snapp_pay' && (
                              <span className="px-2 py-0.5 rounded bg-sky-950 border border-sky-600/40 text-sky-300 text-[10px] font-bold">
                                اسنپ‌پی (۴ قسط)
                              </span>
                            )}
                            {ord.paymentMethod === 'installment_in_person' && (
                              <span className="px-2 py-0.5 rounded bg-amber-950 border border-amber-600/40 text-amber-300 text-[10px] font-bold">
                                چک صیادی (حضوری)
                              </span>
                            )}
                            {ord.paymentMethod === 'online' && (
                              <span className="px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-slate-200 text-[10px]">
                                درگاه آنلاین سامان
                              </span>
                            )}
                          </td>
                          <td className="p-3 font-num font-bold text-rose-400">
                            {ord.totalAmount.toLocaleString('en-US')} تومان
                          </td>
                          <td className="p-3">
                            <select
                              value={ord.status}
                              onChange={(e) => onUpdateOrderStatus(ord.id, e.target.value as AdminOrder['status'])}
                              className="px-2 py-1 rounded-lg bg-black/60 border border-slate-700 text-xs text-white focus:outline-none"
                            >
                              <option value="pending">در انتظار تایید</option>
                              <option value="processing">آماده‌سازی در انبار اهواز</option>
                              <option value="shipped">تحویل پیک / تیپاکس</option>
                              <option value="delivered">تحویل داده شده</option>
                            </select>
                          </td>
                          <td className="p-3">
                            <button
                              onClick={() => setSelectedOrderDetails(ord)}
                              className="px-2.5 py-1 rounded-lg border border-slate-700 hover:border-slate-500 bg-slate-800 text-slate-300 hover:text-white text-[11px] flex items-center gap-1"
                            >
                              <Eye className="w-3 h-3 text-sky-400" />
                              <span>فاکتور و اقلام</span>
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 3: PRODUCTS & STOCK MANAGEMENT */}
          {activeTab === 'products' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
                <div>
                  <h3 className="text-sm font-bold text-white">کاتالوگ و انبارداری تجهیزات پیشگام صنعت</h3>
                  <p className="text-xs text-slate-400">تغییر آنی قیمت‌ها، موجودی انبار اهواز و افزودن دستگاه جدید</p>
                </div>
                <button
                  onClick={() => setShowAddProductModal(true)}
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition-colors"
                >
                  <Plus className="w-4 h-4" />
                  <span>افزودن دستگاه / محصول جدید</span>
                </button>
              </div>

              {/* Product Cards List */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {products.map((prod) => (
                  <div
                    key={prod.id}
                    className="p-4 rounded-2xl bg-[#14141a] border border-slate-800 space-y-3 relative group"
                  >
                    <div className="flex gap-3">
                      <div className="relative group/img shrink-0">
                        <img
                          src={prod.image}
                          alt={prod.name}
                          className="w-20 h-20 rounded-xl object-cover border border-slate-700 bg-black cursor-pointer hover:opacity-90 transition-opacity"
                          onClick={() => {
                            setEditingImageProduct(prod);
                            setSelectedImageUrl(prod.image);
                            setCustomImageUrlInput(prod.image.startsWith('data:') ? '' : prod.image);
                          }}
                          title="کلیک جهت تغییر عکس"
                        />
                        <button
                          type="button"
                          onClick={() => {
                            setEditingImageProduct(prod);
                            setSelectedImageUrl(prod.image);
                            setCustomImageUrlInput(prod.image.startsWith('data:') ? '' : prod.image);
                          }}
                          className="absolute inset-0 bg-black/70 rounded-xl opacity-0 group-hover/img:opacity-100 flex flex-col items-center justify-center text-white text-[10px] font-bold transition-opacity"
                        >
                          <Camera className="w-4 h-4 text-cyan-400 mb-0.5" />
                          <span>تغییر عکس</span>
                        </button>
                      </div>
                      <div className="space-y-1 flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-bold border border-slate-700">
                            {prod.brand}
                          </span>
                          <button
                            onClick={() => {
                              onUpdateProduct({ ...prod, inStock: !prod.inStock });
                            }}
                            className={`text-[10px] px-2 py-0.5 rounded-full font-bold border transition-colors ${
                              prod.inStock
                                ? 'bg-emerald-950/80 border-emerald-600/70 text-emerald-300'
                                : 'bg-rose-950/80 border-rose-600/70 text-rose-300'
                            }`}
                          >
                            {prod.inStock ? 'موجود در اهواز' : 'ناموجود'}
                          </button>
                        </div>
                        <h4 className="text-xs font-bold text-white truncate">{prod.name}</h4>
                        <div className="text-[11px] font-num font-bold text-rose-400">{prod.model}</div>
                      </div>
                    </div>

                    {/* Specs snippet */}
                    <div className="text-[11px] text-slate-400 bg-black/40 p-2 rounded-xl border border-slate-800/60 font-num space-y-0.5">
                      <div><span className="font-sans text-slate-500">رنج کاری:</span> {prod.specs.voltageRange}</div>
                      <div><span className="font-sans text-slate-500">دقت:</span> {prod.specs.accuracy}</div>
                    </div>

                    {/* Price and Action editor */}
                    <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between">
                      {editingPriceId === prod.id ? (
                        <div className="flex items-center gap-1.5 w-full">
                          <input
                            type="number"
                            value={tempPrice}
                            onChange={(e) => setTempPrice(Number(e.target.value))}
                            className="p-1.5 rounded-lg border border-slate-700 bg-black text-white text-xs font-num flex-1"
                          />
                          <button
                            onClick={() => handleCommitEditPrice(prod)}
                            className="p-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white"
                          >
                            <Check className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => setEditingPriceId(null)}
                            className="p-1.5 rounded-lg bg-slate-800 text-slate-400"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <>
                          <div>
                            <span className="text-[10px] text-slate-500 block">قیمت انبار:</span>
                            <span className="font-num text-sm font-black text-white">
                              {prod.price.toLocaleString('en-US')} تومان
                            </span>
                          </div>
                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => {
                                setEditingImageProduct(prod);
                                setSelectedImageUrl(prod.image);
                                setCustomImageUrlInput(prod.image.startsWith('data:') ? '' : prod.image);
                              }}
                              className="px-2 py-1 rounded-lg border border-cyan-800/80 hover:border-cyan-600 bg-cyan-950/40 text-cyan-300 text-[11px] flex items-center gap-1 transition-colors"
                              title="تنظیم یا تغییر عکس محصول"
                            >
                              <Camera className="w-3 h-3 text-cyan-400" />
                              <span>عکس</span>
                            </button>
                            <button
                              onClick={() => handleStartEditPrice(prod)}
                              className="px-2 py-1 rounded-lg border border-slate-700 hover:border-slate-500 bg-slate-800 text-slate-300 text-[11px] flex items-center gap-1"
                              title="تغییر قیمت"
                            >
                              <Edit3 className="w-3 h-3 text-amber-400" />
                              <span>قیمت</span>
                            </button>
                            <button
                              onClick={() => {
                                if (confirm(`آیا از حذف "${prod.name}" اطمینان دارید؟`)) {
                                  onDeleteProduct(prod.id);
                                }
                              }}
                              className="p-1.5 rounded-lg border border-slate-800 hover:border-rose-800 text-slate-500 hover:text-rose-400"
                              title="حذف کالا"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB: BANNERS SLIDER MANAGEMENT (مدیریت بنرهای متغیر و تایمردار) */}
          {activeTab === 'banners' && (
            <div className="space-y-6 max-w-4xl mx-auto">
              {/* Header */}
              <div className="p-5 rounded-2xl bg-[#14141a] border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-500">
                    <ImageIcon className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-white flex items-center gap-2">
                      <span>مدیریت اسلایدر بنرهای صفحه اصلی (تایمردار)</span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 font-num">
                        {bannerSlides.length} اسلاید
                      </span>
                    </h3>
                    <p className="text-xs text-slate-400">
                      تنظیم زمان گردش خودکار، تعویض عکس، تیتر و متن هر بنر (محصولات جدید، برندها یا بنر سفارشی)
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setShowAddBannerModal(true)}
                  className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-md transition-colors shrink-0"
                >
                  <Plus className="w-4 h-4" />
                  <span>+ افزودن بنر جدید به اسلایدر</span>
                </button>
              </div>

              {/* Slider Timer Setting */}
              <div className="p-4 rounded-2xl bg-[#14141a] border border-slate-800 space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <Timer className="w-4 h-4 text-amber-400" />
                    <span className="text-xs font-bold text-white">مدت زمان چرخش خودکار هر اسلاید:</span>
                    <span className="font-num text-xs font-bold text-amber-400 px-2 py-0.5 rounded-lg bg-amber-500/10 border border-amber-500/20">
                      هر {bannerInterval} ثانیه یک‌بار
                    </span>
                  </div>

                  {/* Preset intervals */}
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {[
                      { sec: 5, label: '۵ ثانیه (سریع)' },
                      { sec: 8, label: '۸ ثانیه (استاندارد)' },
                      { sec: 12, label: '۱۲ ثانیه' },
                      { sec: 20, label: '۲۰ ثانیه' },
                      { sec: 60, label: '۱ دقیقه' },
                    ].map((item) => (
                      <button
                        key={item.sec}
                        type="button"
                        onClick={() => {
                          onUpdateBannerInterval(item.sec);
                          setBannerToast(`زمان چرخش بنرها به ${item.label} تنظیم گردید.`);
                          setTimeout(() => setBannerToast(null), 3000);
                        }}
                        className={`px-2.5 py-1 rounded-lg text-[11px] font-bold font-num transition-all ${
                          bannerInterval === item.sec
                            ? 'bg-amber-500 text-slate-950 font-black'
                            : 'bg-slate-900 text-slate-300 border border-slate-800 hover:bg-slate-800'
                        }`}
                      >
                        {item.label}
                      </button>
                    ))}
                  </div>
                </div>

                <p className="text-[11px] text-slate-400 leading-relaxed">
                  هنگامی که موس کاربر روی بنر قرار گیرد، تایمر موقتاً متوقف می‌شود تا مشتری بتواند با آرامش جزئیات بنر را مطالعه کند.
                </p>
              </div>

              {bannerToast && (
                <div className="p-3 rounded-xl bg-emerald-950/60 border border-emerald-600/50 text-emerald-300 text-xs flex items-center gap-2 animate-in fade-in">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>{bannerToast}</span>
                </div>
              )}

              {/* Slides List */}
              <div className="space-y-3">
                <span className="text-xs font-bold text-slate-300 block">اسلایدهای فعال در بنر صفحه اصلی:</span>
                
                {bannerSlides.map((slide, index) => (
                  <div
                    key={slide.id}
                    className={`p-4 rounded-2xl border transition-all ${
                      slide.active
                        ? 'bg-[#14141a] border-slate-800 hover:border-slate-700'
                        : 'bg-black/40 border-slate-900 opacity-60'
                    }`}
                  >
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                      {/* Thumbnail & Info */}
                      <div className="flex items-start sm:items-center gap-3.5 flex-1 min-w-0">
                        <div className="relative shrink-0">
                          <img
                            src={slide.image}
                            alt={slide.title}
                            className="w-20 h-16 sm:w-24 sm:h-20 rounded-xl object-cover border border-slate-700 bg-black"
                          />
                          <span className="absolute -top-2 -start-2 px-1.5 py-0.2 rounded-full bg-slate-900 border border-slate-700 text-white font-num text-[10px] font-bold">
                            #{index + 1}
                          </span>
                        </div>

                        <div className="space-y-1 min-w-0 flex-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-950/70 border border-rose-800/60 text-rose-300 font-bold">
                              {slide.badge}
                            </span>
                            <span className="text-[10px] text-slate-400">
                              {slide.type === 'main'
                                ? '🏷️ بنر شماره ۱ (اصلی انبار اهواز)'
                                : slide.type === 'new_products'
                                ? '⚡ بنر شماره ۲ (معرفی محصولات جدید ۲۰۲۶)'
                                : slide.type === 'brands'
                                ? '🏆 بنر شماره ۳ (معرفی برندهای جهانی)'
                                : '✨ بنر سفارشی'}
                            </span>
                          </div>

                          <h4 className="text-sm font-bold text-white truncate">{slide.title}</h4>
                          <p className="text-xs text-slate-400 line-clamp-1">{slide.description}</p>
                          
                          <div className="text-[10px] text-slate-500 flex items-center gap-2">
                            <span>دکمه: <strong className="text-slate-300">{slide.buttonText}</strong></span>
                            <span>•</span>
                            <span className="truncate max-w-[150px]">لینک: {slide.buttonLink}</span>
                          </div>
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="flex items-center gap-2 shrink-0 self-end md:self-center">
                        {/* Toggle Active */}
                        <button
                          type="button"
                          onClick={() => {
                            const updated = bannerSlides.map((s) =>
                              s.id === slide.id ? { ...s, active: !s.active } : s
                            );
                            onUpdateBannerSlides(updated);
                            setBannerToast(
                              `اسلاید شماره ${index + 1} ${slide.active ? 'غیرفعال و مخفی' : 'فعال'} شد.`
                            );
                            setTimeout(() => setBannerToast(null), 3000);
                          }}
                          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors ${
                            slide.active
                              ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/20'
                              : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                          }`}
                        >
                          {slide.active ? 'فعال در سایت' : 'غیرفعال (مخفی)'}
                        </button>

                        {/* Open Gallery Photo Picker for this Banner */}
                        <button
                          type="button"
                          onClick={() => setPhotoPickerSlideId(slide.id)}
                          className="px-3 py-1.5 rounded-xl bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 text-xs font-bold flex items-center gap-1.5 transition-colors border border-rose-800/60 hover:border-rose-500 cursor-pointer"
                          title="انتخاب تصویر این بنر از آلبوم و تجهیزات سایت"
                        >
                          <ImageIcon className="w-3.5 h-3.5 text-rose-400" />
                          <span>انتخاب عکس از گالری</span>
                        </button>

                        {/* Quick Change Banner Photo */}
                        <label
                          className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer border border-slate-700 hover:border-cyan-500"
                          title="تغییر سریع تصویر این بنر از سیستم"
                        >
                          <Camera className="w-3.5 h-3.5 text-cyan-400" />
                          <span>آپلود فایل عکس</span>
                          <input
                            type="file"
                            accept="image/*"
                            onChange={(e) => {
                              const file = e.target.files?.[0];
                              if (file) {
                                const reader = new FileReader();
                                reader.onload = () => {
                                  const updated = bannerSlides.map((s) =>
                                    s.id === slide.id ? { ...s, image: reader.result as string } : s
                                  );
                                  onUpdateBannerSlides(updated);
                                  setBannerToast(`عکس بنر شماره ${index + 1} با موفقیت به‌روزرسانی شد.`);
                                  setTimeout(() => setBannerToast(null), 3000);
                                };
                                reader.readAsDataURL(file);
                              }
                            }}
                            className="hidden"
                          />
                        </label>

                        {/* Edit Button */}
                        <button
                          type="button"
                          onClick={() => setEditingSlide(slide)}
                          className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold flex items-center gap-1.5 transition-colors"
                        >
                          <Edit3 className="w-3.5 h-3.5 text-rose-400" />
                          <span>ویرایش کامل اسلاید</span>
                        </button>

                        {/* Delete (if custom or more than 1) */}
                        {bannerSlides.length > 1 && (
                          <button
                            type="button"
                            onClick={() => {
                              if (confirm(`آیا از حذف اسلاید "${slide.title}" اطمینان دارید؟`)) {
                                const updated = bannerSlides.filter((s) => s.id !== slide.id);
                                onUpdateBannerSlides(updated);
                                setBannerToast('اسلاید با موفقیت حذف گردید.');
                                setTimeout(() => setBannerToast(null), 3000);
                              }
                            }}
                            className="p-1.5 rounded-xl border border-slate-800 hover:border-rose-800 text-slate-500 hover:text-rose-400 transition-colors"
                            title="حذف اسلاید"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Edit Slide Modal */}
              {editingSlide && (
                <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4">
                  <div className="bg-[#121318] border border-slate-700 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto p-5 sm:p-6 space-y-4 shadow-2xl">
                    <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                      <div className="flex items-center gap-2">
                        <Edit3 className="w-5 h-5 text-rose-500" />
                        <h3 className="font-bold text-base text-white">ویرایش اسلاید بنر</h3>
                      </div>
                      <button
                        onClick={() => setEditingSlide(null)}
                        className="text-slate-400 hover:text-white p-1"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>

                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        const updated = bannerSlides.map((s) =>
                          s.id === editingSlide.id ? editingSlide : s
                        );
                        onUpdateBannerSlides(updated);
                        setEditingSlide(null);
                        setBannerToast('تغییرات اسلاید بنر با موفقیت ذخیره شد.');
                        setTimeout(() => setBannerToast(null), 3000);
                      }}
                      className="space-y-4 text-xs"
                    >
                      {/* Badge & Title */}
                      <div className="space-y-3">
                        <div>
                          <label className="block text-slate-300 mb-1 font-bold">بج کوچک بالای بنر:</label>
                          <input
                            type="text"
                            value={editingSlide.badge}
                            onChange={(e) => setEditingSlide({ ...editingSlide, badge: e.target.value })}
                            className="w-full p-2.5 rounded-xl border border-slate-700 bg-slate-900 text-white"
                          />
                        </div>
                        <div>
                          <label className="block text-slate-300 mb-1 font-bold">عنوان اصلی بنر (تیتر بزرگ):</label>
                          <input
                            type="text"
                            required
                            value={editingSlide.title}
                            onChange={(e) => setEditingSlide({ ...editingSlide, title: e.target.value })}
                            className="w-full p-2.5 rounded-xl border border-slate-700 bg-slate-900 text-white font-bold"
                          />
                        </div>
                        <div>
                          <label className="block text-slate-300 mb-1 font-bold">توضیحات و متن معرفی:</label>
                          <textarea
                            rows={3}
                            value={editingSlide.description}
                            onChange={(e) => setEditingSlide({ ...editingSlide, description: e.target.value })}
                            className="w-full p-2.5 rounded-xl border border-slate-700 bg-slate-900 text-white leading-relaxed"
                          />
                        </div>
                      </div>

                      {/* Buttons Text & Links */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-800">
                        <div>
                          <label className="block text-slate-300 mb-1 font-bold">متن دکمه اول (اصلی):</label>
                          <input
                            type="text"
                            value={editingSlide.buttonText}
                            onChange={(e) => setEditingSlide({ ...editingSlide, buttonText: e.target.value })}
                            className="w-full p-2 rounded-xl border border-slate-700 bg-slate-900 text-white"
                          />
                        </div>
                        <div>
                          <label className="block text-slate-300 mb-1 font-bold">لینک دکمه اول:</label>
                          <input
                            type="text"
                            value={editingSlide.buttonLink}
                            onChange={(e) => setEditingSlide({ ...editingSlide, buttonLink: e.target.value })}
                            className="w-full p-2 rounded-xl border border-slate-700 bg-slate-900 text-white font-mono text-[11px]"
                          />
                        </div>
                        <div>
                          <label className="block text-slate-300 mb-1 font-bold">متن دکمه دوم (اختیاری):</label>
                          <input
                            type="text"
                            value={editingSlide.secondaryButtonText || ''}
                            onChange={(e) => setEditingSlide({ ...editingSlide, secondaryButtonText: e.target.value })}
                            placeholder="مثال: برندها و نمایندگی‌ها"
                            className="w-full p-2 rounded-xl border border-slate-700 bg-slate-900 text-white"
                          />
                        </div>
                        <div>
                          <label className="block text-slate-300 mb-1 font-bold">لینک دکمه دوم:</label>
                          <input
                            type="text"
                            value={editingSlide.secondaryButtonLink || ''}
                            onChange={(e) => setEditingSlide({ ...editingSlide, secondaryButtonLink: e.target.value })}
                            placeholder="#agencies"
                            className="w-full p-2 rounded-xl border border-slate-700 bg-slate-900 text-white font-mono text-[11px]"
                          />
                        </div>
                      </div>

                      {/* Image Selection */}
                      <div className="pt-2 border-t border-slate-800 space-y-2.5">
                        <label className="block text-slate-300 font-bold">تصویر بنر:</label>
                        
                        <div className="flex items-center gap-3 p-3 rounded-xl bg-black/50 border border-slate-800">
                          <img
                            src={editingSlide.image}
                            alt="Preview"
                            className="w-24 h-16 rounded-lg object-cover border border-slate-700 bg-black shrink-0"
                          />
                          <div className="space-y-1 min-w-0 flex-1">
                            <span className="text-[11px] text-slate-300 block truncate font-mono">
                              {editingSlide.image}
                            </span>
                            <label className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white cursor-pointer text-[11px] font-bold">
                              <Upload className="w-3.5 h-3.5 text-emerald-400" />
                              <span>آپلود عکس جدید از کامپیوتر یا گوشی</span>
                              <input
                                type="file"
                                accept="image/*"
                                onChange={(e) => {
                                  const file = e.target.files?.[0];
                                  if (file) {
                                    const reader = new FileReader();
                                    reader.onload = () => {
                                      setEditingSlide({ ...editingSlide, image: reader.result as string });
                                    };
                                    reader.readAsDataURL(file);
                                  }
                                }}
                                className="hidden"
                              />
                            </label>
                          </div>
                        </div>

                        {/* Presets */}
                        <div className="space-y-1.5">
                          <span className="text-[11px] text-slate-400 block">یا انتخاب از تصاویر آماده تجهیزات صنعتی:</span>
                          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                            {PRODUCT_IMAGE_PRESETS.map((p, idx) => (
                              <button
                                key={idx}
                                type="button"
                                onClick={() => setEditingSlide({ ...editingSlide, image: p.url })}
                                className={`p-1.5 rounded-xl border flex items-center gap-2 transition-all ${
                                  editingSlide.image === p.url
                                    ? 'border-rose-500 bg-rose-500/10'
                                    : 'border-slate-800 bg-slate-900/60 hover:border-slate-700'
                                }`}
                              >
                                <img src={p.url} alt={p.name} className="w-8 h-8 rounded-md object-cover shrink-0" />
                                <span className="text-[10px] text-slate-300 truncate text-start">{p.name}</span>
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>

                      {/* Modal Actions */}
                      <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                        <button
                          type="button"
                          onClick={() => setEditingSlide(null)}
                          className="px-4 py-2 rounded-xl border border-slate-700 text-slate-400 hover:text-white"
                        >
                          انصراف
                        </button>
                        <button
                          type="submit"
                          className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold"
                        >
                          ذخیره تغییرات اسلاید
                        </button>
                      </div>
                    </form>
                  </div>
                </div>
              )}

              {/* Add New Slide Modal */}
              {showAddBannerModal && (
                <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4">
                  <div className="bg-[#121318] border border-slate-700 rounded-2xl w-full max-w-xl p-5 sm:p-6 space-y-4 shadow-2xl">
                    <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                      <div className="flex items-center gap-2">
                        <Plus className="w-5 h-5 text-rose-500" />
                        <h3 className="font-bold text-base text-white">افزودن بنر جدید به اسلایدر</h3>
                      </div>
                      <button
                        onClick={() => setShowAddBannerModal(false)}
                        className="text-slate-400 hover:text-white p-1"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>

                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        const newSlide: BannerSlide = {
                          id: `slide-${Date.now()}`,
                          badge: newBannerBadge || 'پیشنهاد انبار اهواز',
                          title: newBannerTitle,
                          description: newBannerDescription,
                          buttonText: newBannerBtnText || 'مشاهده کاتالوگ',
                          buttonLink: newBannerBtnLink || '#catalog',
                          image: newBannerImage,
                          active: true,
                          type: 'custom',
                        };
                        onUpdateBannerSlides([...bannerSlides, newSlide]);
                        setShowAddBannerModal(false);
                        setNewBannerTitle('');
                        setNewBannerDescription('');
                        setBannerToast('بنر جدید با موفقیت به اسلایدر اضافه شد.');
                        setTimeout(() => setBannerToast(null), 3000);
                      }}
                      className="space-y-3.5 text-xs"
                    >
                      <div>
                        <label className="block text-slate-300 mb-1 font-bold">بج بالای بنر:</label>
                        <input
                          type="text"
                          value={newBannerBadge}
                          onChange={(e) => setNewBannerBadge(e.target.value)}
                          placeholder="مثال: تخفیف ویژه ماهانه"
                          className="w-full p-2.5 rounded-xl border border-slate-700 bg-slate-900 text-white"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-300 mb-1 font-bold">عنوان بنر *:</label>
                        <input
                          type="text"
                          required
                          value={newBannerTitle}
                          onChange={(e) => setNewBannerTitle(e.target.value)}
                          placeholder="مثال: ورود سری جدید پاورآنالایزرهای صنعتی"
                          className="w-full p-2.5 rounded-xl border border-slate-700 bg-slate-900 text-white font-bold"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-300 mb-1 font-bold">توضیحات بنر:</label>
                        <textarea
                          rows={2}
                          value={newBannerDescription}
                          onChange={(e) => setNewBannerDescription(e.target.value)}
                          placeholder="توضیح کوتاه درباره کاربرد یا تخفیف دستگاه..."
                          className="w-full p-2.5 rounded-xl border border-slate-700 bg-slate-900 text-white"
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block text-slate-300 mb-1 font-bold">متن دکمه:</label>
                          <input
                            type="text"
                            value={newBannerBtnText}
                            onChange={(e) => setNewBannerBtnText(e.target.value)}
                            className="w-full p-2 rounded-xl border border-slate-700 bg-slate-900 text-white"
                          />
                        </div>
                        <div>
                          <label className="block text-slate-300 mb-1 font-bold">لینک دکمه:</label>
                          <input
                            type="text"
                            value={newBannerBtnLink}
                            onChange={(e) => setNewBannerBtnLink(e.target.value)}
                            className="w-full p-2 rounded-xl border border-slate-700 bg-slate-900 text-white font-mono text-[11px]"
                          />
                        </div>
                      </div>

                      {/* Banner Photo Selection & Upload */}
                      <div className="pt-2 border-t border-slate-800 space-y-2.5">
                        <label className="block text-slate-300 font-bold">عکس بنر جدید *:</label>
                        
                        <div className="flex items-center gap-3 p-3 rounded-xl bg-black/50 border border-slate-800">
                          <img
                            src={newBannerImage}
                            alt="Preview"
                            className="w-24 h-16 rounded-lg object-cover border border-slate-700 bg-black shrink-0"
                          />
                          <div className="space-y-1 min-w-0 flex-1">
                            <span className="text-[11px] text-slate-300 block truncate font-mono">
                              {newBannerImage}
                            </span>
                            <label className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white cursor-pointer text-[11px] font-bold shadow-xs">
                              <Upload className="w-3.5 h-3.5" />
                              <span>انتخاب و آپلود عکس از کامپیوتر یا گوشی</span>
                              <input
                                type="file"
                                accept="image/*"
                                onChange={(e) => {
                                  const file = e.target.files?.[0];
                                  if (file) {
                                    const reader = new FileReader();
                                    reader.onload = () => {
                                      setNewBannerImage(reader.result as string);
                                    };
                                    reader.readAsDataURL(file);
                                  }
                                }}
                                className="hidden"
                              />
                            </label>
                          </div>
                        </div>

                        {/* Presets Grid */}
                        <div className="space-y-1.5">
                          <span className="text-[11px] text-slate-400 block">یا انتخاب از تصاویر آماده تجهیزات صنعتی اهواز:</span>
                          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 max-h-36 overflow-y-auto p-1">
                            {PRODUCT_IMAGE_PRESETS.map((p, idx) => (
                              <button
                                key={idx}
                                type="button"
                                onClick={() => setNewBannerImage(p.url)}
                                className={`p-1.5 rounded-xl border flex items-center gap-2 transition-all ${
                                  newBannerImage === p.url
                                    ? 'border-rose-500 bg-rose-500/10'
                                    : 'border-slate-800 bg-slate-900/60 hover:border-slate-700'
                                }`}
                              >
                                <img src={p.url} alt={p.name} className="w-8 h-8 rounded-md object-cover shrink-0" />
                                <span className="text-[10px] text-slate-300 truncate text-start">{p.name}</span>
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                        <button
                          type="button"
                          onClick={() => setShowAddBannerModal(false)}
                          className="px-4 py-2 rounded-xl border border-slate-700 text-slate-400 hover:text-white"
                        >
                          انصراف
                        </button>
                        <button
                          type="submit"
                          className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold"
                        >
                          افزودن اسلاید
                        </button>
                      </div>
                    </form>
                  </div>
                </div>
              )}

              {/* Photo Gallery Picker Modal */}
              {photoPickerSlideId && (
                <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 animate-in fade-in">
                  <div className="bg-[#121318] border border-slate-700 rounded-2xl w-full max-w-3xl max-h-[90vh] flex flex-col overflow-hidden shadow-2xl">
                    {/* Header */}
                    <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between shrink-0">
                      <div className="flex items-center gap-2.5">
                        <div className="w-9 h-9 rounded-xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-500">
                          <ImageIcon className="w-5 h-5" />
                        </div>
                        <div>
                          <h3 className="font-bold text-sm sm:text-base text-white">
                            انتخاب تصویر بنر از آلبوم تجهیزات صنعتی اهواز
                          </h3>
                          <p className="text-xs text-slate-400">
                            روی تصویر دلخواه کلیک کنید تا بلافاصله به عنوان عکس بنر تنظیم گردد.
                          </p>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => setPhotoPickerSlideId(null)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>

                    {/* Category Filter Pills */}
                    <div className="p-3 bg-[#0d0e12] border-b border-slate-800 flex items-center gap-1.5 flex-wrap shrink-0">
                      {[
                        { id: 'all', label: 'همه تصاویر (۱۰)' },
                        { id: 'مولتی‌متر', label: 'مولتی‌متر' },
                        { id: 'کلمپ‌متر', label: 'کلمپ آمپرمتر' },
                        { id: 'میگر', label: 'تستر عایق و میگر' },
                        { id: 'هیدرولیک', label: 'پرس هیدرولیک' },
                        { id: 'ترموویژن', label: 'دوربین حرارتی' },
                        { id: 'انبار', label: 'انبار مرکزی اهواز' },
                        { id: 'کالیبراتور', label: 'کالیبراسیون' },
                      ].map((cat) => (
                        <button
                          key={cat.id}
                          type="button"
                          onClick={() => setPhotoGalleryCategory(cat.id)}
                          className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                            photoGalleryCategory === cat.id
                              ? 'bg-rose-600 text-white shadow-xs'
                              : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                          }`}
                        >
                          {cat.label}
                        </button>
                      ))}
                    </div>

                    {/* Photos Grid */}
                    <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
                      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                        {PRODUCT_IMAGE_PRESETS
                          .filter((p) => photoGalleryCategory === 'all' || p.category === photoGalleryCategory)
                          .map((preset, idx) => {
                            const isCurrentSelected =
                              photoPickerSlideId === 'new_banner'
                                ? newBannerImage === preset.url
                                : bannerSlides.find((s) => s.id === photoPickerSlideId)?.image === preset.url;

                            return (
                              <div
                                key={idx}
                                onClick={() => {
                                  if (photoPickerSlideId === 'new_banner') {
                                    setNewBannerImage(preset.url);
                                  } else {
                                    const updated = bannerSlides.map((s) =>
                                      s.id === photoPickerSlideId ? { ...s, image: preset.url } : s
                                    );
                                    onUpdateBannerSlides(updated);
                                  }
                                  setBannerToast(`عکس بنر با موفقیت روی "${preset.name}" تنظیم شد.`);
                                  setTimeout(() => setBannerToast(null), 3000);
                                  setPhotoPickerSlideId(null);
                                }}
                                className={`group rounded-xl overflow-hidden border p-2 bg-slate-900/60 hover:bg-slate-800/80 cursor-pointer transition-all ${
                                  isCurrentSelected
                                    ? 'border-rose-500 ring-2 ring-rose-500/40 bg-rose-950/20'
                                    : 'border-slate-800 hover:border-slate-700'
                                }`}
                              >
                                <div className="relative h-32 rounded-lg overflow-hidden bg-black mb-2">
                                  <img
                                    src={preset.url}
                                    alt={preset.name}
                                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                                  />
                                  <span className="absolute top-2 start-2 px-2 py-0.5 rounded-md bg-black/80 backdrop-blur-xs text-[10px] font-bold text-rose-300 border border-white/10">
                                    {preset.category}
                                  </span>
                                  {isCurrentSelected && (
                                    <span className="absolute top-2 end-2 px-2 py-0.5 rounded-md bg-rose-600 text-white text-[10px] font-bold flex items-center gap-1 shadow-md">
                                      <Check className="w-3 h-3" />
                                      <span>انتخاب شده</span>
                                    </span>
                                  )}
                                </div>
                                <div className="space-y-1">
                                  <h4 className="text-xs font-bold text-white truncate">{preset.name}</h4>
                                  <button
                                    type="button"
                                    className="w-full mt-1 py-1 rounded-lg bg-rose-600/20 group-hover:bg-rose-600 text-rose-300 group-hover:text-white text-[11px] font-bold transition-colors flex items-center justify-center gap-1"
                                  >
                                    <Check className="w-3 h-3" />
                                    <span>انتخاب این عکس</span>
                                  </button>
                                </div>
                              </div>
                            );
                          })}
                      </div>

                      {/* Direct Upload or URL option */}
                      <div className="pt-4 border-t border-slate-800 space-y-3">
                        <span className="text-xs font-bold text-slate-300 block">
                          یا بارگذاری فایل تصویر از کامپیوتر یا لینک مستقیم:
                        </span>
                        <div className="flex flex-col sm:flex-row items-center gap-2.5">
                          <label className="w-full sm:w-auto px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold flex items-center justify-center gap-2 cursor-pointer border border-slate-700 hover:border-rose-500 shrink-0">
                            <Upload className="w-4 h-4 text-emerald-400" />
                            <span>آپلود عکس از سیستم</span>
                            <input
                              type="file"
                              accept="image/*"
                              onChange={(e) => {
                                const file = e.target.files?.[0];
                                if (file) {
                                  const reader = new FileReader();
                                  reader.onload = () => {
                                    const base64 = reader.result as string;
                                    if (photoPickerSlideId === 'new_banner') {
                                      setNewBannerImage(base64);
                                    } else {
                                      const updated = bannerSlides.map((s) =>
                                        s.id === photoPickerSlideId ? { ...s, image: base64 } : s
                                      );
                                      onUpdateBannerSlides(updated);
                                    }
                                    setBannerToast('عکس آپلود شده برای بنر ذخیره گردید.');
                                    setTimeout(() => setBannerToast(null), 3000);
                                    setPhotoPickerSlideId(null);
                                  };
                                  reader.readAsDataURL(file);
                                }
                              }}
                              className="hidden"
                            />
                          </label>

                          <div className="flex items-center gap-1.5 w-full flex-1">
                            <input
                              type="text"
                              placeholder="https://... آدرس عکس اینترنتی"
                              value={customPhotoInput}
                              onChange={(e) => setCustomPhotoInput(e.target.value)}
                              className="p-2 rounded-xl border border-slate-700 bg-slate-900 text-white text-xs flex-1 font-mono"
                            />
                            <button
                              type="button"
                              onClick={() => {
                                if (customPhotoInput.trim()) {
                                  if (photoPickerSlideId === 'new_banner') {
                                    setNewBannerImage(customPhotoInput.trim());
                                  } else {
                                    const updated = bannerSlides.map((s) =>
                                      s.id === photoPickerSlideId ? { ...s, image: customPhotoInput.trim() } : s
                                    );
                                    onUpdateBannerSlides(updated);
                                  }
                                  setBannerToast('آدرس تصویر با موفقیت روی بنر ذخیره شد.');
                                  setTimeout(() => setBannerToast(null), 3000);
                                  setPhotoPickerSlideId(null);
                                  setCustomPhotoInput('');
                                }
                              }}
                              className="px-3 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold shrink-0"
                            >
                              اعمال لینک
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Footer */}
                    <div className="p-3 bg-[#0d0e12] border-t border-slate-800 flex justify-end shrink-0">
                      <button
                        type="button"
                        onClick={() => setPhotoPickerSlideId(null)}
                        className="px-4 py-1.5 rounded-xl border border-slate-700 text-slate-300 hover:text-white text-xs font-bold cursor-pointer"
                      >
                        بستن
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB: SPECIAL 24H OFFERS MANAGEMENT (پیشنهادات شگفت‌انگیز ۲۴ ساعته) */}
          {activeTab === 'specialOffers' && (
            <div className="space-y-6 max-w-4xl mx-auto">
              {/* Header */}
              <div className="p-5 rounded-2xl bg-[#14141a] border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-500 shadow-inner">
                    <Flame className="w-5 h-5 text-amber-500" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-white flex items-center gap-2">
                      <span>مدیریت پیشنهادات شگفت‌انگیز ۲۴ ساعته (زیر بنر اصلی)</span>
                      <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                        specialOffers.enabled
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                          : 'bg-slate-800 text-slate-400'
                      }`}>
                        {specialOffers.enabled ? 'نمایش در سایت فعال است' : 'کادر مخفی است'}
                      </span>
                    </h3>
                    <p className="text-xs text-slate-400">
                      تنظیم تایمر معکوس، درصد تخفیف ویژه و لیست اقلام منتخب انبار اهواز
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    onUpdateSpecialOffers({ ...specialOffers, enabled: !specialOffers.enabled });
                    setSpecialOfferToast(
                      `نمایش کادر شگفت‌انگیز ۲۴ ساعته ${!specialOffers.enabled ? 'فعال' : 'غیرفعال'} گردید.`
                    );
                    setTimeout(() => setSpecialOfferToast(null), 3000);
                  }}
                  className={`px-4 py-2 rounded-xl font-bold text-xs transition-colors shrink-0 ${
                    specialOffers.enabled
                      ? 'bg-rose-600 hover:bg-rose-500 text-white'
                      : 'bg-emerald-600 hover:bg-emerald-500 text-white'
                  }`}
                >
                  {specialOffers.enabled ? 'مخفی کردن کادر در سایت' : 'فعال‌سازی نمایش در سایت'}
                </button>
              </div>

              {specialOfferToast && (
                <div className="p-3 rounded-xl bg-emerald-950/60 border border-emerald-600/50 text-emerald-300 text-xs flex items-center gap-2 animate-in fade-in">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>{specialOfferToast}</span>
                </div>
              )}

              {/* Timer & Duration Controller */}
              <div className="p-5 rounded-2xl bg-gradient-to-r from-amber-950/30 via-[#14141a] to-rose-950/30 border border-amber-500/40 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-amber-400" />
                      <span className="text-sm font-bold text-white">کنترلر تایمر معکوس ۲۴ ساعته:</span>
                    </div>
                    <p className="text-xs text-slate-300">
                      کارفرما می‌تواند پس از پایان مهلت یا هر زمان دلخواه، تایمر معکوس را با یک کلیک برای ۲۴ ساعت دیگر شارژ و شروع مجدد نماید.
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      onResetSpecialOffersTimer(specialOffers.durationHours || 24);
                      setSpecialOfferToast('تایمر شگفت‌انگیز برای ۲۴ ساعت آینده با موفقیت ریست و تمدید شد.');
                      setTimeout(() => setSpecialOfferToast(null), 3000);
                    }}
                    className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-rose-600 hover:from-amber-400 hover:to-rose-500 text-slate-950 font-black text-xs flex items-center gap-2 shadow-lg transition-all shrink-0 cursor-pointer"
                  >
                    <RefreshCw className="w-4 h-4" />
                    <span>شروع مجدد تایمر ۲۴ ساعته از همین الان</span>
                  </button>
                </div>

                {/* Duration Presets */}
                <div className="flex items-center gap-2 pt-2 border-t border-slate-800/80 text-xs">
                  <span className="text-slate-400">مدت دوره تایمر:</span>
                  {[
                    { hours: 12, label: '۱۲ ساعت' },
                    { hours: 24, label: '۲۴ ساعت (پیش‌فرض)' },
                    { hours: 48, label: '۴۸ ساعت (۲ روز)' },
                    { hours: 72, label: '۷۲ ساعت (۳ روز)' },
                  ].map((dur) => (
                    <button
                      key={dur.hours}
                      type="button"
                      onClick={() => {
                        onUpdateSpecialOffers({ ...specialOffers, durationHours: dur.hours });
                        onResetSpecialOffersTimer(dur.hours);
                        setSpecialOfferToast(`دوره تایمر به ${dur.label} تغییر و مجدداً تنظیم شد.`);
                        setTimeout(() => setSpecialOfferToast(null), 3000);
                      }}
                      className={`px-2.5 py-1 rounded-lg font-bold font-num text-[11px] transition-all ${
                        specialOffers.durationHours === dur.hours
                          ? 'bg-amber-400 text-slate-950 font-black'
                          : 'bg-slate-900 text-slate-300 border border-slate-800 hover:bg-slate-800'
                      }`}
                    >
                      {dur.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Title & Subtitle Customizer */}
              <div className="p-4 rounded-2xl bg-[#14141a] border border-slate-800 space-y-3 text-xs">
                <span className="font-bold text-white block">عنوان و متن کادر شگفت‌انگیز:</span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-400 mb-1">تیتر اصلی کادر:</label>
                    <input
                      type="text"
                      value={specialOffers.title}
                      onChange={(e) => onUpdateSpecialOffers({ ...specialOffers, title: e.target.value })}
                      className="w-full p-2.5 rounded-xl border border-slate-700 bg-slate-900 text-white font-bold"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 mb-1">زیرعنوان کادر:</label>
                    <input
                      type="text"
                      value={specialOffers.subtitle}
                      onChange={(e) => onUpdateSpecialOffers({ ...specialOffers, subtitle: e.target.value })}
                      className="w-full p-2.5 rounded-xl border border-slate-700 bg-slate-900 text-white"
                    />
                  </div>
                </div>
              </div>

              {/* Add Product to Special Offer */}
              <div className="p-4 rounded-2xl bg-[#14141a] border border-slate-800 space-y-3 text-xs">
                <span className="font-bold text-white flex items-center gap-1.5">
                  <Plus className="w-4 h-4 text-emerald-400" />
                  <span>افزودن محصول جدید به بخش پیشنهادات شگفت‌انگیز:</span>
                </span>

                <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-end">
                  {/* Select Product */}
                  <div className="sm:col-span-6">
                    <label className="block text-slate-400 mb-1">انتخاب کالا از موجودی انبار اهواز:</label>
                    <select
                      value={specialOfferProductSelect}
                      onChange={(e) => setSpecialOfferProductSelect(e.target.value)}
                      className="w-full p-2.5 rounded-xl border border-slate-700 bg-slate-900 text-white"
                    >
                      <option value="">-- انتخاب محصول برای تخفیف ۲۴ ساعته --</option>
                      {products
                        .filter((p) => !specialOffers.items.some((it) => it.productId === p.id))
                        .map((p) => (
                          <option key={p.id} value={p.id}>
                            {p.name} ({p.model}) - {p.price.toLocaleString('en-US')} تومان
                          </option>
                        ))}
                    </select>
                  </div>

                  {/* Discount Percent */}
                  <div className="sm:col-span-3">
                    <label className="block text-slate-400 mb-1">درصد تخفیف ویژه (٪):</label>
                    <input
                      type="number"
                      min={1}
                      max={70}
                      value={specialOfferDiscountInput}
                      onChange={(e) => setSpecialOfferDiscountInput(Number(e.target.value))}
                      className="w-full p-2.5 rounded-xl border border-slate-700 bg-slate-900 text-white font-num font-bold"
                    />
                  </div>

                  {/* Stock Left */}
                  <div className="sm:col-span-3">
                    <label className="block text-slate-400 mb-1">موجودی مجاز برای تخفیف (عدد):</label>
                    <input
                      type="number"
                      min={1}
                      max={50}
                      value={specialOfferStockInput}
                      onChange={(e) => setSpecialOfferStockInput(Number(e.target.value))}
                      className="w-full p-2.5 rounded-xl border border-slate-700 bg-slate-900 text-white font-num font-bold"
                    />
                  </div>
                </div>

                <div className="pt-2 flex justify-end">
                  <button
                    type="button"
                    disabled={!specialOfferProductSelect}
                    onClick={() => {
                      if (!specialOfferProductSelect) return;
                      const newItem: SpecialOfferItem = {
                        productId: specialOfferProductSelect,
                        discountPercent: specialOfferDiscountInput || 15,
                        stockLeft: specialOfferStockInput || 3,
                        customBadge: `تخفیف شگفت‌انگیز ۲۴ ساعته`,
                      };
                      onUpdateSpecialOffers({
                        ...specialOffers,
                        items: [...specialOffers.items, newItem],
                      });
                      setSpecialOfferProductSelect('');
                      setSpecialOfferToast('کالا با موفقیت به بخش پیشنهادات شگفت‌انگیز اضافه شد.');
                      setTimeout(() => setSpecialOfferToast(null), 3000);
                    }}
                    className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold flex items-center gap-1.5 transition-colors"
                  >
                    <Plus className="w-4 h-4" />
                    <span>افزودن به پیشنهادات شگفت‌انگیز</span>
                  </button>
                </div>
              </div>

              {/* Current Featured Items List */}
              <div className="space-y-3">
                <span className="text-xs font-bold text-slate-300 block">
                  کالاهای مشمول تخفیف در این دوره ({specialOffers.items.length} کالا):
                </span>

                {specialOffers.items.length === 0 ? (
                  <div className="p-8 text-center bg-black/40 border border-slate-800 rounded-2xl text-slate-400 text-xs">
                    هنوز کالایی برای این دوره انتخاب نشده است. از فرم بالا کالا اضافه کنید.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {specialOffers.items.map((offerItem) => {
                      const prod = products.find((p) => p.id === offerItem.productId);
                      if (!prod) return null;
                      const discountedPrice = Math.round(prod.price * (1 - offerItem.discountPercent / 100));

                      return (
                        <div
                          key={offerItem.productId}
                          className="p-3.5 rounded-2xl bg-[#14141a] border border-slate-800 flex items-center gap-3 relative overflow-hidden"
                        >
                          <div className="absolute top-0 inset-x-0 h-0.5 bg-gradient-to-r from-amber-500 to-rose-600" />
                          
                          <img
                            src={prod.image}
                            alt={prod.name}
                            className="w-16 h-16 rounded-xl object-cover border border-slate-700 bg-black shrink-0"
                          />

                          <div className="flex-1 min-w-0 space-y-1 text-xs">
                            <div className="flex items-center justify-between gap-2">
                              <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 font-num font-black">
                                {offerItem.discountPercent}٪ تخفیف
                              </span>
                              <span className="text-[10px] text-amber-400 font-num">
                                ظرفیت: {offerItem.stockLeft} عدد
                              </span>
                            </div>

                            <h4 className="font-bold text-white truncate">{prod.name}</h4>
                            <div className="text-[10px] text-slate-400 font-num">{prod.model}</div>

                            <div className="flex items-center gap-2 font-num pt-0.5">
                              <span className="text-slate-500 line-through text-[11px]">
                                {prod.price.toLocaleString('en-US')}
                              </span>
                              <span className="text-emerald-400 font-bold text-xs">
                                {discountedPrice.toLocaleString('en-US')} تومان
                              </span>
                            </div>
                          </div>

                          <button
                            type="button"
                            onClick={() => {
                              const updatedItems = specialOffers.items.filter(
                                (it) => it.productId !== offerItem.productId
                              );
                              onUpdateSpecialOffers({ ...specialOffers, items: updatedItems });
                              setSpecialOfferToast(`کالای "${prod.name}" از پیشنهادات شگفت‌انگیز حذف شد.`);
                              setTimeout(() => setSpecialOfferToast(null), 3000);
                            }}
                            className="p-1.5 rounded-lg border border-slate-800 hover:border-rose-700 text-slate-500 hover:text-rose-400 transition-colors"
                            title="حذف از این دوره"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB: INSTALLMENT TERMS (مدیریت متن و مدارک خرید اقساطی با چک صیادی) */}
          {activeTab === 'installment' && (
            <div className="max-w-3xl mx-auto space-y-5 animate-in fade-in">
              <div className="p-5 sm:p-6 rounded-2xl bg-[#14141a] border border-amber-500/40 space-y-4">
                <div className="flex items-center justify-between gap-3 pb-3 border-b border-slate-800">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-2xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
                      <FileText className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-base font-bold text-white flex items-center gap-2">
                        <span>تنظیم متن و شرایط خرید اقساطی با چک صیادی</span>
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-bold">
                          قابل ویرایش توسط کارفرما
                        </span>
                      </h3>
                      <p className="text-xs text-slate-300 mt-0.5">
                        این متن هنگام کلیک مشتری روی دکمه «شرایط خرید اقساطی» در بنر اصلی سایت یا در مرحله تسویه حساب (شیوه پرداخت اقساطی) در یک پنجره به مشتری نمایش داده می‌شود.
                      </p>
                    </div>
                  </div>
                </div>

                {installmentSavedSuccess && (
                  <div className="p-3 rounded-xl bg-emerald-950/70 border border-emerald-500/60 text-emerald-300 text-xs flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>متن شرایط خرید اقساطی با موفقیت ذخیره شد و در تمامی بخش‌های سایت به‌روزرسانی گردید.</span>
                  </div>
                )}

                <div className="space-y-2">
                  <label className="block text-xs font-bold text-slate-200">
                    متن شرایط، نحوه ارائه چک صیادی، ضامن و هماهنگی حضوری اهواز:
                  </label>
                  <textarea
                    rows={10}
                    value={localInstallmentTerms}
                    onChange={(e) => setLocalInstallmentTerms(e.target.value)}
                    className="w-full p-3.5 rounded-xl border border-slate-700 bg-black text-white text-xs leading-relaxed focus:outline-none focus:ring-2 focus:ring-amber-500 font-sans"
                    placeholder="متن شرایط اقساط و مدارک را وارد کنید..."
                  />
                </div>

                {/* Actions */}
                <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setLocalInstallmentTerms(defaultTermsFallback)}
                    className="text-slate-400 hover:text-white underline text-xs transition-colors"
                  >
                    بازیابی متن رسمی پیش‌فرض
                  </button>

                  <button
                    type="button"
                    onClick={handleSaveInstallmentTerms}
                    className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-slate-950 font-black text-xs flex items-center gap-2 shadow-lg transition-all cursor-pointer"
                  >
                    <Check className="w-4 h-4" />
                    <span>ذخیره و اعمال بلادرنگ در سایت</span>
                  </button>
                </div>

                {/* Live Preview Box of the Customer Modal */}
                <div className="pt-4 border-t border-slate-800 space-y-2">
                  <span className="text-[11px] font-bold text-slate-400 block">
                    پیش‌نمایش زنده پنجره‌ای که مشتری مشاهده می‌کند:
                  </span>
                  <div className="p-4 rounded-xl bg-slate-900/90 border border-amber-600/40 text-xs text-slate-200 leading-relaxed whitespace-pre-line font-sans shadow-inner">
                    {localInstallmentTerms}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: TICKER & ANNOUNCEMENT */}
          {activeTab === 'ticker' && (
            <div className="max-w-2xl mx-auto space-y-5">
              <div className="p-5 rounded-2xl bg-[#14141a] border border-slate-800 space-y-4">
                <div className="flex items-center gap-2">
                  <Edit3 className="w-5 h-5 text-amber-400" />
                  <h3 className="text-base font-bold text-white">تنظیمات نوار متحرک بالای سایت (Marquee Ticker)</h3>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  متن این نوار به صورت انیمیشنی و مداوم در بالای سایت به تمامی بازدیدکنندگان نمایش داده می‌شود. می‌توانید اطلاعیه‌های تخفیف، اخبار تامین کالا یا پرداخت اقساطی را در آن درج نمایید.
                </p>

                <div className="space-y-2">
                  <label className="block text-xs font-bold text-slate-300">متن اطلاعیه انبار و شرایط پرداخت:</label>
                  <textarea
                    rows={4}
                    value={localTicker}
                    onChange={(e) => setLocalTicker(e.target.value)}
                    className="w-full p-3 rounded-xl border border-slate-700 bg-black/60 text-white text-xs leading-relaxed focus:outline-none focus:ring-2 focus:ring-rose-500"
                    placeholder="متن اطلاعیه..."
                  />
                </div>

                {/* Live Preview */}
                <div className="p-3 rounded-xl bg-black border border-slate-800 space-y-1">
                  <span className="text-[10px] text-slate-500 font-bold block">پیش‌نمایش زنده در سایت:</span>
                  <div className="text-xs text-rose-400 font-medium truncate py-1">
                    {localTicker}
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2">
                  <button
                    onClick={() => setLocalTicker('امکان خرید اقساطی در ۴ قسط بدون سود با اسنپ‌پی (SnappPay) · خرید اقساطی با چک صیادی و ضمانت · درگاه پرداخت آنلاین سامان (شتاب) · ارسال فوری از انبار مرکزی اهواز · گواهی کالیبراسیون ۱۰۰٪ معتبر · تلفن مستقیم: 061-32230000')}
                    className="text-slate-400 hover:text-white underline text-xs"
                  >
                    بازنشانی به متن استاندارد
                  </button>
                  <button
                    onClick={handleSaveTicker}
                    className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm"
                  >
                    <Check className="w-4 h-4" />
                    <span>ذخیره و اعمال بلادرنگ در سایت</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: AGENCIES & BRANDS (مدیریت و افزودن نمایندگی‌ها) */}
          {activeTab === 'agencies' && (
            <div className="space-y-4 max-w-4xl mx-auto">
              {/* Header */}
              <div className="p-4 sm:p-5 rounded-2xl bg-[#14141a] border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-500 shadow-inner shrink-0">
                    <Award className="w-5 h-5 text-amber-400" />
                  </div>
                  <div>
                    <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
                      <span>مدیریت برندها و نمایندگی‌های رسمی پیشگام صنعت</span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-num font-bold">
                        {agencies.length} برند فعال
                      </span>
                    </h3>
                    <p className="text-xs text-slate-400">
                      افزودن و ویرایش برندهای جهانی همکار، کشور سازنده، سرتیفیکیت‌ها و تخصص‌ها
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setShowAddAgencyModal(true)}
                  className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-md transition-colors shrink-0 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>+ افزودن نمایندگی جدید</span>
                </button>
              </div>

              {agencyToast && (
                <div className="p-3 rounded-xl bg-emerald-950/60 border border-emerald-600/50 text-emerald-300 text-xs flex items-center gap-2 animate-in fade-in">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>{agencyToast}</span>
                </div>
              )}

              {/* Agencies Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {agencies.map((ag, idx) => (
                  <div key={ag.id || idx} className="p-4 rounded-2xl bg-[#14141a] border border-slate-800 space-y-3 hover:border-slate-700 transition-all">
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 flex-1 min-w-0">
                        <Award className="w-4 h-4 text-amber-400 shrink-0" />
                        <input
                          type="text"
                          value={ag.name}
                          onChange={(e) => {
                            const copy = [...agencies];
                            copy[idx] = { ...copy[idx], name: e.target.value };
                            onUpdateAgencies(copy);
                          }}
                          className="font-bold text-sm bg-black/60 border border-slate-700 rounded-lg px-2 py-1 text-white flex-1 focus:ring-1 focus:ring-rose-500"
                          placeholder="نام برند یا شرکت"
                        />
                      </div>
                      <input
                        type="text"
                        value={ag.country}
                        onChange={(e) => {
                          const copy = [...agencies];
                          copy[idx] = { ...copy[idx], country: e.target.value };
                          onUpdateAgencies(copy);
                        }}
                        className="text-xs bg-black/60 border border-slate-700 rounded-lg px-2 py-1 text-slate-300 w-28 text-center shrink-0"
                        placeholder="کشور سازنده"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] text-slate-400 font-bold block">سطح عاملیت در خوزستان:</label>
                      <input
                        type="text"
                        value={ag.role}
                        onChange={(e) => {
                          const copy = [...agencies];
                          copy[idx] = { ...copy[idx], role: e.target.value };
                          onUpdateAgencies(copy);
                        }}
                        className="w-full text-xs bg-black/60 border border-slate-700 rounded-lg p-2 text-rose-300 font-bold"
                        placeholder="نقش نمایندگی..."
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] text-slate-400 font-bold block">نشان و بج اعتبار:</label>
                      <input
                        type="text"
                        value={ag.badge}
                        onChange={(e) => {
                          const copy = [...agencies];
                          copy[idx] = { ...copy[idx], badge: e.target.value };
                          onUpdateAgencies(copy);
                        }}
                        className="w-full text-xs bg-black/60 border border-slate-700 rounded-lg p-1.5 text-amber-300"
                        placeholder="سرتیفیکیت یا بج گارانتی..."
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] text-slate-400 font-bold block">تجهیزات و تخصص‌های اصلی (با «،» جدا کنید):</label>
                      <input
                        type="text"
                        value={ag.specialties?.join('، ') || ''}
                        onChange={(e) => {
                          const copy = [...agencies];
                          copy[idx] = {
                            ...copy[idx],
                            specialties: e.target.value.split('،').map((s) => s.trim()).filter(Boolean),
                          };
                          onUpdateAgencies(copy);
                        }}
                        className="w-full text-xs bg-black/60 border border-slate-700 rounded-lg p-1.5 text-slate-300"
                        placeholder="تخصص‌ها..."
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] text-slate-400 font-bold block">توضیحات و سوابق تامین:</label>
                      <textarea
                        rows={2}
                        value={ag.description}
                        onChange={(e) => {
                          const copy = [...agencies];
                          copy[idx] = { ...copy[idx], description: e.target.value };
                          onUpdateAgencies(copy);
                        }}
                        className="w-full text-xs bg-black/60 border border-slate-700 rounded-lg p-2 text-slate-300 leading-relaxed"
                        placeholder="توضیح کوتاه سوابق تامین..."
                      />
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-slate-800/80">
                      <button
                        type="button"
                        onClick={() => {
                          setAgencyToast(`تغییرات نمایندگی "${ag.name}" ذخیره گردید.`);
                          setTimeout(() => setAgencyToast(null), 3000);
                        }}
                        className="px-3 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-emerald-400 text-[11px] font-bold flex items-center gap-1 transition-colors"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>ذخیره تغییرات</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          if (confirm(`آیا از حذف برند "${ag.name}" از لیست نمایندگی‌ها اطمینان دارید؟`)) {
                            const updated = agencies.filter((_, i) => i !== idx);
                            onUpdateAgencies(updated);
                            localStorage.setItem('pishgam_agencies', JSON.stringify(updated));
                            setAgencyToast(`برند "${ag.name}" حذف گردید.`);
                            setTimeout(() => setAgencyToast(null), 3000);
                          }
                        }}
                        className="text-slate-500 hover:text-rose-400 text-xs flex items-center gap-1 transition-colors cursor-pointer"
                        title="حذف این برند"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>حذف این برند</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {/* Add Agency Modal */}
              {showAddAgencyModal && (
                <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 animate-in fade-in">
                  <div className="bg-[#121318] border border-slate-700 rounded-2xl w-full max-w-lg p-5 sm:p-6 space-y-4 shadow-2xl">
                    <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                      <div className="flex items-center gap-2">
                        <Award className="w-5 h-5 text-amber-400" />
                        <h3 className="font-bold text-base text-white">افزودن برند و نمایندگی جدید به پیشگام صنعت</h3>
                      </div>
                      <button
                        type="button"
                        onClick={() => setShowAddAgencyModal(false)}
                        className="text-slate-400 hover:text-white p-1 cursor-pointer"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>

                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        if (!newAgencyName.trim()) {
                          alert('لطفاً نام برند یا شرکت نمایندگی را وارد نمایید.');
                          return;
                        }
                        const newAg: AgencyItem = {
                          id: `ag-${Date.now()}`,
                          name: newAgencyName.trim(),
                          country: newAgencyCountry.trim() || 'استاندارد بین‌المللی',
                          role: newAgencyRole.trim() || 'عاملیت مجاز فروش در اهواز',
                          description: newAgencyDescription.trim() || 'تامین تجهیزات تست و سنجش صنعتی اصل با ضمانت رسمی',
                          badge: newAgencyBadge.trim() || 'سرتیفیکیت معتبر',
                          specialties: newAgencySpecialties
                            .split('،')
                            .map((s) => s.trim())
                            .filter(Boolean),
                        };
                        const updated = [...agencies, newAg];
                        onUpdateAgencies(updated);
                        localStorage.setItem('pishgam_agencies', JSON.stringify(updated));
                        setAgencyToast(`نمایندگی "${newAgencyName}" با موفقیت به لیست اضافه شد.`);
                        setTimeout(() => setAgencyToast(null), 3000);
                        setShowAddAgencyModal(false);
                        setNewAgencyName('');
                        setNewAgencyDescription('');
                      }}
                      className="space-y-3.5 text-xs"
                    >
                      <div>
                        <label className="block text-slate-300 mb-1 font-bold">نام برند یا کمپانی نمایندگی *:</label>
                        <input
                          type="text"
                          required
                          placeholder="مثال: HIOKI (ژاپن) یا FLUKE (آمریکا) یا WIKA"
                          value={newAgencyName}
                          onChange={(e) => setNewAgencyName(e.target.value)}
                          className="w-full p-2.5 rounded-xl border border-slate-700 bg-slate-900 text-white font-bold"
                        />
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="block text-slate-300 mb-1 font-bold">کشور مبدا / استاندارد:</label>
                          <input
                            type="text"
                            placeholder="مثال: ژاپن (Nagano, Japan)"
                            value={newAgencyCountry}
                            onChange={(e) => setNewAgencyCountry(e.target.value)}
                            className="w-full p-2 rounded-xl border border-slate-700 bg-slate-900 text-white"
                          />
                        </div>
                        <div>
                          <label className="block text-slate-300 mb-1 font-bold">نشان و بج اعتبار:</label>
                          <input
                            type="text"
                            placeholder="مثال: سرتیفیکیت معتبر IEC"
                            value={newAgencyBadge}
                            onChange={(e) => setNewAgencyBadge(e.target.value)}
                            className="w-full p-2 rounded-xl border border-slate-700 bg-slate-900 text-white"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-slate-300 mb-1 font-bold">سطح و عنوان عاملیت در خوزستان:</label>
                        <input
                          type="text"
                          placeholder="مثال: عاملیت انحصاری توزیع و خدمات پس از فروش در استان خوزستان"
                          value={newAgencyRole}
                          onChange={(e) => setNewAgencyRole(e.target.value)}
                          className="w-full p-2 rounded-xl border border-slate-700 bg-slate-900 text-white font-bold text-rose-300"
                        />
                      </div>

                      <div>
                        <label className="block text-slate-300 mb-1 font-bold">تجهیزات و تخصص‌های کلیدی (با ویرگول «،» جدا کنید):</label>
                        <input
                          type="text"
                          placeholder="مثال: پاورآنالایزر، کلمپ جریان، دیتالاگر مهندسی"
                          value={newAgencySpecialties}
                          onChange={(e) => setNewAgencySpecialties(e.target.value)}
                          className="w-full p-2 rounded-xl border border-slate-700 bg-slate-900 text-white"
                        />
                      </div>

                      <div>
                        <label className="block text-slate-300 mb-1 font-bold">توضیحات و سوابق تامین در اهواز:</label>
                        <textarea
                          rows={3}
                          placeholder="توضیحاتی درباره کیفیت قطعات، گارانتی، کالیبراسیون و انبارداری قطعات..."
                          value={newAgencyDescription}
                          onChange={(e) => setNewAgencyDescription(e.target.value)}
                          className="w-full p-2.5 rounded-xl border border-slate-700 bg-slate-900 text-white leading-relaxed"
                        />
                      </div>

                      <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                        <button
                          type="button"
                          onClick={() => setShowAddAgencyModal(false)}
                          className="px-4 py-2 rounded-xl border border-slate-700 text-slate-400 hover:text-white cursor-pointer"
                        >
                          انصراف
                        </button>
                        <button
                          type="submit"
                          className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold flex items-center gap-1.5 cursor-pointer shadow-md"
                        >
                          <Plus className="w-4 h-4" />
                          <span>افزودن به لیست نمایندگی‌ها</span>
                        </button>
                      </div>
                    </form>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 6: EXIT RETENTION & DISCOUNT */}
          {activeTab === 'retention' && (
            <div className="max-w-2xl mx-auto space-y-5">
              <div className="p-5 rounded-2xl bg-[#14141a] border border-slate-800 space-y-4">
                <div className="flex items-center gap-2">
                  <Tag className="w-5 h-5 text-emerald-400" />
                  <h3 className="text-base font-bold text-white">تنظیمات پاپ‌آپ هوشمند تحریک مشتری و کد تخفیف خروج</h3>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  هنگامی که مشتری نشانگر موس را به بالای مرورگر جهت ترک سایت می‌برد، این کد تخفیف اختصاصی همراه با مزایای ارسال فوری در اهواز و اقساط اسنپ‌پی نمایش داده می‌شود تا سبد خرید را نهایی کند.
                </p>

                <div className="p-4 rounded-2xl bg-black/60 border border-slate-800 space-y-3">
                  <label className="block text-xs font-bold text-slate-300">کد کوپن تخفیف فعال برای خروج:</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={localDiscount}
                      onChange={(e) => setLocalDiscount(e.target.value.toUpperCase())}
                      className="p-2.5 rounded-xl border border-slate-700 bg-black text-white font-num font-black text-base uppercase tracking-wider flex-1 focus:ring-2 focus:ring-rose-500"
                    />
                    <button
                      onClick={handleSaveDiscount}
                      className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5"
                    >
                      <Check className="w-4 h-4" />
                      <span>ذخیره کد تخفیف</span>
                    </button>
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                  <div className="text-xs font-bold text-white">تست فوری رفتار پاپ‌آپ:</div>
                  <p className="text-[11px] text-slate-400">
                    برای بررسی شکل ظاهری پاپ‌آپ در وضعیت‌های سبد خرید پر یا خالی، دکمه زیر را کلیک کنید:
                  </p>
                  <button
                    onClick={onPreviewExitIntent}
                    className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm"
                  >
                    <AlertTriangle className="w-4 h-4 text-amber-300" />
                    <span>مشاهده پیش‌نمایش پاپ‌آپ خروج مشتری</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 7: STORE SETTINGS & CONTACT */}
          {activeTab === 'settings' && (
            <div className="max-w-2xl mx-auto space-y-5">
              <div className="p-5 rounded-2xl bg-[#14141a] border border-slate-800 space-y-4">
                <div className="flex items-center gap-2">
                  <Settings className="w-5 h-5 text-rose-500" />
                  <h3 className="text-base font-bold text-white">تنظیمات اطلاعات انبار مرکزی و فروشگاه</h3>
                </div>

                <div className="space-y-3 text-xs">
                  <div>
                    <label className="block text-slate-400 mb-1 font-medium">شماره تلفن ثابت دفتر و انبار اهواز:</label>
                    <input
                      type="text"
                      value={localPhone}
                      onChange={(e) => setLocalPhone(e.target.value)}
                      className="w-full p-2.5 rounded-xl border border-slate-700 bg-black text-white font-num"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-400 mb-1 font-medium">شماره موبایل و واتس‌اپ تدارکات:</label>
                    <input
                      type="text"
                      value={localMobile}
                      onChange={(e) => setLocalMobile(e.target.value)}
                      className="w-full p-2.5 rounded-xl border border-slate-700 bg-black text-white font-num"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-400 mb-1 font-medium">آدرس دقیق انبار مرکزی جهت دریافت حضوری:</label>
                    <textarea
                      rows={2}
                      value={localAddress}
                      onChange={(e) => setLocalAddress(e.target.value)}
                      className="w-full p-2.5 rounded-xl border border-slate-700 bg-black text-white leading-relaxed"
                    />
                  </div>
                </div>

                <div className="pt-2 flex justify-end">
                  <button
                    onClick={handleSaveStoreSettings}
                    className="px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm"
                  >
                    <Check className="w-4 h-4" />
                    <span>ذخیره اطلاعات انبار</span>
                  </button>
                </div>
              </div>

              {/* MANAGER INVOICE EMAIL NOTIFICATION CARD (ارسال خودکار فاکتور هر سفارش به ایمیل مدیر) */}
              <div className="p-5 rounded-2xl bg-[#14141a] border border-slate-800 space-y-4">
                <div className="flex items-center gap-2 pb-2 border-b border-slate-800">
                  <div className="w-8 h-8 rounded-xl bg-rose-600/20 text-rose-400 flex items-center justify-center shrink-0">
                    <Send className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white flex items-center gap-2">
                      <span>ارسال خودکار فاکتور سفارشات به ایمیل مدیر</span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 font-bold">
                        سامانه هوشمند اطلاع‌رسانی
                      </span>
                    </h3>
                    <p className="text-[11px] text-slate-400">
                      به محض ثبت هر سفارش توسط مشتری، یک نسخه کامل از فاکتور با مشخصات خریدار به ایمیل مدیر ارسال می‌شود
                    </p>
                  </div>
                </div>

                <div className="space-y-3 text-xs">
                  <div>
                    <label className="block text-slate-300 mb-1 font-bold">آدرس ایمیل دریافت‌کننده مدیر *:</label>
                    <input
                      type="email"
                      value={managerEmailInput}
                      onChange={(e) => setManagerEmailInput(e.target.value)}
                      placeholder="مثال: manager@pishgams.com یا ایمیل شخصی"
                      className="w-full p-2.5 rounded-xl border border-slate-700 bg-black text-white font-mono text-xs"
                    />
                  </div>

                  <div className="p-3 rounded-xl bg-black/40 border border-slate-800/80 space-y-2.5">
                    <span className="text-[11px] font-bold text-slate-300 block">
                      تنظیمات اتصال SMTP هاست پیشگام صنعت (pishgams.com):
                    </span>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      <div>
                        <label className="block text-slate-400 mb-1 text-[11px]">سرور SMTP:</label>
                        <input
                          type="text"
                          value={smtpHostInput}
                          onChange={(e) => setSmtpHostInput(e.target.value)}
                          placeholder="mail.pishgams.com"
                          className="w-full p-2 rounded-xl border border-slate-700 bg-slate-900 text-white font-mono text-[11px]"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-400 mb-1 text-[11px]">پورت SMTP:</label>
                        <input
                          type="text"
                          value={smtpPortInput}
                          onChange={(e) => setSmtpPortInput(e.target.value)}
                          placeholder="465 (SSL) یا 587 (TLS)"
                          className="w-full p-2 rounded-xl border border-slate-700 bg-slate-900 text-white font-mono text-[11px]"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-400 mb-1 text-[11px]">نام کاربری ایمیل فرستنده (User):</label>
                        <input
                          type="text"
                          value={smtpUserInput}
                          onChange={(e) => setSmtpUserInput(e.target.value)}
                          placeholder="info@pishgams.com یا orders@pishgams.com"
                          className="w-full p-2 rounded-xl border border-slate-700 bg-slate-900 text-white font-mono text-[11px]"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-400 mb-1 text-[11px]">رمز عبور ایمیل (Password):</label>
                        <input
                          type="password"
                          value={smtpPassInput}
                          onChange={(e) => setSmtpPassInput(e.target.value)}
                          placeholder="••••••••••••"
                          className="w-full p-2 rounded-xl border border-slate-700 bg-slate-900 text-white font-mono text-[11px]"
                        />
                      </div>
                    </div>
                  </div>

                  {emailTestingStatus && (
                    <div className="p-3 rounded-xl bg-slate-900 border border-slate-700 text-xs text-slate-200 flex items-center gap-2 animate-in fade-in">
                      <Sparkles className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span>{emailTestingStatus}</span>
                    </div>
                  )}

                  <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-800">
                    <button
                      type="button"
                      onClick={async () => {
                        setEmailTestingStatus('در حال ارسال فاکتور تستی...');
                        try {
                          const res = await fetch('/api/orders/send-invoice-email', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({
                              order: orders[0] || {
                                id: 'test-order-1',
                                trackingCode: 'PSH-TEST-9901',
                                customerName: 'مهندس رضایی (تست سامانه)',
                                customerPhone: '09161112233',
                                city: 'اهواز',
                                address: 'بلوار پاسداران، شهرک صنعتی شماره ۱',
                                paymentMethod: 'online',
                                totalAmount: 6850000,
                                items: [{ product: products[0], quantity: 1 }],
                              },
                              managerEmail: managerEmailInput,
                              smtpConfig: {
                                host: smtpHostInput,
                                port: smtpPortInput,
                                user: smtpUserInput,
                                pass: smtpPassInput,
                              },
                            }),
                          });
                          const data = await res.json();
                          setEmailTestingStatus(data.message || 'فاکتور تستی پردازش شد.');
                        } catch (err: any) {
                          setEmailTestingStatus('خطا در ارتباط با سرور: ' + err.message);
                        }
                      }}
                      className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <Send className="w-3.5 h-3.5 text-rose-400" />
                      <span>تست ارسال یک فاکتور نمونه به ایمیل مدیر</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        localStorage.setItem('pishgam_manager_email', managerEmailInput);
                        localStorage.setItem(
                          'pishgam_smtp_config',
                          JSON.stringify({
                            host: smtpHostInput,
                            port: smtpPortInput,
                            user: smtpUserInput,
                            pass: smtpPassInput,
                          })
                        );
                        setEmailTestingStatus('تنظیمات ایمیل اطلاع‌رسانی مدیر با موفقیت ذخیره شد.');
                        setTimeout(() => setEmailTestingStatus(null), 4000);
                      }}
                      className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-sm"
                    >
                      <Check className="w-4 h-4" />
                      <span>ذخیره تنظیمات ایمیل فاکتور</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* EDITABLE INSTALLMENT TERMS CARD (ویرایش متن و شرایط خرید اقساطی حضوری و چک صیادی) */}
              <div className="p-5 rounded-2xl bg-[#14141a] border border-amber-600/50 space-y-4">
                <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                  <div className="flex items-center gap-2">
                    <FileText className="w-5 h-5 text-amber-400" />
                    <div>
                      <h3 className="text-sm font-bold text-white">متن شرایط خرید اقساطی حضوری و مدارک ضمانت (چک صیادی)</h3>
                      <p className="text-[11px] text-slate-400">این متن در صفحه تسویه‌حساب هنگام انتخاب گزینه اقساطی به مشتری نمایش داده می‌شود</p>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded-full bg-amber-950 border border-amber-600/40 text-amber-300 text-[10px] font-bold">
                    ویرایشگر شرایط اقساط
                  </span>
                </div>

                <div>
                  <textarea
                    rows={8}
                    value={localInstallmentTerms}
                    onChange={(e) => setLocalInstallmentTerms(e.target.value)}
                    className="w-full p-3 rounded-xl border border-slate-700 bg-black text-white text-xs leading-relaxed focus:outline-none focus:ring-2 focus:ring-amber-500 font-sans"
                    placeholder="متن شرایط اقساط و مدارک را وارد کنید..."
                  />
                </div>

                <div className="flex items-center justify-between pt-1">
                  <button
                    type="button"
                    onClick={() => setLocalInstallmentTerms(defaultTermsFallback)}
                    className="text-slate-400 hover:text-white underline text-[11px]"
                  >
                    بازنشانی به متن پیش‌فرض
                  </button>
                  <button
                    type="button"
                    onClick={handleSaveInstallmentTerms}
                    className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm"
                  >
                    <Check className="w-4 h-4" />
                    <span>{installmentSavedSuccess ? 'ذخیره شد ✓' : 'ذخیره متن شرایط اقساطی'}</span>
                  </button>
                </div>
              </div>

              {/* DEDICATED GUIDE & CONFIGURATION: SOLVING SMS TRACKING CODE FAILURE IN IRAN */}
              <div className="p-5 rounded-2xl bg-[#14141a] border border-emerald-700/60 space-y-4 text-xs">
                <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                  <div className="flex items-center gap-2">
                    <Smartphone className="w-5 h-5 text-emerald-400" />
                    <div>
                      <h3 className="text-sm font-bold text-white">
                        راهنمای فنی: چرا پیامک کد رهگیری به برخی مشتریان نمی‌رسد؟
                      </h3>
                      <p className="text-[11px] text-slate-400">
                        تحلیل مشکل بلک‌لیست مخابرات در ایران و راهکارهای فعال‌شده در سایت
                      </p>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded-full bg-emerald-950 border border-emerald-600/40 text-emerald-300 text-[10px] font-bold">
                    راهکار فعال
                  </span>
                </div>

                <div className="space-y-3 leading-relaxed text-slate-300 text-[11px]">
                  <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 space-y-1.5">
                    <span className="font-bold text-amber-400 block text-xs">۱. علت اصلی نرسیدن پیامک (لیست سیاه مخابرات / Blacklist):</span>
                    <p>
                      بیش از ۶۰٪ مشترکان همراه اول و ایرانسل با ارسال کد به ۸۹۹۹ دریافت پیامک‌های تبلیغاتی (خطوط ۱۰۰۰، ۳۰۰۰، ۵۰۰۰) را مسدود کرده‌اند. اگر سامانه‌ای از خط تبلیغاتی استفاده کند، مخابرات پیامک را بدون اخطار دور می‌اندازد و مشتری کد پیگیری را نمی‌گیرد!
                    </p>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 space-y-1.5">
                    <span className="font-bold text-emerald-400 block text-xs">۲. راه‌حل‌های عملیاتی فعال‌شده در پیشگام صنعت اهواز:</span>
                    <ul className="list-disc list-inside space-y-1 text-slate-300">
                      <li>
                        <strong>استفاده از پترن وب‌سرویس خدماتی (OTP Pattern):</strong> اتصال به سرویس خدماتی کاوه‌نگار / فراز اس‌ام‌اس که بلک‌لیست را ۱۰۰٪ دور می‌زند و زیر ۵ ثانیه به تمام شماره‌ها می‌رسد.
                      </li>
                      <li>
                        <strong>سامانه استعلام آنلاین بدون نیاز به پیامک:</strong> مشتری با وارد کردن شماره همراه در بالای سایت، فوراً وضعیت بسته و بارکد پستی را می‌بیند.
                      </li>
                      <li>
                        <strong>ثبت بارکد ۲۴ رقمی پستی در پنل مدیر:</strong> امکان ثبت بارکد پس از تحویل بسته به پست/تیپاکس و ارسال خودکار پیامک دوم به خریدار.
                      </li>
                      <li>
                        <strong>پشتیبان چندکاناله در واتساپ:</strong> امکان ارسال سریع فاکتور و کد پیگیری به واتساپ مشتری با ۱ کلیک از داخل پنل مدیریت.
                      </li>
                    </ul>
                  </div>

                  <div className="p-3 rounded-xl bg-black/60 border border-slate-800 flex items-center justify-between">
                    <div>
                      <span className="font-bold text-white block">وضعیت درگاه پیامک فعلی:</span>
                      <span className="text-slate-400 text-[10px]">کاوه‌نگار پترن خدماتی (الگوی تایید سفارش و بارکد پستی)</span>
                    </div>
                    <span className="px-2.5 py-1 rounded-lg bg-emerald-950 border border-emerald-600/50 text-emerald-300 font-bold font-num text-[11px] flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>فعال و تست‌شده</span>
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

        </div>
      </div>

      {/* MODAL: ADD NEW PRODUCT */}
      {showAddProductModal && (
        <div className="fixed inset-0 z-60 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-[#14141a] border border-slate-700 rounded-3xl w-full max-w-lg p-6 space-y-4 shadow-2xl text-xs">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <Plus className="w-4 h-4 text-emerald-400" />
                <span>افزودن تجهیز و دستگاه جدید به انبار اهواز</span>
              </h3>
              <button
                onClick={() => setShowAddProductModal(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveNewProduct} className="space-y-3">
              <div>
                <label className="block text-slate-400 mb-1">نام کامل دستگاه:</label>
                <input
                  type="text"
                  required
                  placeholder="مثال: مولتی‌متر دیجیتال اتورنج"
                  value={newProdName}
                  onChange={(e) => setNewProdName(e.target.value)}
                  className="w-full p-2 rounded-xl border border-slate-700 bg-black text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-400 mb-1">مدل فنی دستگاه:</label>
                  <input
                    type="text"
                    required
                    placeholder="مثال: UT89X"
                    value={newProdModel}
                    onChange={(e) => setNewProdModel(e.target.value)}
                    className="w-full p-2 rounded-xl border border-slate-700 bg-black text-white font-num"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">برند سازنده:</label>
                  <select
                    value={newProdBrand}
                    onChange={(e) => setNewProdBrand(e.target.value as any)}
                    className="w-full p-2 rounded-xl border border-slate-700 bg-black text-white"
                  >
                    <option value="UNI-T">UNI-T (یونیتی)</option>
                    <option value="Mastech">MASTECH (مستک)</option>
                    <option value="Kyoritsu">Kyoritsu (کیوریتسو)</option>
                    <option value="Pishgam">Pishgam (پیشگام)</option>
                    <option value="Fluke">FLUKE (فلوک)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-400 mb-1">دسته‌بندی تجهیز:</label>
                  <select
                    value={newProdCategory}
                    onChange={(e) => setNewProdCategory(e.target.value as any)}
                    className="w-full p-2 rounded-xl border border-slate-700 bg-black text-white"
                  >
                    <option value="multimeter">مولتی‌متر و کلمپ</option>
                    <option value="megger">میگر و عایق‌سنج</option>
                    <option value="thermal">ترموویژن و حرارت‌سنج</option>
                    <option value="hydraulic">پرس کابل‌شو و هیدرولیک</option>
                    <option value="calibrator">کالیبراتور فرآیندی</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">قیمت نقد (تومان):</label>
                  <input
                    type="number"
                    required
                    value={newProdPrice}
                    onChange={(e) => setNewProdPrice(Number(e.target.value))}
                    className="w-full p-2 rounded-xl border border-slate-700 bg-black text-white font-num"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">ویژگی برجسته و گارانتی:</label>
                <input
                  type="text"
                  value={newProdFeature}
                  onChange={(e) => setNewProdFeature(e.target.value)}
                  className="w-full p-2 rounded-xl border border-slate-700 bg-black text-white"
                />
              </div>

              {/* Product Image Selection & Upload for New Product */}
              <div className="space-y-2 p-3 rounded-2xl bg-black/60 border border-slate-800">
                <label className="block text-slate-300 font-bold">عکس و تصویر محصول:</label>
                <div className="flex items-center gap-3">
                  <img
                    src={newProdImage}
                    alt="New product preview"
                    className="w-16 h-16 rounded-xl object-cover border border-slate-700 bg-black shrink-0"
                  />
                  <div className="space-y-1.5 flex-1 text-xs">
                    <label className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-700 hover:border-emerald-500 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium cursor-pointer transition-colors">
                      <Upload className="w-3.5 h-3.5 text-emerald-400" />
                      <span>آپلود عکس از سیستم</span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={(e) => handleImageFileUpload(e, true)}
                        className="hidden"
                      />
                    </label>
                    <div className="flex items-center gap-1 overflow-x-auto py-1">
                      {PRODUCT_IMAGE_PRESETS.slice(0, 5).map((p, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => setNewProdImage(p.url)}
                          className={`p-1 rounded-lg border shrink-0 ${
                            newProdImage === p.url ? 'border-emerald-500 ring-1 ring-emerald-500' : 'border-slate-800'
                          }`}
                          title={p.name}
                        >
                          <img src={p.url} alt={p.name} className="w-7 h-7 rounded object-cover" />
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddProductModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-700 text-slate-300 hover:bg-slate-800"
                >
                  انصراف
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold"
                >
                  ذخیره و افزودن به کاتالوگ
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: CHANGE PRODUCT IMAGE (تنظیم یا تغییر عکس محصول موجود) */}
      {editingImageProduct && (
        <div className="fixed inset-0 z-60 bg-black/85 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-[#14141a] border border-slate-700 rounded-3xl w-full max-w-xl p-6 space-y-5 shadow-2xl text-xs text-slate-200 animate-in fade-in zoom-in-95 duration-150 max-h-[92vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Camera className="w-5 h-5 text-cyan-400" />
                <div>
                  <h3 className="font-bold text-sm text-white">
                    تنظیم یا تغییر عکس محصول: {editingImageProduct.name}
                  </h3>
                  <span className="text-[11px] text-slate-400 font-num">{editingImageProduct.model}</span>
                </div>
              </div>
              <button
                onClick={() => setEditingImageProduct(null)}
                className="text-slate-400 hover:text-white p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Current & New Photo Preview */}
            <div className="p-4 rounded-2xl bg-black/60 border border-slate-800 flex items-center gap-4">
              <div className="relative shrink-0">
                <img
                  src={selectedImageUrl || editingImageProduct.image}
                  alt={editingImageProduct.name}
                  className="w-24 h-24 rounded-2xl object-cover border-2 border-cyan-500/70 shadow-lg bg-black"
                />
                <span className="absolute -bottom-2 -end-1 px-1.5 py-0.5 rounded-full bg-cyan-600 text-white text-[9px] font-bold">
                  پیش‌نمایش
                </span>
              </div>
              <div className="space-y-1.5 flex-1 text-xs">
                <span className="font-bold text-white block">تصویر انتخابی برای نمایش در فروشگاه</span>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  می‌توانید عکس دلخواه را از کامپیوتر یا گوشی آپلود نمایید، از گالری تجهیزات صنعتی آماده انتخاب کنید، یا آدرس اینترنتی تصویر را وارد کنید.
                </p>
              </div>
            </div>

            {/* Option 1: Upload from Device */}
            <div className="p-3.5 rounded-2xl bg-[#1b1c24] border border-slate-700/80 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-white flex items-center gap-1.5">
                  <Upload className="w-4 h-4 text-emerald-400" />
                  <span>آپلود تصویر جدید از دستگاه (کامپیوتر یا گوشی):</span>
                </span>
                <span className="text-[10px] text-slate-400">حداکثر ۸ مگابایت</span>
              </div>
              <label className="flex items-center justify-center gap-2 p-3 rounded-xl border border-dashed border-slate-600 hover:border-emerald-500 bg-black/40 hover:bg-black/60 cursor-pointer text-slate-300 hover:text-white transition-all text-xs font-medium">
                <Upload className="w-4 h-4 text-emerald-400" />
                <span>انتخاب فایل عکس از سیستم / گالری</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => handleImageFileUpload(e, false)}
                  className="hidden"
                />
              </label>
            </div>

            {/* Option 2: Choose from Curated Presets */}
            <div className="space-y-2">
              <span className="font-bold text-white flex items-center gap-1.5">
                <ImageIcon className="w-4 h-4 text-amber-400" />
                <span>انتخاب از گالری تجهیزات صنعتی پیشگام صنعت:</span>
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {PRODUCT_IMAGE_PRESETS.map((preset, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setSelectedImageUrl(preset.url);
                      setCustomImageUrlInput(preset.url);
                    }}
                    className={`p-2 rounded-xl border text-start flex items-center gap-2 transition-all ${
                      selectedImageUrl === preset.url
                        ? 'border-cyan-500 bg-cyan-950/40 ring-1 ring-cyan-500/50 text-white font-bold'
                        : 'border-slate-800 bg-black/40 hover:border-slate-700 text-slate-300'
                    }`}
                  >
                    <img
                      src={preset.url}
                      alt={preset.name}
                      className="w-10 h-10 rounded-lg object-cover border border-slate-700 shrink-0 bg-black"
                    />
                    <div className="min-w-0 flex-1">
                      <span className="text-[10px] block truncate font-medium">{preset.name}</span>
                      <span className="text-[9px] text-slate-400">{preset.category}</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Option 3: Custom URL Input */}
            <div className="space-y-1.5">
              <label className="block text-slate-400 font-medium">یا وارد کردن آدرس اینترنتی مستقیم عکس (URL):</label>
              <div className="flex items-center gap-2">
                <input
                  type="url"
                  placeholder="https://... یا /src/assets/images/..."
                  value={customImageUrlInput}
                  onChange={(e) => {
                    setCustomImageUrlInput(e.target.value);
                    if (e.target.value.trim()) {
                      setSelectedImageUrl(e.target.value.trim());
                    }
                  }}
                  className="w-full p-2.5 rounded-xl border border-slate-700 bg-black text-white text-xs font-num focus:outline-none focus:ring-1 focus:ring-cyan-500"
                />
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setEditingImageProduct(null)}
                className="px-4 py-2 rounded-xl border border-slate-700 text-slate-300 hover:bg-slate-800"
              >
                انصراف
              </button>
              <button
                type="button"
                onClick={handleSaveProductImage}
                className="px-5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold flex items-center gap-1.5 shadow-md"
              >
                <Check className="w-4 h-4" />
                <span>ذخیره و اعمال تصویر جدید</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: ORDER DETAILS & OFFICIAL INVOICE VIEW */}
      {selectedOrderDetails && (
        <div className="fixed inset-0 z-60 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-[#14141a] border border-slate-700 rounded-3xl w-full max-w-2xl p-6 space-y-4 shadow-2xl text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-rose-500" />
                <h3 className="font-bold text-sm text-white font-num">
                  جزئیات فاکتور رسمی سفارش #{selectedOrderDetails.trackingCode}
                </h3>
              </div>
              <button
                onClick={() => setSelectedOrderDetails(null)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3 p-3 rounded-2xl bg-black/50 border border-slate-800 text-[11px]">
              <div><span className="text-slate-400">نام خریدار:</span> <span className="font-bold text-white">{selectedOrderDetails.customerName}</span></div>
              <div><span className="text-slate-400">شماره تماس:</span> <span className="font-bold text-white font-num" dir="ltr">{selectedOrderDetails.customerPhone}</span></div>
              <div><span className="text-slate-400">شهر و استان:</span> <span className="text-white">{selectedOrderDetails.city}</span></div>
              <div>
                <span className="text-slate-400">روش پرداخت:</span>{' '}
                <span className="font-bold text-rose-400">
                  {selectedOrderDetails.paymentMethod === 'snapp_pay' ? 'اسنپ‌پی (۴ قسط ماهانه)' :
                   selectedOrderDetails.paymentMethod === 'installment_in_person' ? 'اقساط با چک صیادی (حضوری اهواز)' : 'درگاه پرداخت آنلاین سامان (سامانه)'}
                </span>
              </div>
              <div className="col-span-2">
                <span className="text-slate-400">آدرس پستی:</span> <span className="text-slate-200">{selectedOrderDetails.address}</span>
              </div>
            </div>

            {/* SMS Delivery & Postal Barcode Management Section */}
            <div className="p-3.5 rounded-2xl bg-black/60 border border-slate-700/80 space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <Smartphone className="w-4 h-4 text-emerald-400" />
                  <span className="font-bold text-white text-xs">وضعیت ارسال پیامک و رهگیری پستی مرسوله</span>
                </div>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950 border border-emerald-600/40 text-emerald-400 font-bold">
                  پترن خدماتی (عبور ۱۰۰٪ از بلک‌لیست)
                </span>
              </div>

              {/* Status info */}
              <div className="text-[11px] text-slate-300 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">سامانه پیامکی متصل:</span>
                  <span className="font-bold text-white">وب‌سرویس پترن خدماتی کاوه‌نگار / فراز اس‌ام‌اس (بدون بلک‌لیست)</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">تحویل به خط مشتری:</span>
                  <span className="text-emerald-400 font-bold flex items-center gap-1 font-num">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>تحویل موفق به خط {selectedOrderDetails.customerPhone}</span>
                  </span>
                </div>
              </div>

              {/* Postal Barcode Input & Action */}
              <div className="pt-2 border-t border-slate-800 space-y-2">
                <label className="block text-slate-300 font-bold text-[11px]">
                  ثبت بارکد ۲۴ رقمی اداره پست یا کد رهگیری تیپاکس:
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={editingPostalBarcode}
                    onChange={(e) => setEditingPostalBarcode(e.target.value)}
                    placeholder="مثلاً: 24891002948192039485712 یا TPX-839201"
                    className="flex-1 p-2 rounded-xl border border-slate-700 bg-slate-900 text-white font-num text-xs focus:ring-1 focus:ring-emerald-500"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (!editingPostalBarcode.trim()) {
                        alert('لطفاً ابتدا بارکد پستی را وارد کنید.');
                        return;
                      }
                      if (onUpdateOrderDetails) {
                        onUpdateOrderDetails(selectedOrderDetails.id, {
                          postalBarcode: editingPostalBarcode.trim(),
                          status: 'shipped',
                        });
                      }
                      setSelectedOrderDetails({
                        ...selectedOrderDetails,
                        postalBarcode: editingPostalBarcode.trim(),
                        status: 'shipped',
                      });
                      setSmsActionFeedback('بارکد پستی ذخیره شد و پیامک حاوی لینک رهگیری زنده پست به خریدار ارسال گردید.');
                      setTimeout(() => setSmsActionFeedback(null), 4000);
                    }}
                    className="px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 transition-colors shrink-0 shadow-xs"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>ثبت و ارسال پیامک بارکد</span>
                  </button>
                </div>

                {/* Direct Tracking Portal Link if barcode present */}
                {selectedOrderDetails.postalBarcode && (
                  <div className="flex items-center justify-between text-[11px] pt-1">
                    <span className="text-slate-400 font-num">بارکد ثبت‌شده: <strong className="text-white">{selectedOrderDetails.postalBarcode}</strong></span>
                    <a
                      href={
                        selectedOrderDetails.postalBarcode.startsWith('TPX')
                          ? `https://tipaxco.com/tracking?id=${selectedOrderDetails.postalBarcode}`
                          : `https://tracking.post.ir/`
                      }
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-sky-400 hover:text-sky-300 flex items-center gap-1 underline font-bold"
                    >
                      <span>استعلام در سامانه رهگیری مرسولات پست / تیپاکس</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                )}

                {/* Multi-channel fallback buttons */}
                <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-800/80">
                  <a
                    href={`https://api.whatsapp.com/send?phone=98${selectedOrderDetails.customerPhone.replace(/^0/, '')}&text=${encodeURIComponent(
                      `با سلام جناب ${selectedOrderDetails.customerName}،\nسفارش شما در شرکت پیشگام صنعت اهواز به شماره پیگیری ${selectedOrderDetails.trackingCode} بسته‌بندی شد.\n${
                        selectedOrderDetails.postalBarcode
                          ? `بارکد رهگیری پستی مرسوله: ${selectedOrderDetails.postalBarcode}\nسامانه رهگیری پست: https://tracking.post.ir`
                          : 'سفارش در حال آماده‌سازی و ارسال از انبار مرکزی اهواز می‌باشد.'
                      }\nبا تشکر - بازرگانی پیشگام صنعت اهواز`
                    )}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3 py-1.5 rounded-xl border border-emerald-700/60 bg-emerald-950/40 hover:bg-emerald-900/60 text-emerald-300 text-[11px] font-bold flex items-center gap-1.5 transition-colors"
                  >
                    <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
                    <span>ارسال وضعیت در واتساپ خریدار</span>
                  </a>

                  <button
                    type="button"
                    onClick={() => {
                      const msg = `سفارش پیشگام صنعت: ${selectedOrderDetails.trackingCode}\nمشتری: ${selectedOrderDetails.customerName}\nتلفن: ${selectedOrderDetails.customerPhone}\nبارکد پستی: ${selectedOrderDetails.postalBarcode || 'در حال صدور'}\nپیگیری در: https://www.pishgams.com/track`;
                      navigator.clipboard.writeText(msg);
                      setSmsActionFeedback('متن پیامک و بارکد رهگیری در کلیپ‌بورد کپی شد.');
                      setTimeout(() => setSmsActionFeedback(null), 3000);
                    }}
                    className="px-3 py-1.5 rounded-xl border border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] flex items-center gap-1.5 transition-colors"
                  >
                    <Copy className="w-3 h-3 text-slate-400" />
                    <span>کپی متن پیامک</span>
                  </button>
                </div>

                {smsActionFeedback && (
                  <div className="p-2 rounded-xl bg-emerald-950/60 border border-emerald-600/60 text-emerald-300 text-[11px] flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>{smsActionFeedback}</span>
                  </div>
                )}
              </div>
            </div>

            {/* Ordered Items */}
            <div className="space-y-2">
              <span className="font-bold text-slate-300 block">اقلام سفارش:</span>
              <div className="rounded-xl border border-slate-800 divide-y divide-slate-800 overflow-hidden">
                {selectedOrderDetails.items.map((it) => (
                  <div key={it.product.id} className="p-2.5 flex items-center justify-between text-xs bg-black/40">
                    <div className="flex items-center gap-2">
                      <img src={it.product.image} alt={it.product.name} className="w-8 h-8 rounded-lg object-cover" />
                      <div>
                        <div className="font-bold text-white">{it.product.name}</div>
                        <div className="text-[10px] text-slate-400 font-num">{it.product.model} · {it.quantity} دستگاه</div>
                      </div>
                    </div>
                    <div className="font-num font-bold text-white">
                      {(it.product.price * it.quantity).toLocaleString('en-US')} تومان
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between font-num">
              <span className="font-sans font-bold text-slate-300">مجموع پرداختی:</span>
              <span className="text-base font-black text-emerald-400">
                {selectedOrderDetails.totalAmount.toLocaleString('en-US')} تومان
              </span>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => window.print()}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs flex items-center gap-1.5"
              >
                <Printer className="w-4 h-4 text-slate-300" />
                <span>چاپ فاکتور رسمی</span>
              </button>
              <button
                onClick={() => setSelectedOrderDetails(null)}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs"
              >
                بستن
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
